<?php

/**
 * This is the model class for table "duplicate_tool_has_task".
 *
 * The followings are the available columns in table 'duplicate_tool_has_task':
 * @property integer $tool_id
 * @property integer $task_id
 * @property double $price
 * @property double $percentage_share
 * @property integer $respect_share_but_could_squeeze_in
 * @property double $original_squeezed_share
 * @property integer $respect_task_percentage_share
 * @property string $create_time
 * @property string $update_time
 * @property integer $create_user_id
 * @property integer $update_user_id
 *
 * The followings are the available model relations:
 * @property Resources $tool
 * @property Resources $task
 */
class DuplicateToolHasTask extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'duplicate_tool_has_task';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('tool_id, task_id', 'required'),
			array('tool_id, task_id, respect_share_but_could_squeeze_in, respect_task_percentage_share, create_user_id, update_user_id', 'numerical', 'integerOnly'=>true),
			array('price, percentage_share, original_squeezed_share', 'numerical'),
			array('create_time, update_time', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('tool_id, task_id, price, percentage_share, respect_share_but_could_squeeze_in, original_squeezed_share, respect_task_percentage_share, create_time, update_time, create_user_id, update_user_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'tool' => array(self::BELONGS_TO, 'Resources', 'tool_id'),
			'task' => array(self::BELONGS_TO, 'Resources', 'task_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'tool_id' => 'Tool',
			'task_id' => 'Task',
			'price' => 'Price',
			'percentage_share' => 'Percentage Share',
			'respect_share_but_could_squeeze_in' => 'Respect Share But Could Squeeze In',
			'original_squeezed_share' => 'Original Squeezed Share',
			'respect_task_percentage_share' => 'Respect Task Percentage Share',
			'create_time' => 'Create Time',
			'update_time' => 'Update Time',
			'create_user_id' => 'Create User',
			'update_user_id' => 'Update User',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('tool_id',$this->tool_id);
		$criteria->compare('task_id',$this->task_id);
		$criteria->compare('price',$this->price);
		$criteria->compare('percentage_share',$this->percentage_share);
		$criteria->compare('respect_share_but_could_squeeze_in',$this->respect_share_but_could_squeeze_in);
		$criteria->compare('original_squeezed_share',$this->original_squeezed_share);
		$criteria->compare('respect_task_percentage_share',$this->respect_task_percentage_share);
		$criteria->compare('create_time',$this->create_time,true);
		$criteria->compare('update_time',$this->update_time,true);
		$criteria->compare('create_user_id',$this->create_user_id);
		$criteria->compare('update_user_id',$this->update_user_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return DuplicateToolHasTask the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
