<?php

/**
 * This is the model class for table "document_resource".
 *
 * The followings are the available columns in table 'document_resource':
 * @property string $id
 * @property integer $primary_document_id
 * @property string $title
 * @property string $filename
 * @property string $input_type
 * @property string $domain_id
 * @property string $file_fullname
 * @property integer $filesize
 * @property string $create_time
 * @property string $update_time
 * @property integer $create_user_id
 * @property integer $update_user_id
 *
 * The followings are the available model relations:
 * @property Resources $primaryDocument
 * @property Resourcegroupcategory $domain
 * @property DocumentResourceKeyword[] $documentResourceKeywords
 */
class DocumentResource extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'document_resource';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('primary_document_id, domain_id', 'required'),
			array('primary_document_id, filesize, create_user_id, update_user_id', 'numerical', 'integerOnly'=>true),
			array('title, filename', 'length', 'max'=>200),
			array('input_type', 'length', 'max'=>9),
			array('domain_id', 'length', 'max'=>10),
			array('file_fullname', 'length', 'max'=>60),
			array('create_time, update_time', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, primary_document_id, title, filename, input_type, domain_id, file_fullname, filesize, create_time, update_time, create_user_id, update_user_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'primaryDocument' => array(self::BELONGS_TO, 'Resources', 'primary_document_id'),
			'domain' => array(self::BELONGS_TO, 'Resourcegroupcategory', 'domain_id'),
			'documentResourceKeywords' => array(self::HAS_MANY, 'DocumentResourceKeyword', 'document_resource_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'primary_document_id' => 'Primary Document',
			'title' => 'Title',
			'filename' => 'Filename',
			'input_type' => 'Input Type',
			'domain_id' => 'Domain',
			'file_fullname' => 'File Fullname',
			'filesize' => 'Filesize',
			'create_time' => 'Create Time',
			'update_time' => 'Update Time',
			'create_user_id' => 'Create User',
			'update_user_id' => 'Update User',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('primary_document_id',$this->primary_document_id);
		$criteria->compare('title',$this->title,true);
		$criteria->compare('filename',$this->filename,true);
		$criteria->compare('input_type',$this->input_type,true);
		$criteria->compare('domain_id',$this->domain_id,true);
		$criteria->compare('file_fullname',$this->file_fullname,true);
		$criteria->compare('filesize',$this->filesize);
		$criteria->compare('create_time',$this->create_time,true);
		$criteria->compare('update_time',$this->update_time,true);
		$criteria->compare('create_user_id',$this->create_user_id);
		$criteria->compare('update_user_id',$this->update_user_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return DocumentResource the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
