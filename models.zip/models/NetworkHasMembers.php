<?php

/**
 * This is the model class for table "network_has_members".
 *
 * The followings are the available columns in table 'network_has_members':
 * @property string $network_id
 * @property string $member_id
 * @property string $member_status
 * @property string $initiator_request_status
 * @property string $destination_request_status
 * @property string $network_status
 * @property string $member_privilege
 * @property string $create_time
 * @property string $update_time
 * @property integer $create_user_id
 * @property integer $update_user_id
 */
class NetworkHasMembers extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'network_has_members';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('network_id, member_id, member_status, initiator_request_status, destination_request_status, network_status, member_privilege', 'required'),
			array('create_user_id, update_user_id', 'numerical', 'integerOnly'=>true),
			array('network_id, member_id, member_status, network_status', 'length', 'max'=>10),
			array('initiator_request_status, destination_request_status', 'length', 'max'=>8),
			array('member_privilege', 'length', 'max'=>7),
			array('create_time, update_time', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('network_id, member_id, member_status, initiator_request_status, destination_request_status, network_status, member_privilege, create_time, update_time, create_user_id, update_user_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'network_id' => 'Network',
			'member_id' => 'Member',
			'member_status' => 'Member Status',
			'initiator_request_status' => 'Initiator Request Status',
			'destination_request_status' => 'Destination Request Status',
			'network_status' => 'Network Status',
			'member_privilege' => 'Member Privilege',
			'create_time' => 'Create Time',
			'update_time' => 'Update Time',
			'create_user_id' => 'Create User',
			'update_user_id' => 'Update User',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('network_id',$this->network_id,true);
		$criteria->compare('member_id',$this->member_id,true);
		$criteria->compare('member_status',$this->member_status,true);
		$criteria->compare('initiator_request_status',$this->initiator_request_status,true);
		$criteria->compare('destination_request_status',$this->destination_request_status,true);
		$criteria->compare('network_status',$this->network_status,true);
		$criteria->compare('member_privilege',$this->member_privilege,true);
		$criteria->compare('create_time',$this->create_time,true);
		$criteria->compare('update_time',$this->update_time,true);
		$criteria->compare('create_user_id',$this->create_user_id);
		$criteria->compare('update_user_id',$this->update_user_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return NetworkHasMembers the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * This is the function that confirms if a member is connected to a network
         */
        public function isMemberConnectedToThisNetwork($member_id,$network_id){
            
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('network_has_members')
                    ->where("(member_id = $member_id and network_id=$network_id) and membership_status='accepted'");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        /**
         * This is the function that retreives all private network that a user is connected 
         */
        public function getAllTheNetworksWhereThisMemberIsConnectedTo($userid){
             $member_networks = [];
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='member_id=:memberid and membership_status=:status';   
             $criteria->params = array(':memberid'=>$userid, ':status'=>'accepted');
             $members = NetworkHasMembers::model()->findAll($criteria);
             
             foreach($members as $member){
                 $member_networks[] = $member['network_id'];
             }
             return $member_networks;
        }
        
        
        /**
         * This is the function that gets all the members of a network
         */
        public function getAllTheMembersOfThisNetwork($network_id){
            
            $network_members = [];
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='network_id=:netid and membership_status=:status';   
             $criteria->params = array(':netid'=>$network_id, ':status'=>'accepted');
             $networks = NetworkHasMembers::model()->findAll($criteria);
             
             foreach($networks as $network){
                 $network_members[] = $network['member_id'];
             }
             return $network_members;
            
        }
        
        /**
         * This is the function that confirms if a requester is already a member of a network 
         */
        public function isRequesterEligibleToMakeMembershipRequestToThisNetwork($member_id, $network_id){
            
            if($this->isThisNetworkMembershipRequestPending($member_id, $network_id)){
                return false;
            }else if($this->isThisNetworkMembershipRequestAlreadyAccepted($member_id, $network_id)){
                return false;
            }else{
                return true;
            }
     
        }
        
        
        /**
         * This is thhe function that confirms if a network membership request is successfully initiated
         */
        public function isNetworkMembershipRequestSuccessfullyInitiated($member_id,$network_id){
            if($this->isAPreviouslyRejectedRequestRemoved($member_id,$network_id)){
                
                $cmd =Yii::app()->db->createCommand();
                $result = $cmd->insert('network_has_members',
                                  array(
                                    'member_id'=>$member_id,
                                    'network_id'=>$network_id,
                                    'membership_status'=>"pending",   
                                    'date_initiated'=>new CDbExpression('NOW()'),
                                  )
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
            }else{
                return false;
            }
                
            
        }
        
        
        /**
         * This is the function that confirms if a previouely rejected request had been removed before initiating a new one
         */
        public function isAPreviouslyRejectedRequestRemoved($member_id,$network_id){
            
            if($this->isExistARejectedNetworkMembershipRequest($member_id,$network_id)){
                
                 $cmd =Yii::app()->db->createCommand();  
                $result = $cmd->delete('network_has_members', '(member_id=:memberid and network_id=:networkid) and membership_status=:status', array(':memberid'=>$member_id,':networkid'=>$network_id,':status'=>"rejected"));
            
                if($result>0){
                    return true;
                    
                }else{
                    return false;
                }
                
            }else{
                return true;
                
            }
           
        }
        
        
        
        /**
         * This is the function that confirms if a  previous network rejected trequest exist
         */
        public function isExistARejectedNetworkMembershipRequest($member_id,$network_id){
            
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('network_has_members')
                    ->where("(member_id = $member_id and network_id=$network_id) and membership_status='rejected'");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        /**
         * This is the function that confirms if a network request had already been treated and not pending
         */
        public function isThisNetworkMembershipRequestAlreadyAccepted($member_id, $network_id){
            
             $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('network_has_members')
                    ->where("(member_id = $member_id and network_id=$network_id) and membership_status='accepted'");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        /**
         * This is the function that confirms if tyhe rejection of a network membership  request is successful
         */
        public function isTheRejectionOfThisNetworkMembershipRequestASuccess($member_id,$network_id){
                
                if($this->isThisNetworkMembershipRequestPending($member_id,$network_id)){
                     $cmd =Yii::app()->db->createCommand();
                     $result = $cmd->insert('network_has_members',
                                  array(
                                    'member_id'=>$member_id,
                                    'network_id'=>$network_id,
                                    'membership_status'=>"rejected",   
                                    
                                  )
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                    
                }else{
                    return false;
                }           
               
          
    
        }
        
        
        
         /**
         * This is the function that confirms if tyhe acceptance of a network membership  request is successful
         */
        public function isTheAcceptanceOfThisNetworkMembershipRequestASuccess($member_id,$network_id){
                
                if($this->isThisNetworkMembershipRequestPending($member_id,$network_id)){
                     $cmd =Yii::app()->db->createCommand();
                     $result = $cmd->insert('network_has_members',
                                  array(
                                    'member_id'=>$member_id,
                                    'network_id'=>$network_id,
                                    'membership_status'=>"accepted",   
                                    
                                  )
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                    
                }else{
                    return false;
                }           
               
          
    
        }
        
        
        
        /**
         * This is the function that confirms if a network membership request is still pending
         */
        public function isThisNetworkMembershipRequestPending($member_id,$network_id){
            
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('network_has_members')
                    ->where("(member_id = $member_id and network_id=$network_id) and membership_status='pending'");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
         /**
         * This is the function that retreives all private network that a user is connected 
         */
        public function getAllThePrivateNetworkThatThisMemberIsConnectedTo($userid,$domain_id){
             $member_networks = [];
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='member_id=:memberid and membership_status=:status';   
             $criteria->params = array(':memberid'=>$userid, ':status'=>'accepted');
             $members = NetworkHasMembers::model()->findAll($criteria);
             
             foreach($members as $member){
                 
                 if($this->isThisNetworkPrivate($member['network_id'])){
                    // if($this->getTheDomainOfThisNetwork($member['network_id']) == $domain_id){
                            $member_networks[] = $member['network_id'];
                   // }
                 }
           
             }
             return $member_networks;
        }
        
        /**
         * This is the function that retrieves the domain id of a network
         */
        public function getTheDomainOfThisNetwork($network_id){
            $model = new Network;
            return $model->getTheDomainOfThisNetwork($network_id);
        }
        
        /**
         * This is the function that determines if a network is of a private type
         */
        public function isThisNetworkPrivate($network_id){
            $model = new Network;
            return $model->isThisNetworkPrivate($network_id);
        }
        
        
        
         /**
         * This is the function that retreives all private network that a user is connected 
         */
        public function getAllThePublicNetworkThatThisMemberIsConnectedTo($userid,$domain_id){
             $member_networks = [];
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='member_id=:memberid and membership_status=:status';   
             $criteria->params = array(':memberid'=>$userid, ':status'=>'accepted');
             $members = NetworkHasMembers::model()->findAll($criteria);
             
             foreach($members as $member){
                 
                 if($this->isThisNetworkPrivate($member['network_id'])==false){
                     //if($this->getTheDomainOfThisNetwork($member['network_id']) == $domain_id){
                            $member_networks[] = $member['network_id'];
                   /// }
                 }
           
             }
             return $member_networks;
        }
        
        
        /**
         * This is the function that gets other domain networks that this member is connected to
         */
        public function getAllTheOtherDomainNetworksThatThisMemberIsConnectedTo($user_id,$domain_id){
            
             $member_networks = [];
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='member_id=:memberid and membership_status=:status';   
             $criteria->params = array(':memberid'=>$user_id, ':status'=>'accepted');
             $members = NetworkHasMembers::model()->findAll($criteria);
             
             foreach($members as $member){
                 
                 if($this->isThisNetworkPrivate($member['network_id'])==false){
                    // if($this->getTheDomainOfThisNetwork($member['network_id']) != $domain_id){
                            $member_networks[] = $member['network_id'];
                    //}
                 }
           
             }
             return $member_networks;
        }
        
        
         /*8
         * This is the function that gets the total number of a netork group members
         */
        public function getTheTotalNumberOfThisGroupMembers($group_id){
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('network_has_members')
                    ->where("network_id = $group_id and membership_status='accepted'");
                $result = $cmd->queryScalar();
                
                return $result;
        }
}
