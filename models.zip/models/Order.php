<?php

/**
 * This is the model class for table "order".
 *
 * The followings are the available columns in table 'order':
 * @property string $id
 * @property string $order_number
 * @property string $status
 * @property string $order_domain_id
 * @property string $order_initiation_date
 * @property string $last_updated_date
 * @property integer $order_initiated_by
 * @property integer $order_updated_by
 *
 * The followings are the available model relations:
 * @property Resourcegroupcategory $orderDomain
 * @property Resourcegroup[] $resourcegroups
 * @property Payment[] $payments
 */
class Order extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'order';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('status, order_domain_id', 'required'),
			array('order_initiated_by, order_updated_by', 'numerical', 'integerOnly'=>true),
			array('order_number', 'length', 'max'=>20),
			array('status', 'length', 'max'=>6),
			array('order_domain_id', 'length', 'max'=>10),
			array('order_initiation_date, last_updated_date', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, order_number, status, order_domain_id, order_initiation_date, last_updated_date, order_initiated_by, order_updated_by', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'orderDomain' => array(self::BELONGS_TO, 'Resourcegroupcategory', 'order_domain_id'),
			'resourcegroups' => array(self::MANY_MANY, 'Resourcegroup', 'order_has_toolboxes(order_id, toolbox_id)'),
			'payments' => array(self::HAS_MANY, 'Payment', 'order_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'order_number' => 'Order Number',
			'status' => 'Status',
			'order_domain_id' => 'Order Domain',
			'order_initiation_date' => 'Order Initiation Date',
			'last_updated_date' => 'Last Updated Date',
			'order_initiated_by' => 'Order Initiated By',
			'order_updated_by' => 'Order Updated By',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('order_number',$this->order_number,true);
		$criteria->compare('status',$this->status,true);
		$criteria->compare('order_domain_id',$this->order_domain_id,true);
		$criteria->compare('order_initiation_date',$this->order_initiation_date,true);
		$criteria->compare('last_updated_date',$this->last_updated_date,true);
		$criteria->compare('order_initiated_by',$this->order_initiated_by);
		$criteria->compare('order_updated_by',$this->order_updated_by);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Order the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
