<?php

/**
 * This is the model class for table "resources".
 *
 * The followings are the available columns in table 'resources':
 * @property integer $id
 * @property integer $resourcetype_id
 * @property string $product_id
 * @property string $name
 * @property string $description
 * @property string $text
 * @property integer $parent_id
 * @property integer $level
 * @property string $url
 * @property string $domain_id
 * @property integer $original_tool_id
 * @property integer $duplicate
 * @property string $icon
 * @property string $filename
 * @property string $poster
 * @property string $zipped_filename
 * @property string $full_media_filename
 * @property string $index_html
 * @property string $html5_demo_file
 * @property string $demo_file_homepage
 * @property integer $video_size
 * @property integer $demo_size
 * @property integer $icon_size
 * @property integer $handholding_size
 * @property integer $poster_size
 * @property integer $select_value
 * @property integer $islocation_based
 * @property integer $isFirst_consumption
 * @property string $consumption_startime
 * @property string $consumption_endtime
 * @property string $consumer_id
 * @property integer $consumption_frequency
 * @property string $first_consumption_date
 * @property string $last_consumption_date
 * @property integer $number_of_consumption
 * @property double $price
 * @property integer $min_subscription_required
 * @property integer $min_discountable_number
 * @property integer $enforce_min_discountable_number
 * @property double $discount_rate
 * @property integer $discount_proof
 * @property double $percentage_share
 * @property integer $respect_task_percentage_share
 * @property integer $respect_share_but_could_squeeze_in
 * @property integer $enforce_equal_share
 * @property integer $reconstruct_tool
 * @property integer $also_serve_as_preview
 * @property integer $downloadable_by_owner_users
 * @property integer $downloadable_by_non_owner_users
 * @property integer $is_duplicate
 * @property integer $cumulative_component_price
 * @property integer $price_preference
 * @property string $document_number
 * @property string $document_status
 * @property string $document_processed_date
 * @property integer $enforce_validation
 * @property string $file_number
 * @property string $file_location
 * @property string $file_room_number
 * @property string $cabinet_shelf_number
 * @property string $cabinet_shelf_row_number
 * @property string $cabinet_shelf_column_number
 * @property integer $file_position_from_right
 * @property integer $file_position_from_left
 * @property string $create_time
 * @property integer $create_user_id
 * @property string $update_time
 * @property integer $update_user_id
 * @property string $document_expiry_date
 * @property integer $is_destroyed
 * @property integer $current_document_holder
 * @property integer $is_destruction_accepted_by_initiator
 * @property integer $is_destruction_accepted_by_domain_verifier
 * @property integer $is_destruction_accepted_by_platform_checker
 * @property integer $is_destruction_accepted_by_platform_verifier
 * @property integer $destruction_initiator_user_id
 * @property integer $destruction_domain_verifier_user_id
 * @property integer $destruction_platform_checker_user_id
 * @property integer $destruction_platform_verifier_user_id
 * @property integer $initiate_expiry_date_extension_for_close_to_expiry_doc
 * @property integer $document_expiry_date_extended_by
 * @property integer $extended_document_expiry_date_verified_by
 * @property string $tentative_document_new_expiry_date
 * @property integer $expired_document_expiry_date_changed_by
 * @property integer initiate_expired_document_expiry_date_change
 * @property integer $changed_expired_document_expiry_date_verified_by
 * @property integer $initiate_removal_of_soft_document
 * @property integer $confirmed_removal_of_soft_document
 * @property integer $checked_confirmed_removal_of_soft_document
 * 
 * The followings are the available model relations:
 * @property Announcements[] $announcements
 * @property DuplicateToolHasTask[] $duplicateToolHasTasks
 * @property DuplicateToolHasTask[] $duplicateToolHasTasks1
 * @property MediaHasKeywords[] $mediaHasKeywords
 * @property Resourcegroup[] $resourcegroups
 * @property Products $product
 * @property Resources $parent
 * @property Resources[] $resources
 * @property TaskToTask[] $taskToTasks
 * @property TaskToTask[] $taskToTasks1
 * @property TaskToTask[] $taskToTasks2
 * @property TaskToTask[] $taskToTasks3
 * @property ToolHasTask[] $toolHasTasks
 * @property ToolHasTask[] $toolHasTasks1
 * @property User[] $users
 * @property UserHasNeed[] $userHasNeeds
 * @property UserHasNeed[] $userHasNeeds1
 * @property Wishes[] $wishes
 */
class Resources extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'resources';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('product_id, name, domain_id', 'required'),
			array('resourcetype_id, parent_id, level, original_tool_id, duplicate, video_size, demo_size, icon_size, handholding_size, poster_size, select_value, islocation_based, isFirst_consumption, consumption_frequency, number_of_consumption, min_subscription_required, min_discountable_number, enforce_min_discountable_number, discount_proof, respect_task_percentage_share, respect_share_but_could_squeeze_in, enforce_equal_share, reconstruct_tool, also_serve_as_preview, downloadable_by_owner_users, downloadable_by_non_owner_users, is_duplicate, cumulative_component_price, price_preference, enforce_validation, file_position_from_right, file_position_from_left, create_user_id, update_user_id', 'numerical', 'integerOnly'=>true),
			array('price, discount_rate, percentage_share', 'numerical'),
			array('product_id, domain_id', 'length', 'max'=>10),
			array('name, url, icon, document_number, file_number, file_room_number, cabinet_shelf_number, cabinet_shelf_row_number, cabinet_shelf_column_number', 'length', 'max'=>100),
			array('description', 'length', 'max'=>150),
			array('text', 'length', 'max'=>250),
			array('filename, poster, zipped_filename, full_media_filename, index_html, html5_demo_file, demo_file_homepage', 'length', 'max'=>60),
			array('document_status', 'length', 'max'=>16),
			array('file_location', 'length', 'max'=>200),
			array('consumption_startime, consumption_endtime, consumer_id, first_consumption_date, last_consumption_date, create_time, update_time', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, resourcetype_id, product_id, name, description, text, parent_id, level, url, domain_id, original_tool_id, duplicate, icon, filename, poster, zipped_filename, full_media_filename, index_html, html5_demo_file, demo_file_homepage, video_size, demo_size, icon_size, handholding_size, poster_size, select_value, islocation_based, isFirst_consumption, consumption_startime, consumption_endtime, consumer_id, consumption_frequency, first_consumption_date, last_consumption_date, number_of_consumption, price, min_subscription_required, min_discountable_number, enforce_min_discountable_number, discount_rate, discount_proof, percentage_share, respect_task_percentage_share, respect_share_but_could_squeeze_in, enforce_equal_share, reconstruct_tool, also_serve_as_preview, downloadable_by_owner_users, downloadable_by_non_owner_users, is_duplicate, cumulative_component_price, price_preference, document_number, document_status, enforce_validation, file_number, file_location, file_room_number, cabinet_shelf_number, cabinet_shelf_row_number, cabinet_shelf_column_number, file_position_from_right, file_position_from_left, create_time, create_user_id, update_time, update_user_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'announcements' => array(self::MANY_MANY, 'Announcements', 'tool_has_announcements(resource_id, announcement_id)'),
			'duplicateToolHasTasks' => array(self::HAS_MANY, 'DuplicateToolHasTask', 'tool_id'),
			'duplicateToolHasTasks1' => array(self::HAS_MANY, 'DuplicateToolHasTask', 'task_id'),
			'mediaHasKeywords' => array(self::HAS_MANY, 'MediaHasKeywords', 'media_id'),
			'resourcegroups' => array(self::MANY_MANY, 'Resourcegroup', 'resource_has_resourcegroups(resource_id, resourcegroup_id)'),
			'product' => array(self::BELONGS_TO, 'Products', 'product_id'),
			'parent' => array(self::BELONGS_TO, 'Resources', 'parent_id'),
			'resources' => array(self::HAS_MANY, 'Resources', 'parent_id'),
			'taskToTasks' => array(self::HAS_MANY, 'TaskToTask', 'master_tool_id'),
			'taskToTasks1' => array(self::HAS_MANY, 'TaskToTask', 'slave_id'),
			'taskToTasks2' => array(self::HAS_MANY, 'TaskToTask', 'master_id'),
			'taskToTasks3' => array(self::HAS_MANY, 'TaskToTask', 'slave_tool_id'),
			'toolHasTasks' => array(self::HAS_MANY, 'ToolHasTask', 'task_id'),
			'toolHasTasks1' => array(self::HAS_MANY, 'ToolHasTask', 'tool_id'),
			'users' => array(self::MANY_MANY, 'User', 'user_has_favourites(resource_id, user_id)'),
			'userHasNeeds' => array(self::HAS_MANY, 'UserHasNeed', 'tool_id'),
			'userHasNeeds1' => array(self::HAS_MANY, 'UserHasNeed', 'need_id'),
			'wishes' => array(self::HAS_MANY, 'Wishes', 'resource_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'resourcetype_id' => 'Resourcetype',
			'product_id' => 'Product',
			'name' => 'Name',
			'description' => 'Description',
			'text' => 'Text',
			'parent_id' => 'Parent',
			'level' => 'Level',
			'url' => 'Url',
			'domain_id' => 'Domain',
			'original_tool_id' => 'Original Tool',
			'duplicate' => 'Duplicate',
			'icon' => 'Icon',
			'filename' => 'Filename',
			'poster' => 'Poster',
			'zipped_filename' => 'Zipped Filename',
			'full_media_filename' => 'Full Media Filename',
			'index_html' => 'Index Html',
			'html5_demo_file' => 'Html5 Demo File',
			'demo_file_homepage' => 'Demo File Homepage',
			'video_size' => 'Video Size',
			'demo_size' => 'Demo Size',
			'icon_size' => 'Icon Size',
			'handholding_size' => 'Handholding Size',
			'poster_size' => 'Poster Size',
			'select_value' => 'Select Value',
			'islocation_based' => 'Islocation Based',
			'isFirst_consumption' => 'Is First Consumption',
			'consumption_startime' => 'Consumption Startime',
			'consumption_endtime' => 'Consumption Endtime',
			'consumer_id' => 'Consumer',
			'consumption_frequency' => 'Consumption Frequency',
			'first_consumption_date' => 'First Consumption Date',
			'last_consumption_date' => 'Last Consumption Date',
			'number_of_consumption' => 'Number Of Consumption',
			'price' => 'Price',
			'min_subscription_required' => 'Min Subscription Required',
			'min_discountable_number' => 'Min Discountable Number',
			'enforce_min_discountable_number' => 'Enforce Min Discountable Number',
			'discount_rate' => 'Discount Rate',
			'discount_proof' => 'Discount Proof',
			'percentage_share' => 'Percentage Share',
			'respect_task_percentage_share' => 'Respect Task Percentage Share',
			'respect_share_but_could_squeeze_in' => 'Respect Share But Could Squeeze In',
			'enforce_equal_share' => 'Enforce Equal Share',
			'reconstruct_tool' => 'Reconstruct Tool',
			'also_serve_as_preview' => 'Also Serve As Preview',
			'downloadable_by_owner_users' => 'Downloadable By Owner Users',
			'downloadable_by_non_owner_users' => 'Downloadable By Non Owner Users',
			'is_duplicate' => 'Is Duplicate',
			'cumulative_component_price' => 'Cumulative Component Price',
			'price_preference' => 'Price Preference',
			'document_number' => 'Document Number',
			'document_status' => 'Document Status',
			'enforce_validation' => 'Enforce Validation',
			'file_number' => 'File Number',
			'file_location' => 'File Location',
			'file_room_number' => 'File Room Number',
			'cabinet_shelf_number' => 'Cabinet Shelf Number',
			'cabinet_shelf_row_number' => 'Cabinet Shelf Row Number',
			'cabinet_shelf_column_number' => 'Cabinet Shelf Column Number',
			'file_position_from_right' => 'File Position From Right',
			'file_position_from_left' => 'File Position From Left',
			'create_time' => 'Create Time',
			'create_user_id' => 'Create User',
			'update_time' => 'Update Time',
			'update_user_id' => 'Update User',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id);
		$criteria->compare('resourcetype_id',$this->resourcetype_id);
		$criteria->compare('product_id',$this->product_id,true);
		$criteria->compare('name',$this->name,true);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('text',$this->text,true);
		$criteria->compare('parent_id',$this->parent_id);
		$criteria->compare('level',$this->level);
		$criteria->compare('url',$this->url,true);
		$criteria->compare('domain_id',$this->domain_id,true);
		$criteria->compare('original_tool_id',$this->original_tool_id);
		$criteria->compare('duplicate',$this->duplicate);
		$criteria->compare('icon',$this->icon,true);
		$criteria->compare('filename',$this->filename,true);
		$criteria->compare('poster',$this->poster,true);
		$criteria->compare('zipped_filename',$this->zipped_filename,true);
		$criteria->compare('full_media_filename',$this->full_media_filename,true);
		$criteria->compare('index_html',$this->index_html,true);
		$criteria->compare('html5_demo_file',$this->html5_demo_file,true);
		$criteria->compare('demo_file_homepage',$this->demo_file_homepage,true);
		$criteria->compare('video_size',$this->video_size);
		$criteria->compare('demo_size',$this->demo_size);
		$criteria->compare('icon_size',$this->icon_size);
		$criteria->compare('handholding_size',$this->handholding_size);
		$criteria->compare('poster_size',$this->poster_size);
		$criteria->compare('select_value',$this->select_value);
		$criteria->compare('islocation_based',$this->islocation_based);
		$criteria->compare('isFirst_consumption',$this->isFirst_consumption);
		$criteria->compare('consumption_startime',$this->consumption_startime,true);
		$criteria->compare('consumption_endtime',$this->consumption_endtime,true);
		$criteria->compare('consumer_id',$this->consumer_id,true);
		$criteria->compare('consumption_frequency',$this->consumption_frequency);
		$criteria->compare('first_consumption_date',$this->first_consumption_date,true);
		$criteria->compare('last_consumption_date',$this->last_consumption_date,true);
		$criteria->compare('number_of_consumption',$this->number_of_consumption);
		$criteria->compare('price',$this->price);
		$criteria->compare('min_subscription_required',$this->min_subscription_required);
		$criteria->compare('min_discountable_number',$this->min_discountable_number);
		$criteria->compare('enforce_min_discountable_number',$this->enforce_min_discountable_number);
		$criteria->compare('discount_rate',$this->discount_rate);
		$criteria->compare('discount_proof',$this->discount_proof);
		$criteria->compare('percentage_share',$this->percentage_share);
		$criteria->compare('respect_task_percentage_share',$this->respect_task_percentage_share);
		$criteria->compare('respect_share_but_could_squeeze_in',$this->respect_share_but_could_squeeze_in);
		$criteria->compare('enforce_equal_share',$this->enforce_equal_share);
		$criteria->compare('reconstruct_tool',$this->reconstruct_tool);
		$criteria->compare('also_serve_as_preview',$this->also_serve_as_preview);
		$criteria->compare('downloadable_by_owner_users',$this->downloadable_by_owner_users);
		$criteria->compare('downloadable_by_non_owner_users',$this->downloadable_by_non_owner_users);
		$criteria->compare('is_duplicate',$this->is_duplicate);
		$criteria->compare('cumulative_component_price',$this->cumulative_component_price);
		$criteria->compare('price_preference',$this->price_preference);
		$criteria->compare('document_number',$this->document_number,true);
		$criteria->compare('document_status',$this->document_status,true);
		$criteria->compare('enforce_validation',$this->enforce_validation);
		$criteria->compare('file_number',$this->file_number,true);
		$criteria->compare('file_location',$this->file_location,true);
		$criteria->compare('file_room_number',$this->file_room_number,true);
		$criteria->compare('cabinet_shelf_number',$this->cabinet_shelf_number,true);
		$criteria->compare('cabinet_shelf_row_number',$this->cabinet_shelf_row_number,true);
		$criteria->compare('cabinet_shelf_column_number',$this->cabinet_shelf_column_number,true);
		$criteria->compare('file_position_from_right',$this->file_position_from_right);
		$criteria->compare('file_position_from_left',$this->file_position_from_left);
		$criteria->compare('create_time',$this->create_time,true);
		$criteria->compare('create_user_id',$this->create_user_id);
		$criteria->compare('update_time',$this->update_time,true);
		$criteria->compare('update_user_id',$this->update_user_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Resources the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
