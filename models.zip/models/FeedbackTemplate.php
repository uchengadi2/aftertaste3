<?php

/**
 * This is the model class for table "feedback_template".
 *
 * The followings are the available columns in table 'feedback_template':
 * @property string $id
 * @property string $template_name
 * @property string $template_label
 * @property string $code_id
 * @property string $first_feedback_type
 * @property string $first_feedback_question
 * @property string $first_feedback_description
 * @property string $first_feedback_name
 * @property integer $is_first_feedback_included
 * @property string $first_feedback_purpose
 * @property string $second_feedback_type
 * @property string $second_feedback_question
 * @property string $second_feedback_description
 * @property string $second_feedback_purpose
 * @property string $second_feedback_name
 * @property integer $is_second_feedback_included
 * @property string $third_feedback_type
 * @property string $third_feedback_question
 * @property string $third_feedback_description
 * @property string $third_feedback_purpose
 * @property string $third_feedback_name
 * @property integer $is_third_feedback_included
 * @property string $fourth_feedback_type
 * @property string $fourth_feedback_question
 * @property string $fourth_feedback_description
 * @property string $fourth_feedback_purpose
 * @property string $fourth_feedback_name
 * @property integer $is_fourth_feedback_included
 * @property string $fifth_feedback_type
 * @property string $fifth_feedback_question
 * @property string $fifth_feedback_description
 * @property string $fifth_feedback_purpose
 * @property string $fifth_feedback_name
 * @property integer $is_fifth_feedback_included
 * @property string $status
 * @property integer $is_ussd_active
 * @property integer $maximum_feedback_required
 * @property integer $is_feedback_before_authenticity
 * @property integer $is_multiple_feedback_responses_allowed
 * @property string $first_feedback_single_option
 * @property string $first_feedback_multiple_option
 * @property string $first_feedback_single_option_number
 * @property string $first_feedback_multiple_option_number
 * @property string $second_feedback_single_option
 * @property string $second_feedback_multiple_option
 * @property string $second_feedback_single_option_number
 * @property string $second_feedback_multiple_option_number
 * @property string $third_feedback_single_option
 * @property string $third_feedback_multiple_option
 * @property string $third_feedback_single_option_number
 * @property string $third_feedback_multiple_option_number
 * @property string $fourth_feedback_single_option
 * @property string $fourth_feedback_multiple_option
 * @property string $fourth_feedback_single_option_number
 * @property string $fourth_feedback_multiple_option_number
 * @property string $fifth_feedback_single_option
 * @property string $fifth_feedback_multiple_option
 * @property string $fifth_feedback_single_option_number
 * @property string $fifth_feedback_multiple_option_number
 */
class FeedbackTemplate extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'feedback_template';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('code_id, status', 'required'),
			array('is_first_feedback_included, is_second_feedback_included, is_third_feedback_included, is_fourth_feedback_included, is_fifth_feedback_included, is_ussd_active, maximum_feedback_required, is_feedback_before_authenticity, is_multiple_feedback_responses_allowed', 'numerical', 'integerOnly'=>true),
			array('template_name, template_label, first_feedback_question, first_feedback_description, first_feedback_name, second_feedback_question, second_feedback_description, second_feedback_name, third_feedback_question, third_feedback_description, third_feedback_name, fourth_feedback_question, fourth_feedback_description, fourth_feedback_name, fifth_feedback_question, fifth_feedback_description, fifth_feedback_name, first_feedback_single_option_number, first_feedback_multiple_option_number, second_feedback_single_option_number, second_feedback_multiple_option_number, third_feedback_single_option_number, third_feedback_multiple_option_number, fourth_feedback_single_option_number, fourth_feedback_multiple_option_number, fifth_feedback_single_option_number, fifth_feedback_multiple_option_number', 'length', 'max'=>250),
			array('code_id', 'length', 'max'=>10),
			array('first_feedback_type, second_feedback_type, third_feedback_type, fourth_feedback_type, fifth_feedback_type', 'length', 'max'=>22),
			array('first_feedback_purpose, second_feedback_purpose, third_feedback_purpose, fourth_feedback_purpose, fifth_feedback_purpose', 'length', 'max'=>24),
			array('status', 'length', 'max'=>8),
			array('first_feedback_single_option, first_feedback_multiple_option, second_feedback_single_option, second_feedback_multiple_option, third_feedback_single_option, third_feedback_multiple_option, fourth_feedback_single_option, fourth_feedback_multiple_option, fifth_feedback_single_option, fifth_feedback_multiple_option', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, template_name, template_label, code_id, first_feedback_type, first_feedback_question, first_feedback_description, first_feedback_name, is_first_feedback_included, first_feedback_purpose, second_feedback_type, second_feedback_question, second_feedback_description, second_feedback_purpose, second_feedback_name, is_second_feedback_included, third_feedback_type, third_feedback_question, third_feedback_description, third_feedback_purpose, third_feedback_name, is_third_feedback_included, fourth_feedback_type, fourth_feedback_question, fourth_feedback_description, fourth_feedback_purpose, fourth_feedback_name, is_fourth_feedback_included, fifth_feedback_type, fifth_feedback_question, fifth_feedback_description, fifth_feedback_purpose, fifth_feedback_name, is_fifth_feedback_included, status, is_ussd_active, maximum_feedback_required, is_feedback_before_authenticity, is_multiple_feedback_responses_allowed, first_feedback_single_option, first_feedback_multiple_option, first_feedback_single_option_number, first_feedback_multiple_option_number, second_feedback_single_option, second_feedback_multiple_option, second_feedback_single_option_number, second_feedback_multiple_option_number, third_feedback_single_option, third_feedback_multiple_option, third_feedback_single_option_number, third_feedback_multiple_option_number, fourth_feedback_single_option, fourth_feedback_multiple_option, fourth_feedback_single_option_number, fourth_feedback_multiple_option_number, fifth_feedback_single_option, fifth_feedback_multiple_option, fifth_feedback_single_option_number, fifth_feedback_multiple_option_number', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'template_name' => 'Template Name',
			'template_label' => 'Template Label',
			'code_id' => 'Code',
			'first_feedback_type' => 'First Feedback Type',
			'first_feedback_question' => 'First Feedback Question',
			'first_feedback_description' => 'First Feedback Description',
			'first_feedback_name' => 'First Feedback Name',
			'is_first_feedback_included' => 'Is First Feedback Included',
			'first_feedback_purpose' => 'First Feedback Purpose',
			'second_feedback_type' => 'Second Feedback Type',
			'second_feedback_question' => 'Second Feedback Question',
			'second_feedback_description' => 'Second Feedback Description',
			'second_feedback_purpose' => 'Second Feedback Purpose',
			'second_feedback_name' => 'Second Feedback Name',
			'is_second_feedback_included' => 'Is Second Feedback Included',
			'third_feedback_type' => 'Third Feedback Type',
			'third_feedback_question' => 'Third Feedback Question',
			'third_feedback_description' => 'Third Feedback Description',
			'third_feedback_purpose' => 'Third Feedback Purpose',
			'third_feedback_name' => 'Third Feedback Name',
			'is_third_feedback_included' => 'Is Third Feedback Included',
			'fourth_feedback_type' => 'Fourth Feedback Type',
			'fourth_feedback_question' => 'Fourth Feedback Question',
			'fourth_feedback_description' => 'Fourth Feedback Description',
			'fourth_feedback_purpose' => 'Fourth Feedback Purpose',
			'fourth_feedback_name' => 'Fourth Feedback Name',
			'is_fourth_feedback_included' => 'Is Fourth Feedback Included',
			'fifth_feedback_type' => 'Fifth Feedback Type',
			'fifth_feedback_question' => 'Fifth Feedback Question',
			'fifth_feedback_description' => 'Fifth Feedback Description',
			'fifth_feedback_purpose' => 'Fifth Feedback Purpose',
			'fifth_feedback_name' => 'Fifth Feedback Name',
			'is_fifth_feedback_included' => 'Is Fifth Feedback Included',
			'status' => 'Status',
			'is_ussd_active' => 'Is Ussd Active',
			'maximum_feedback_required' => 'Maximum Feedback Required',
			'is_feedback_before_authenticity' => 'Is Feedback Before Authenticity',
			'is_multiple_feedback_responses_allowed' => 'Is Multiple Feedback Responses Allowed',
			'first_feedback_single_option' => 'First Feedback Single Option',
			'first_feedback_multiple_option' => 'First Feedback Multiple Option',
			'first_feedback_single_option_number' => 'First Feedback Single Option Number',
			'first_feedback_multiple_option_number' => 'First Feedback Multiple Option Number',
			'second_feedback_single_option' => 'Second Feedback Single Option',
			'second_feedback_multiple_option' => 'Second Feedback Multiple Option',
			'second_feedback_single_option_number' => 'Second Feedback Single Option Number',
			'second_feedback_multiple_option_number' => 'Second Feedback Multiple Option Number',
			'third_feedback_single_option' => 'Third Feedback Single Option',
			'third_feedback_multiple_option' => 'Third Feedback Multiple Option',
			'third_feedback_single_option_number' => 'Third Feedback Single Option Number',
			'third_feedback_multiple_option_number' => 'Third Feedback Multiple Option Number',
			'fourth_feedback_single_option' => 'Fourth Feedback Single Option',
			'fourth_feedback_multiple_option' => 'Fourth Feedback Multiple Option',
			'fourth_feedback_single_option_number' => 'Fourth Feedback Single Option Number',
			'fourth_feedback_multiple_option_number' => 'Fourth Feedback Multiple Option Number',
			'fifth_feedback_single_option' => 'Fifth Feedback Single Option',
			'fifth_feedback_multiple_option' => 'Fifth Feedback Multiple Option',
			'fifth_feedback_single_option_number' => 'Fifth Feedback Single Option Number',
			'fifth_feedback_multiple_option_number' => 'Fifth Feedback Multiple Option Number',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('template_name',$this->template_name,true);
		$criteria->compare('template_label',$this->template_label,true);
		$criteria->compare('code_id',$this->code_id,true);
		$criteria->compare('first_feedback_type',$this->first_feedback_type,true);
		$criteria->compare('first_feedback_question',$this->first_feedback_question,true);
		$criteria->compare('first_feedback_description',$this->first_feedback_description,true);
		$criteria->compare('first_feedback_name',$this->first_feedback_name,true);
		$criteria->compare('is_first_feedback_included',$this->is_first_feedback_included);
		$criteria->compare('first_feedback_purpose',$this->first_feedback_purpose,true);
		$criteria->compare('second_feedback_type',$this->second_feedback_type,true);
		$criteria->compare('second_feedback_question',$this->second_feedback_question,true);
		$criteria->compare('second_feedback_description',$this->second_feedback_description,true);
		$criteria->compare('second_feedback_purpose',$this->second_feedback_purpose,true);
		$criteria->compare('second_feedback_name',$this->second_feedback_name,true);
		$criteria->compare('is_second_feedback_included',$this->is_second_feedback_included);
		$criteria->compare('third_feedback_type',$this->third_feedback_type,true);
		$criteria->compare('third_feedback_question',$this->third_feedback_question,true);
		$criteria->compare('third_feedback_description',$this->third_feedback_description,true);
		$criteria->compare('third_feedback_purpose',$this->third_feedback_purpose,true);
		$criteria->compare('third_feedback_name',$this->third_feedback_name,true);
		$criteria->compare('is_third_feedback_included',$this->is_third_feedback_included);
		$criteria->compare('fourth_feedback_type',$this->fourth_feedback_type,true);
		$criteria->compare('fourth_feedback_question',$this->fourth_feedback_question,true);
		$criteria->compare('fourth_feedback_description',$this->fourth_feedback_description,true);
		$criteria->compare('fourth_feedback_purpose',$this->fourth_feedback_purpose,true);
		$criteria->compare('fourth_feedback_name',$this->fourth_feedback_name,true);
		$criteria->compare('is_fourth_feedback_included',$this->is_fourth_feedback_included);
		$criteria->compare('fifth_feedback_type',$this->fifth_feedback_type,true);
		$criteria->compare('fifth_feedback_question',$this->fifth_feedback_question,true);
		$criteria->compare('fifth_feedback_description',$this->fifth_feedback_description,true);
		$criteria->compare('fifth_feedback_purpose',$this->fifth_feedback_purpose,true);
		$criteria->compare('fifth_feedback_name',$this->fifth_feedback_name,true);
		$criteria->compare('is_fifth_feedback_included',$this->is_fifth_feedback_included);
		$criteria->compare('status',$this->status,true);
		$criteria->compare('is_ussd_active',$this->is_ussd_active);
		$criteria->compare('maximum_feedback_required',$this->maximum_feedback_required);
		$criteria->compare('is_feedback_before_authenticity',$this->is_feedback_before_authenticity);
		$criteria->compare('is_multiple_feedback_responses_allowed',$this->is_multiple_feedback_responses_allowed);
		$criteria->compare('first_feedback_single_option',$this->first_feedback_single_option,true);
		$criteria->compare('first_feedback_multiple_option',$this->first_feedback_multiple_option,true);
		$criteria->compare('first_feedback_single_option_number',$this->first_feedback_single_option_number,true);
		$criteria->compare('first_feedback_multiple_option_number',$this->first_feedback_multiple_option_number,true);
		$criteria->compare('second_feedback_single_option',$this->second_feedback_single_option,true);
		$criteria->compare('second_feedback_multiple_option',$this->second_feedback_multiple_option,true);
		$criteria->compare('second_feedback_single_option_number',$this->second_feedback_single_option_number,true);
		$criteria->compare('second_feedback_multiple_option_number',$this->second_feedback_multiple_option_number,true);
		$criteria->compare('third_feedback_single_option',$this->third_feedback_single_option,true);
		$criteria->compare('third_feedback_multiple_option',$this->third_feedback_multiple_option,true);
		$criteria->compare('third_feedback_single_option_number',$this->third_feedback_single_option_number,true);
		$criteria->compare('third_feedback_multiple_option_number',$this->third_feedback_multiple_option_number,true);
		$criteria->compare('fourth_feedback_single_option',$this->fourth_feedback_single_option,true);
		$criteria->compare('fourth_feedback_multiple_option',$this->fourth_feedback_multiple_option,true);
		$criteria->compare('fourth_feedback_single_option_number',$this->fourth_feedback_single_option_number,true);
		$criteria->compare('fourth_feedback_multiple_option_number',$this->fourth_feedback_multiple_option_number,true);
		$criteria->compare('fifth_feedback_single_option',$this->fifth_feedback_single_option,true);
		$criteria->compare('fifth_feedback_multiple_option',$this->fifth_feedback_multiple_option,true);
		$criteria->compare('fifth_feedback_single_option_number',$this->fifth_feedback_single_option_number,true);
		$criteria->compare('fifth_feedback_multiple_option_number',$this->fifth_feedback_multiple_option_number,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return FeedbackTemplate the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        /**
         * This is the function that confirms if a template name had already been used for a service point
         */
        public function isThisTemplateNameAlreadyUsed($code_id,$template_name){
             $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('feedback_template')
                    ->where("code_id = $code_id and template_name ='$template_name'");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        /**
         * This is the function that retrieves the name of a feedback
         */
        public function getThisFeedbackTemplateName($id){
            $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';   
             $criteria->params = array(':id'=>$id);
             $template = FeedbackTemplate::model()->find($criteria);
             
             return $template['template_name'];
        }
        
        
       /**
        * This is the function that deactivates a feedback template
        */
        public function isTheDeactivationOfThisTemplateASuccess($id){
           $model= FeedbackTemplate::model()->findByPk($id);
           
           $model->status = "inactive";
           if($model->save()){
               return true;
           }else{
               return false;
           }
                   
        }
        
        
         /**
        * This is the function that disables a ussed feedback template
        */
        public function isTheDisablingOfThisUssdTemplateASuccess($id){
           $model= FeedbackTemplate::model()->findByPk($id);
           
           $model->is_ussd_active = 0;
           if($model->save()){
               return true;
           }else{
               return false;
           }
                   
        }
        
        
        /**
         * This is the function that verifies if an issue type is analyzable
         */
        public function isIssueTypeAnalyzable($feedback_type){
            if($feedback_type == "text"){
                return false;
                
            }else{
                return true;
            }
        }
        
        
         /*
         * This is the function that gets total number of a text-based  single options
         */
        public function getTheTotalNumberOfQuestionOptions($options){
            
          $sliced_options = explode("+",$options);
          return sizeof($sliced_options);
        }
        
        
       /*
         * This is the function that gets the array of this text-based single option
         */
        public function getTheArrayOfTheQuestionOptions($options){
           $sliced_options = explode("+",$options);
           if($this->getTheTotalNumberOfQuestionOptions($options)>$this->getTheMaxOptionListingLimit()){
               for ( $i = 0, $c = sizeof($sliced_options); $i < $c; $i++ ) {
                 $sliced_options[$i] = [$sliced_options[$i]];
                }
                return $sliced_options;
           }else{
               return $sliced_options;
           }
           
        }
        
        
        
       /*
         * This is the function that gets the total number of a number-based  multiple options
         */
        public function getTheTotalNumberOfNumericQuestionOptions($options){
            $sliced_options = explode(",",$options);
            return sizeof($sliced_options);
          
        }
        
        
        
         /*
         * This is the function that gets the array of this number-based single option
       */
        public function getTheArrayOfTheNumericQuestionOptions($options){
           
           $sliced_options = explode(",",$options);
             if($this->getTheArrayOfTheQuestionOptions($options)>$this->getTheMaxOptionListingLimit()){
                 for ( $i = 0, $c = sizeof($sliced_options); $i < $c; $i++ ) {
                    $sliced_options[$i] = [$sliced_options[$i]];
                }
                return $sliced_options;
             }else{
                 return $sliced_options;
             }
        }
        
        
        /**
         * This is the function that specifies the maximum listing limit of options
         */
        public function getTheMaxOptionListingLimit(){
            return 5;
        }
        
        
         /**
         * This is the function that registers feedback options
         */
        public function isRegisteringTheOptionsASuccess($pmodel,$first_question_number,$second_question_number,$third_question_number,$fourth_question_number,$fifth_question_number){
            $model = new FeedbackTemplateOptions;
            $counter =0;
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';   
             $criteria->params = array(':id'=>$pmodel->id);
             $template = FeedbackTemplate::model()->find($criteria);
             
             if($this->isThisFeedbackWithOptions($template)){
                 
                 //addressing the first feedback question
              if($template['is_first_feedback_included'] == 1){
                 if($this->isFirstFeedbackWithOptions($template['first_feedback_type'])){
                     //register this feedback
                     if($template['first_feedback_type'] =='single_option'){
                         $model->registerFeedbackOption($template['id'],$template['first_feedback_single_option'],$template['first_feedback_type'],$first_question_number);
                     }else if($template['first_feedback_type'] =='multiple_option'){
                         $model->registerFeedbackOption($template['id'],$template['first_feedback_multiple_option'],$template['first_feedback_type'],$first_question_number);
                     }else if($template['first_feedback_type'] =='single_option_number'){
                         $model->registerFeedbackOption($template['id'],$template['first_feedback_single_option_number'],$template['first_feedback_type'],$first_question_number);
                     }else if($template['first_feedback_type'] =='multiple_option_number'){
                         $model->registerFeedbackOption($template['id'],$template['first_feedback_multiple_option_number'],$template['first_feedback_type'],$first_question_number);
                     }
                     
                 }
                $counter = $counter + 1;
             }
             
             //addressing the second feedback question
              if($template['is_second_feedback_included'] == 1){
                 if($this->isSecondFeedbackWithOptions($template['second_feedback_type'])){
                       //register this feedback
                    if($template['second_feedback_type'] =='single_option'){
                         $model->registerFeedbackOption($template['id'],$template['second_feedback_single_option'],$template['second_feedback_type'],$second_question_number);
                     }else if($template['second_feedback_type'] =='multiple_option'){
                         $model->registerFeedbackOption($template['id'],$template['second_feedback_multiple_option'],$template['second_feedback_type'],$second_question_number);
                     }else if($template['second_feedback_type'] =='single_option_number'){
                         $model->registerFeedbackOption($template['id'],$template['second_feedback_single_option_number'],$template['second_feedback_type'],$second_question_number);
                     }else if($template['second_feedback_type'] =='multiple_option_number'){
                         $model->registerFeedbackOption($template['id'],$template['second_feedback_multiple_option_number'],$template['second_feedback_type'],$second_question_number);
                     }
                   }
                   $counter = $counter + 1;
                 
             }
             
              //addressing the third feedback question
             
            if($template['is_third_feedback_included'] == 1){
                 if($this->isThirdFeedbackWithOptions($template['third_feedback_type'])){
                     //register this feedback
                    if($template['third_feedback_type'] =='single_option'){
                         $model->registerFeedbackOption($template['id'],$template['third_feedback_single_option'],$template['third_feedback_type'],$third_question_number);
                     }else if($template['third_feedback_type'] =='multiple_option'){
                         $model->registerFeedbackOption($template['id'],$template['third_feedback_multiple_option'],$template['third_feedback_type'],$third_question_number);
                     }else if($template['third_feedback_type'] =='single_option_number'){
                         $model->registerFeedbackOption($template['id'],$template['third_feedback_single_option_number'],$template['third_feedback_type'],$third_question_number);
                     }else if($template['third_feedback_type'] =='multiple_option_number'){
                         $model->registerFeedbackOption($template['id'],$template['third_feedback_multiple_option_number'],$template['third_feedback_type'],$third_question_number);
                     }
                }
                 $counter = $counter + 1;
             }
             
              //addressing the fourth feedback question
             if($template['is_fourth_feedback_included'] == 1){
                 if($this->isFourthFeedbackWithOptions($template['fourth_feedback_type'])){
                     //register this feedback
                    if($template['fourth_feedback_type'] =='single_option'){
                         $model->registerFeedbackOption($template['id'],$template['fourth_feedback_single_option'],$template['fourth_feedback_type'],$fourth_question_number);
                     }else if($template['fourth_feedback_type'] =='multiple_option'){
                         $model->registerFeedbackOption($template['id'],$template['fourth_feedback_multiple_option'],$template['fourth_feedback_type'],$fourth_question_number);
                     }else if($template['fourth_feedback_type'] =='single_option_number'){
                         $model->registerFeedbackOption($template['id'],$template['fourth_feedback_single_option_number'],$template['fourth_feedback_type'],$fourth_question_number);
                     }else if($template['fourth_feedback_type'] =='multiple_option_number'){
                         $model->registerFeedbackOption($template['id'],$template['fourth_feedback_multiple_option_number'],$template['fourth_feedback_type'],$fourth_question_number);
                     }
                }
                 $counter = $counter + 1;
             }
             
             
             //addressing the fifth feedback question
             
                if($template['is_fifth_feedback_included'] == 1){
                    if($this->isFifthFeedbackWithOptions($template['fifth_feedback_type'])){
                     //register this feedback
                    if($template['fifth_feedback_type'] =='single_option'){
                         $model->registerFeedbackOption($template['id'],$template['fifth_feedback_single_option'],$template['fifth_feedback_type'].$fifth_question_number);
                     }else if($template['fifth_feedback_type'] =='multiple_option'){
                         $model->registerFeedbackOption($template['id'],$template['fifth_feedback_multiple_option'],$template['fifth_feedback_type'],$fifth_question_number);
                     }else if($template['fifth_feedback_type'] =='single_option_number'){
                         $model->registerFeedbackOption($template['id'],$template['fifth_feedback_single_option_number'],$template['fifth_feedback_type'],$fifth_question_number);
                     }else if($template['fifth_feedback_type'] =='multiple_option_number'){
                         $model->registerFeedbackOption($template['id'],$template['fifth_feedback_multiple_option_number'],$template['fifth_feedback_type'],$fifth_question_number);
                     }
                }
                  $counter = $counter + 1; 
             }
             
             if($counter>0){
                 return true;
             }else{
                 return false;
             }
                 
             }else{
                 return true;
                 
             }
             
       
             
        }
        
        
        /**
         * This is the function that determines if a feedback is with options
         */
        public function isThisFeedbackWithOptions($template){
           if($template['is_first_feedback_included'] == 1){
               if($this->isFirstFeedbackWithOptions($template['first_feedback_type'])){
                   return true;
               }
           }else if($template['is_second_feedback_included']==1){
               if($this->isSecondFeedbackWithOptions($template['second_feedback_type'])){
                   return true;
               }
           }else if($template['is_third_feedback_included'] == 1){
               if($this->isThirdFeedbackWithOptions($template['third_feedback_type'])){
                   return true;
               }
           }else if($template['is_fourth_feedback_included'] == 1){
               if($this->isFourthFeedbackWithOptions($template['fourth_feedback_type'])){
                   return true;
               }
           }else if($template['is_fifth_feedback_included'] == 1){
                if($this->isFifthFeedbackWithOptions($template['fifth_feedback_type'])){
                   return true;
               }
           }
            return false;
        }
        
        
        /**
         * This is the function that confirms if the first feedback is with options
         */
        public function isFirstFeedbackWithOptions($feedback_type){
            if($feedback_type =="single_option"){
                return true;
            }else if($feedback_type =="multiple_option"){
                return true;
            }else if($feedback_type == "single_option_number"){
                return true;
            }else if($feedback_type == "multiple_option_number"){
                return true;
            }else{
                return false;
            }
        }
        
        
         /**
         * This is the function that confirms if the second feedback is with options
         */
        public function isSecondFeedbackWithOptions($feedback_type){
            if($feedback_type =="single_option"){
                return true;
            }else if($feedback_type =="multiple_option"){
                return true;
            }else if($feedback_type == "single_option_number"){
                return true;
            }else if($feedback_type == "multiple_option_number"){
                return true;
            }else{
                return false;
            }
        }
        
        
           /**
         * This is the function that confirms if the third feedback is with options
         */
        public function isThirdFeedbackWithOptions($feedback_type){
            if($feedback_type =="single_option"){
                return true;
            }else if($feedback_type =="multiple_option"){
                return true;
            }else if($feedback_type == "single_option_number"){
                return true;
            }else if($feedback_type == "multiple_option_number"){
                return true;
            }else{
                return false;
            }
        }
        
        
           /**
         * This is the function that confirms if the fourth feedback is with options
         */
        public function isFourthFeedbackWithOptions($feedback_type){
            if($feedback_type =="single_option"){
                return true;
            }else if($feedback_type =="multiple_option"){
                return true;
            }else if($feedback_type == "single_option_number"){
                return true;
            }else if($feedback_type == "multiple_option_number"){
                return true;
            }else{
                return false;
            }
        }
        
        
        
        /**
         * This is the function that confirms if the fifth feedback is with options
         */
        public function isFifthFeedbackWithOptions($feedback_type){
            if($feedback_type =="single_option"){
                return true;
            }else if($feedback_type =="multiple_option"){
                return true;
            }else if($feedback_type == "single_option_number"){
                return true;
            }else if($feedback_type == "multiple_option_number"){
                return true;
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the function that updates feedback options registeration
         */
        public function isUpdatingTheseOptionsRegisteringASuccess($pmodel){
            $model = new FeedbackTemplateOptions;
            $counter =0;
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';   
             $criteria->params = array(':id'=>$pmodel->id);
             $template = FeedbackTemplate::model()->find($criteria);
             
             if($this->isThisFeedbackWithOptions($template)){
                 
                 //addressing the first feedback question
              if($template['is_first_feedback_included'] == 1){
                 if($this->isFirstFeedbackWithOptions($template['first_feedback_type'])){
                     //register this feedback
                     if($template['first_feedback_type'] =='single_option'){
                         $model->updateFeedbackFeedbackOptionRegisteration($template['id'],$template['first_feedback_single_option'],$template['first_feedback_type']);
                     }else if($template['first_feedback_type'] =='multiple_option'){
                         $model->updateFeedbackFeedbackOptionRegisteration($template['id'],$template['first_feedback_multiple_option'],$template['first_feedback_type']);
                     }else if($template['first_feedback_type'] =='single_option_number'){
                         $model->updateFeedbackFeedbackOptionRegisteration($template['id'],$template['first_feedback_single_option_number'],$template['first_feedback_type']);
                     }else if($template['first_feedback_type'] =='multiple_option_number'){
                         $model->updateFeedbackFeedbackOptionRegisteration($template['id'],$template['first_feedback_multiple_option_number'],$template['first_feedback_type']);
                     }
                     
                 }
                $counter = $counter + 1;
             }
             
             //addressing the second feedback question
              if($template['is_second_feedback_included'] == 1){
                 if($this->isSecondFeedbackWithOptions($template['second_feedback_type'])){
                       //register this feedback
                    if($template['second_feedback_type'] =='single_option'){
                         $model->updateFeedbackFeedbackOptionRegisteration($template['id'],$template['second_feedback_single_option'],$template['second_feedback_type']);
                     }else if($template['second_feedback_type'] =='multiple_option'){
                         $model->updateFeedbackFeedbackOptionRegisteration($template['id'],$template['second_feedback_multiple_option'],$template['second_feedback_type']);
                     }else if($template['second_feedback_type'] =='single_option_number'){
                         $model->updateFeedbackFeedbackOptionRegisteration($template['id'],$template['second_feedback_single_option_number'],$template['second_feedback_type']);
                     }else if($template['second_feedback_type'] =='multiple_option_number'){
                         $model->updateFeedbackFeedbackOptionRegisteration($template['id'],$template['second_feedback_multiple_option_number'],$template['second_feedback_type']);
                     }
                   }
                   $counter = $counter + 1;
                 
             }
             
              //addressing the third feedback question
             
            if($template['is_third_feedback_included'] == 1){
                 if($this->isThirdFeedbackWithOptions($template['third_feedback_type'])){
                     //register this feedback
                    if($template['third_feedback_type'] =='single_option'){
                         $model->updateFeedbackFeedbackOptionRegisteration($template['id'],$template['third_feedback_single_option'],$template['third_feedback_type']);
                     }else if($template['third_feedback_type'] =='multiple_option'){
                         $model->updateFeedbackFeedbackOptionRegisteration($template['id'],$template['third_feedback_multiple_option'],$template['third_feedback_type']);
                     }else if($template['third_feedback_type'] =='single_option_number'){
                         $model->updateFeedbackFeedbackOptionRegisteration($template['id'],$template['third_feedback_single_option_number'],$template['third_feedback_type']);
                     }else if($template['third_feedback_type'] =='multiple_option_number'){
                         $model->updateFeedbackFeedbackOptionRegisteration($template['id'],$template['third_feedback_multiple_option_number'],$template['third_feedback_type']);
                     }
                }
                 $counter = $counter + 1;
             }
             
              //addressing the fourth feedback question
             if($template['is_fourth_feedback_included'] == 1){
                 if($this->isFourthFeedbackWithOptions($template['fourth_feedback_type'])){
                     //register this feedback
                    if($template['fourth_feedback_type'] =='single_option'){
                         $model->updateFeedbackFeedbackOptionRegisteration($template['id'],$template['fourth_feedback_single_option'],$template['fourth_feedback_type']);
                     }else if($template['fourth_feedback_type'] =='multiple_option'){
                         $model->updateFeedbackFeedbackOptionRegisteration($template['id'],$template['fourth_feedback_multiple_option'],$template['fourth_feedback_type']);
                     }else if($template['fourth_feedback_type'] =='single_option_number'){
                         $model->updateFeedbackFeedbackOptionRegisteration($template['id'],$template['fourth_feedback_single_option_number'],$template['fourth_feedback_type']);
                     }else if($template['fourth_feedback_type'] =='multiple_option_number'){
                         $model->updateFeedbackFeedbackOptionRegisteration($template['id'],$template['fourth_feedback_multiple_option_number'],$template['fourth_feedback_type']);
                     }
                }
                 $counter = $counter + 1;
             }
             
             
             //addressing the fifth feedback question
             
                if($template['is_fifth_feedback_included'] == 1){
                    if($this->isFifthFeedbackWithOptions($template['fifth_feedback_type'])){
                     //register this feedback
                    if($template['fifth_feedback_type'] =='single_option'){
                         $model->updateFeedbackFeedbackOptionRegisteration($template['id'],$template['fifth_feedback_single_option'],$template['fifth_feedback_type']);
                     }else if($template['fifth_feedback_type'] =='multiple_option'){
                         $model->updateFeedbackFeedbackOptionRegisteration($template['id'],$template['fifth_feedback_multiple_option'],$template['fifth_feedback_type']);
                     }else if($template['fifth_feedback_type'] =='single_option_number'){
                         $model->updateFeedbackFeedbackOptionRegisteration($template['id'],$template['fifth_feedback_single_option_number'],$template['fifth_feedback_type']);
                     }else if($template['fifth_feedback_type'] =='multiple_option_number'){
                         $model->updateFeedbackFeedbackOptionRegisteration($template['id'],$template['fifth_feedback_multiple_option_number'],$template['fifth_feedback_type']);
                     }
                }
                  $counter = $counter + 1; 
             }
             
             if($counter>0){
                 return true;
             }else{
                 return false;
             }
                 
             }else{
                 return true;
                 
             }
            
        }
        
        
        /**
         * This is the function that retrieves a template issue
         */
        public function retrievethistemplateissueType($template_id,$issue_code){
           
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$template_id);
            $template= FeedbackTemplate::model()->find($criteria);
            
            //write a script to limit template to only analyzable issues. Also retrieve the issue types
            
            if($issue_code == 1){
                if($this->isIssueTypeAnalyzable($template['first_feedback_type'])){
                    $issue = $template['first_feedback_question'];
                    $issue_type = $template['first_feedback_type'];
                }else{
                    $issue="";
                    $issue_type = $template['first_feedback_type'];
                }
                
            }else if($issue_code == 2){
                 if($this->isIssueTypeAnalyzable($template['second_feedback_type'])){
                     $issue = $template['second_feedback_question'];
                     $issue_type = $template['second_feedback_type'];
                 }else{
                     $issue="";
                     $issue_type = $template['second_feedback_type'];
                 }
                
            }else if($issue_code == 3){
                if($this->isIssueTypeAnalyzable($template['third_feedback_type'])){
                    $issue = $template['third_feedback_question'];
                    $issue_type = $template['third_feedback_type'];
                }else{
                     $issue="";
                     $issue_type = $template['third_feedback_type'];
                }
                
            }else if($issue_code == 4){
                if($this->isIssueTypeAnalyzable($template['fourth_feedback_type'])){
                    $issue = $template['fourth_feedback_question'];
                    $issue_type = $template['fourth_feedback_type'];
                }else{
                     $issue="";
                     $issue_type = $template['fourth_feedback_type'];
                }
                
            }else if($issue_code == 5){
                if($this->isIssueTypeAnalyzable($template['fifth_feedback_type'])){
                    $issue = $template['fifth_feedback_question'];
                    $issue_type = $template['fifth_feedback_type'];
                }else{
                     $issue="";
                     $issue_type = $template['fifth_feedback_type'];
                }
                
            }else{
                $issue="";
                $issue_type ="";
            }
             return $issue_type;
            
        }
        
        
        /**
         * This is the question that retrieves all the questions in a template without question one
         */
        public function getAllTheQuestionsInATemplateWithoutQuestionOne($template_id){
            $data = [];
            //retrieve the second question
             $q = "select id, second_feedback_question as question from feedback_template Where (id=$template_id)";
                                 
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                  if($res['question'] != null){
                     $data[] = $res;
                 }
             }
             
                       
            //retrieve the third question
            $q = "select id, third_feedback_question as question from feedback_template Where (id=$template_id)";
                                 
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 if($res['question'] != null){
                     $data[] = $res;
                 }
             }
            
            //retrieve the fourth question
            $q = "select id, fourth_feedback_question as question from feedback_template Where (id=$template_id)";
                                 
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                  if($res['question'] != null){
                     $data[] = $res;
                 }
             }
             
            //retrieve the fifth question
           $q = "select id, fifth_feedback_question as question from feedback_template Where (id=$template_id)";
                                 
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                if($res['question'] != null){
                     $data[] = $res;
                 }
                 
             }
            
            return $data;
        }
        
        
        /**
         * This is the question that retrieves all the questions in a template without question two
         */
        public function getAllTheQuestionsInATemplateWithoutQuestionTwo($template_id){
            $data = [];
            //retrieve the first question
             $q = "select id, first_feedback_question as question from feedback_template Where (id=$template_id)";
             
                                 
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 // if($res['question'] != NULL){
                     $data[] = $res;
                 //}
             }
             
                       
            //retrieve the third question
            $q = "select id, third_feedback_question as question from feedback_template Where (id=$template_id)";
                                 
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                  if($res['question'] != NULL){
                     $data[] = $res;
                 }
             }
            
            //retrieve the fourth question
            $q = "select id, fourth_feedback_question as question from feedback_template Where (id=$template_id)";
                                 
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                  if($res['question'] != NULL){
                     $data[] = $res;
                 }
             }
             
            //retrieve the fifth question
           $q = "select id, fifth_feedback_question as question from feedback_template Where (id=$template_id)";
                                 
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 if($res['question'] != NULL){
                     $data[] = $res;
                 }
                 
             }
            
            return $data;
        }
        
        
         /**
         * This is the question that retrieves all the questions in a template without question three
         */
        public function getAllTheQuestionsInATemplateWithoutQuestionThree($template_id){
            $data = [];
            //retrieve the first question
             $q = "select id, first_feedback_question as question from feedback_template Where (id=$template_id)";
                                 
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                  if($res['question'] != NULL){
                     $data[] = $res;
                 }
             }
             
                       
            //retrieve the second question
            $q = "select id, second_feedback_question as question from feedback_template Where (id=$template_id)";
                                 
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                  if($res['question'] != NULL){
                     $data[] = $res;
                 }
             }
            
            //retrieve the fourth question
            $q = "select id, fourth_feedback_question as question from feedback_template Where (id=$template_id)";
                                 
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                  if($res['question'] != NULL){
                     $data[] = $res;
                 }
             }
             
            //retrieve the fifth question
           $q = "select id, fifth_feedback_question as question from feedback_template Where (id=$template_id)";
                                 
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 if($res['question'] != NULL){
                     $data[] = $res;
                 }
                 
             }
            
            return $data;
        }
        
        
         /**
         * This is the question that retrieves all the questions in a template without question four
         */
        public function getAllTheQuestionsInATemplateWithoutQuestionFour($template_id){
            $data = [];
            //retrieve the first question
             $q = "select id, first_feedback_question as question from feedback_template Where (id=$template_id)";
                                 
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                  if($res['question'] != NULL){
                     $data[] = $res;
                 }
             }
             
                       
            //retrieve the second question
            $q = "select id, second_feedback_question as question from feedback_template Where (id=$template_id)";
                                 
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                  if($res['question'] != NULL){
                     $data[] = $res;
                 }
             }
            
            //retrieve the third question
            $q = "select id, third_feedback_question as question from feedback_template Where (id=$template_id)";
                                 
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                  if($res['question'] != NULL){
                     $data[] = $res;
                 }
             }
             
            //retrieve the fifth question
           $q = "select id, fifth_feedback_question as question from feedback_template Where (id=$template_id)";
                                 
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 if($res['question'] != NULL){
                     $data[] = $res;
                 }
                 
             }
            
            return $data;
        }
        
        
        /**
         * This is the question that retrieves all the questions in a template without question five
         */
        public function getAllTheQuestionsInATemplateWithoutQuestionFive($template_id){
            $data = [];
            //retrieve the first question
             $q = "select id, first_feedback_question as question from feedback_template Where (id=$template_id)";
                                 
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                  if($res['question'] != NULL){
                     $data[] = $res;
                 }
             }
             
                       
            //retrieve the second question
            $q = "select id, second_feedback_question as question from feedback_template Where (id=$template_id)";
                                 
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                  if($res['question'] != NULL){
                     $data[] = $res;
                 }
             }
            
            //retrieve the third question
            $q = "select id, third_feedback_question as question from feedback_template Where (id=$template_id)";
                                 
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                  if($res['question'] != NULL){
                     $data[] = $res;
                 }
             }
             
            //retrieve the fourth question
           $q = "select id, fourth_feedback_question as question from feedback_template Where (id=$template_id)";
                                 
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 if($res['question'] != NULL){
                     $data[] = $res;
                 }
                 
             }
            
            return $data;
        }
        
}
