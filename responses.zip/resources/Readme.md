# ext-theme-neptune-a13a2704-fd28-4a54-bb1e-72ce785c5e14/resources

This folder contains static resources (typically an `"images"` folder as well).
