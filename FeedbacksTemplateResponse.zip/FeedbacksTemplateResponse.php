<?php

/**
 * This is the model class for table "feedbacks_template_response".
 *
 * The followings are the available columns in table 'feedbacks_template_response':
 * @property string $id
 * @property string $template_id
 * @property integer $user_id
 * @property integer $first_feedback_response_boolean
 * @property string $first_feedback_response_text
 * @property integer $first_feedback_response_integer
 * @property double $first_feedback_response_double
 * @property integer $second_feedback_response_boolean
 * @property string $second_feedback_response_text
 * @property integer $second_feedback_response_integer
 * @property double $second_feedback_response_double
 * @property integer $third_feedback_response_boolean
 * @property string $third_feedback_response_text
 * @property integer $third_feedback_response_integer
 * @property double $third_feedback_response_double
 * @property integer $fourth_feedback_response_boolean
 * @property string $fourth_feedback_response_text
 * @property integer $fourth_feedback_response_integer
 * @property double $fourth_feedback_response_double
 * @property integer $fifth_feedback_response_boolean
 * @property string $fifth_feedback_response_text
 * @property integer $fifth_feedback_response_integer
 * @property double $fifth_feedback_response_double
 * @property string $date_provided
 * @property string $first_feedback_response_single_option
 * @property string $first_feedback_response_single_option_number
 * @property string $first_feedback_response_multiple_option
 * @property string $first_feedback_response_multiple_option_number
 * @property string $second_feedback_response_single_option
 * @property string $second_feedback_response_single_option_number
 * @property string $second_feedback_response_multiple_option
 * @property string $second_feedback_response_multiple_option_number
 * @property string $third_feedback_response_single_option
 * @property string $third_feedback_response_single_option_number
 * @property string $third_feedback_response_multiple_option
 * @property string $third_feedback_response_multiple_option_number
 * @property string $fourth_feedback_response_single_option
 * @property string $fourth_feedback_response_single_option_number
 * @property string $fourth_feedback_response_multiple_option
 * @property string $fourth_feedback_response_multiple_option_number
 * @property string $fifth_feedback_response_single_option
 * @property string $fifth_feedback_response_single_option_number
 * @property string $fifth_feedback_response_multiple_option
 * @property string $fifth_feedback_response_multiple_option_number
 */
class FeedbacksTemplateResponse extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'feedbacks_template_response';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('template_id', 'required'),
			array('user_id, first_feedback_response_boolean, first_feedback_response_integer, second_feedback_response_boolean, second_feedback_response_integer, third_feedback_response_boolean, third_feedback_response_integer, fourth_feedback_response_boolean, fourth_feedback_response_integer, fifth_feedback_response_boolean, fifth_feedback_response_integer', 'numerical', 'integerOnly'=>true),
			array('first_feedback_response_double, second_feedback_response_double, third_feedback_response_double, fourth_feedback_response_double, fifth_feedback_response_double', 'numerical'),
			array('template_id', 'length', 'max'=>10),
			array('first_feedback_response_single_option, first_feedback_response_single_option_number, first_feedback_response_multiple_option, first_feedback_response_multiple_option_number, second_feedback_response_single_option, second_feedback_response_single_option_number, second_feedback_response_multiple_option, second_feedback_response_multiple_option_number, third_feedback_response_single_option, third_feedback_response_single_option_number, third_feedback_response_multiple_option, third_feedback_response_multiple_option_number, fourth_feedback_response_single_option, fourth_feedback_response_single_option_number, fourth_feedback_response_multiple_option, fourth_feedback_response_multiple_option_number', 'length', 'max'=>250),
			array('first_feedback_response_text, second_feedback_response_text, third_feedback_response_text, fourth_feedback_response_text, fifth_feedback_response_text, date_provided, fifth_feedback_response_single_option, fifth_feedback_response_single_option_number, fifth_feedback_response_multiple_option, fifth_feedback_response_multiple_option_number', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, template_id, user_id, first_feedback_response_boolean, first_feedback_response_text, first_feedback_response_integer, first_feedback_response_double, second_feedback_response_boolean, second_feedback_response_text, second_feedback_response_integer, second_feedback_response_double, third_feedback_response_boolean, third_feedback_response_text, third_feedback_response_integer, third_feedback_response_double, fourth_feedback_response_boolean, fourth_feedback_response_text, fourth_feedback_response_integer, fourth_feedback_response_double, fifth_feedback_response_boolean, fifth_feedback_response_text, fifth_feedback_response_integer, fifth_feedback_response_double, date_provided, first_feedback_response_single_option, first_feedback_response_single_option_number, first_feedback_response_multiple_option, first_feedback_response_multiple_option_number, second_feedback_response_single_option, second_feedback_response_single_option_number, second_feedback_response_multiple_option, second_feedback_response_multiple_option_number, third_feedback_response_single_option, third_feedback_response_single_option_number, third_feedback_response_multiple_option, third_feedback_response_multiple_option_number, fourth_feedback_response_single_option, fourth_feedback_response_single_option_number, fourth_feedback_response_multiple_option, fourth_feedback_response_multiple_option_number, fifth_feedback_response_single_option, fifth_feedback_response_single_option_number, fifth_feedback_response_multiple_option, fifth_feedback_response_multiple_option_number', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'template_id' => 'Template',
			'user_id' => 'User',
			'first_feedback_response_boolean' => 'First Feedback Response Boolean',
			'first_feedback_response_text' => 'First Feedback Response Text',
			'first_feedback_response_integer' => 'First Feedback Response Integer',
			'first_feedback_response_double' => 'First Feedback Response Double',
			'second_feedback_response_boolean' => 'Second Feedback Response Boolean',
			'second_feedback_response_text' => 'Second Feedback Response Text',
			'second_feedback_response_integer' => 'Second Feedback Response Integer',
			'second_feedback_response_double' => 'Second Feedback Response Double',
			'third_feedback_response_boolean' => 'Third Feedback Response Boolean',
			'third_feedback_response_text' => 'Third Feedback Response Text',
			'third_feedback_response_integer' => 'Third Feedback Response Integer',
			'third_feedback_response_double' => 'Third Feedback Response Double',
			'fourth_feedback_response_boolean' => 'Fourth Feedback Response Boolean',
			'fourth_feedback_response_text' => 'Fourth Feedback Response Text',
			'fourth_feedback_response_integer' => 'Fourth Feedback Response Integer',
			'fourth_feedback_response_double' => 'Fourth Feedback Response Double',
			'fifth_feedback_response_boolean' => 'Fifth Feedback Response Boolean',
			'fifth_feedback_response_text' => 'Fifth Feedback Response Text',
			'fifth_feedback_response_integer' => 'Fifth Feedback Response Integer',
			'fifth_feedback_response_double' => 'Fifth Feedback Response Double',
			'date_provided' => 'Date Provided',
			'first_feedback_response_single_option' => 'First Feedback Response Single Option',
			'first_feedback_response_single_option_number' => 'First Feedback Response Single Option Number',
			'first_feedback_response_multiple_option' => 'First Feedback Response Multiple Option',
			'first_feedback_response_multiple_option_number' => 'First Feedback Response Multiple Option Number',
			'second_feedback_response_single_option' => 'Second Feedback Response Single Option',
			'second_feedback_response_single_option_number' => 'Second Feedback Response Single Option Number',
			'second_feedback_response_multiple_option' => 'Second Feedback Response Multiple Option',
			'second_feedback_response_multiple_option_number' => 'Second Feedback Response Multiple Option Number',
			'third_feedback_response_single_option' => 'Third Feedback Response Single Option',
			'third_feedback_response_single_option_number' => 'Third Feedback Response Single Option Number',
			'third_feedback_response_multiple_option' => 'Third Feedback Response Multiple Option',
			'third_feedback_response_multiple_option_number' => 'Third Feedback Response Multiple Option Number',
			'fourth_feedback_response_single_option' => 'Fourth Feedback Response Single Option',
			'fourth_feedback_response_single_option_number' => 'Fourth Feedback Response Single Option Number',
			'fourth_feedback_response_multiple_option' => 'Fourth Feedback Response Multiple Option',
			'fourth_feedback_response_multiple_option_number' => 'Fourth Feedback Response Multiple Option Number',
			'fifth_feedback_response_single_option' => 'Fifth Feedback Response Single Option',
			'fifth_feedback_response_single_option_number' => 'Fifth Feedback Response Single Option Number',
			'fifth_feedback_response_multiple_option' => 'Fifth Feedback Response Multiple Option',
			'fifth_feedback_response_multiple_option_number' => 'Fifth Feedback Response Multiple Option Number',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('template_id',$this->template_id,true);
		$criteria->compare('user_id',$this->user_id);
		$criteria->compare('first_feedback_response_boolean',$this->first_feedback_response_boolean);
		$criteria->compare('first_feedback_response_text',$this->first_feedback_response_text,true);
		$criteria->compare('first_feedback_response_integer',$this->first_feedback_response_integer);
		$criteria->compare('first_feedback_response_double',$this->first_feedback_response_double);
		$criteria->compare('second_feedback_response_boolean',$this->second_feedback_response_boolean);
		$criteria->compare('second_feedback_response_text',$this->second_feedback_response_text,true);
		$criteria->compare('second_feedback_response_integer',$this->second_feedback_response_integer);
		$criteria->compare('second_feedback_response_double',$this->second_feedback_response_double);
		$criteria->compare('third_feedback_response_boolean',$this->third_feedback_response_boolean);
		$criteria->compare('third_feedback_response_text',$this->third_feedback_response_text,true);
		$criteria->compare('third_feedback_response_integer',$this->third_feedback_response_integer);
		$criteria->compare('third_feedback_response_double',$this->third_feedback_response_double);
		$criteria->compare('fourth_feedback_response_boolean',$this->fourth_feedback_response_boolean);
		$criteria->compare('fourth_feedback_response_text',$this->fourth_feedback_response_text,true);
		$criteria->compare('fourth_feedback_response_integer',$this->fourth_feedback_response_integer);
		$criteria->compare('fourth_feedback_response_double',$this->fourth_feedback_response_double);
		$criteria->compare('fifth_feedback_response_boolean',$this->fifth_feedback_response_boolean);
		$criteria->compare('fifth_feedback_response_text',$this->fifth_feedback_response_text,true);
		$criteria->compare('fifth_feedback_response_integer',$this->fifth_feedback_response_integer);
		$criteria->compare('fifth_feedback_response_double',$this->fifth_feedback_response_double);
		$criteria->compare('date_provided',$this->date_provided,true);
		$criteria->compare('first_feedback_response_single_option',$this->first_feedback_response_single_option,true);
		$criteria->compare('first_feedback_response_single_option_number',$this->first_feedback_response_single_option_number,true);
		$criteria->compare('first_feedback_response_multiple_option',$this->first_feedback_response_multiple_option,true);
		$criteria->compare('first_feedback_response_multiple_option_number',$this->first_feedback_response_multiple_option_number,true);
		$criteria->compare('second_feedback_response_single_option',$this->second_feedback_response_single_option,true);
		$criteria->compare('second_feedback_response_single_option_number',$this->second_feedback_response_single_option_number,true);
		$criteria->compare('second_feedback_response_multiple_option',$this->second_feedback_response_multiple_option,true);
		$criteria->compare('second_feedback_response_multiple_option_number',$this->second_feedback_response_multiple_option_number,true);
		$criteria->compare('third_feedback_response_single_option',$this->third_feedback_response_single_option,true);
		$criteria->compare('third_feedback_response_single_option_number',$this->third_feedback_response_single_option_number,true);
		$criteria->compare('third_feedback_response_multiple_option',$this->third_feedback_response_multiple_option,true);
		$criteria->compare('third_feedback_response_multiple_option_number',$this->third_feedback_response_multiple_option_number,true);
		$criteria->compare('fourth_feedback_response_single_option',$this->fourth_feedback_response_single_option,true);
		$criteria->compare('fourth_feedback_response_single_option_number',$this->fourth_feedback_response_single_option_number,true);
		$criteria->compare('fourth_feedback_response_multiple_option',$this->fourth_feedback_response_multiple_option,true);
		$criteria->compare('fourth_feedback_response_multiple_option_number',$this->fourth_feedback_response_multiple_option_number,true);
		$criteria->compare('fifth_feedback_response_single_option',$this->fifth_feedback_response_single_option,true);
		$criteria->compare('fifth_feedback_response_single_option_number',$this->fifth_feedback_response_single_option_number,true);
		$criteria->compare('fifth_feedback_response_multiple_option',$this->fifth_feedback_response_multiple_option,true);
		$criteria->compare('fifth_feedback_response_multiple_option_number',$this->fifth_feedback_response_multiple_option_number,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return FeedbacksTemplateResponse the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
       /**
        * This is the function that confirms if the maximum limit of feedback reponses in a template is reached
        */
        public function isFeedbackResponseLimitReached($maximum_feedback_required,$template_id){
            if(is_numeric($maximum_feedback_required)){
              $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('feedbacks_template_response')
                    ->where("template_id = $template_id");
                $result = $cmd->queryScalar();
                
                if($result<$maximum_feedback_required){
                    return false;
                }else{
                    return true;
                }
                
            }else{
                return false;
            }
        }
        
        /**
         * This is the function that confirms if a uer is legible to send a feedback response
         */
        public function isThisUserLegibleToProvideFeedbackResponse($user_id,$template_id,$is_multiple_feedback_responses_allowed){
            if($is_multiple_feedback_responses_allowed != 1){
                if($this->hasUserProvidedThisFeedbackBefore($template_id,$user_id)){
                    return false;
                }else{
                    return true;
                }
                
            }else{
                return true;
            }
        }
        
        
         /**
         * This is the function that ascertains if a user had provided feedback on a code before
         */
        public function hasUserProvidedThisFeedbackBefore($template_id,$user_id){
             $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('feedbacks_template_response')
                    ->where("template_id = $template_id and user_id=$user_id");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        /**
         * This is the function that determines if a feedback template already has responses
         */
        public function isThisFeedbackTemplateAlreadyWithReponses($template_id){
             $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('feedbacks_template_response')
                    ->where("template_id = $template_id");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        /**
         * This is the function that registers a customers feedback response
         */
        public function isRegisteringTheResponseOptionsASuccess($pmodel){
            
             $model = new FeedbackTemplateOptionResponse;
            $counter =0;
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';   
             $criteria->params = array(':id'=>$pmodel->template_id);
             $template = FeedbackTemplate::model()->find($criteria);
             
             
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';   
             $criteria->params = array(':id'=>$pmodel->id);
             $response = FeedbacksTemplateResponse::model()->find($criteria);
             
             if($this->isThisFeedbackWithOptions($template)){
                 
                 //addressing the first feedback question
              if($template['is_first_feedback_included'] == 1){
                  $question_number=1;
                 if($this->isFirstFeedbackWithOptions($template['first_feedback_type'])){
                     //register this feedback
                     if($template['first_feedback_type'] =='single_option'){
                         $model->registerFeedbackOptionResponse($template['id'],$response['first_feedback_response_single_option'],$template['first_feedback_type'],$response['trans_refid'],$question_number);
                     }else if($template['first_feedback_type'] =='multiple_option'){
                         $model->registerFeedbackOptionResponse($template['id'],$response['first_feedback_response_multiple_option'],$template['first_feedback_type'],$response['trans_refid'],$question_number);
                     }else if($template['first_feedback_type'] =='single_option_number'){
                         $model->registerFeedbackOptionResponse($template['id'],$response['first_feedback_response_single_option_number'],$template['first_feedback_type'],$response['trans_refid'],$question_number);
                     }else if($template['first_feedback_type'] =='multiple_option_number'){
                         $model->registerFeedbackOptionResponse($template['id'],$response['first_feedback_response_multiple_option_number'],$template['first_feedback_type'],$response['trans_refid'],$question_number);
                     }
                     
                 }
                $counter = $counter + 1;
             }
             
             //addressing the second feedback question
              if($template['is_second_feedback_included'] == 1){
                  $question_number=2;
                 if($this->isSecondFeedbackWithOptions($template['second_feedback_type'])){
                       //register this feedback
                    if($template['second_feedback_type'] =='single_option'){
                         $model->registerFeedbackOptionResponse($template['id'],$response['second_feedback_response_single_option'],$template['second_feedback_type'],$response['trans_refid'],$question_number);
                     }else if($template['second_feedback_type'] =='multiple_option'){
                         $model->registerFeedbackOptionResponse($template['id'],$response['second_feedback_response_multiple_option'],$template['second_feedback_type'],$response['trans_refid'],$question_number);
                     }else if($template['second_feedback_type'] =='single_option_number'){
                         $model->registerFeedbackOptionResponse($template['id'],$response['second_feedback_response_single_option_number'],$template['second_feedback_type'],$response['trans_refid'],$question_number);
                     }else if($template['second_feedback_type'] =='multiple_option_number'){
                         $model->registerFeedbackOptionResponse($template['id'],$response['second_feedback_response_multiple_option_number'],$template['second_feedback_type'],$response['trans_refid'],$question_number);
                     }
                   }
                   $counter = $counter + 1;
                 
             }
             
              //addressing the third feedback question
             
            if($template['is_third_feedback_included'] == 1){
                $question_number=3;
                 if($this->isThirdFeedbackWithOptions($template['third_feedback_type'])){
                     //register this feedback
                    if($template['third_feedback_type'] =='single_option'){
                         $model->registerFeedbackOptionResponse($template['id'],$response['third_feedback_response_single_option'],$template['third_feedback_type'],$response['trans_refid'],$question_number);
                     }else if($template['third_feedback_type'] =='multiple_option'){
                         $model->registerFeedbackOptionResponse($template['id'],$response['third_feedback_response_multiple_option'],$template['third_feedback_type'],$response['trans_refid'],$question_number);
                     }else if($template['third_feedback_type'] =='single_option_number'){
                         $model->registerFeedbackOptionResponse($template['id'],$response['third_feedback_response_single_option_number'],$template['third_feedback_type'],$response['trans_refid'],$question_number);
                     }else if($template['third_feedback_type'] =='multiple_option_number'){
                         $model->registerFeedbackOptionResponse($template['id'],$response['third_feedback_response_multiple_option_number'],$template['third_feedback_type'],$response['trans_refid'],$question_number);
                     }
                }
                 $counter = $counter + 1;
             }
             
              //addressing the fourth feedback question
             if($template['is_fourth_feedback_included'] == 1){
                 $question_number=4;
                 if($this->isFourthFeedbackWithOptions($template['fourth_feedback_type'])){
                     //register this feedback
                    if($template['fourth_feedback_type'] =='single_option'){
                         $model->registerFeedbackOptionResponse($template['id'],$response['fourth_feedback_response_single_option'],$template['fourth_feedback_type'],$response['trans_refid'],$question_number);
                     }else if($template['fourth_feedback_type'] =='multiple_option'){
                         $model->registerFeedbackOptionResponse($template['id'],$response['fourth_feedback_response_multiple_option'],$template['fourth_feedback_type'],$response['trans_refid'],$question_number);
                     }else if($template['fourth_feedback_type'] =='single_option_number'){
                         $model->registerFeedbackOptionResponse($template['id'],$response['fourth_feedback_response_single_option_number'],$template['fourth_feedback_type'],$response['trans_refid'],$question_number);
                     }else if($template['fourth_feedback_type'] =='multiple_option_number'){
                         $model->registerFeedbackOptionResponse($template['id'],$response['fourth_feedback_response_multiple_option_number'],$template['fourth_feedback_type'],$response['trans_refid'],$question_number);
                     }
                }
                 $counter = $counter + 1;
             }
             
             
             //addressing the fifth feedback question
             
                if($template['is_fifth_feedback_included'] == 1){
                    $question_number=5;
                    if($this->isFifthFeedbackWithOptions($template['fifth_feedback_type'])){
                     //register this feedback
                    if($template['fifth_feedback_type'] =='single_option'){
                         $model->registerFeedbackOptionResponse($template['id'],$response['fifth_feedback_response_single_option'],$template['fifth_feedback_type'],$response['trans_refid'],$question_number);
                     }else if($template['fifth_feedback_type'] =='multiple_option'){
                         $model->registerFeedbackOptionResponse($template['id'],$response['fifth_feedback_response_multiple_option'],$template['fifth_feedback_type'],$response['trans_refid'],$question_number);
                     }else if($template['fifth_feedback_type'] =='single_option_number'){
                         $model->registerFeedbackOptionResponse($template['id'],$response['fifth_feedback_response_single_option_number'],$template['fifth_feedback_type'],$response['trans_refid'],$question_number);
                     }else if($template['fifth_feedback_type'] =='multiple_option_number'){
                         $model->registerFeedbackOptionResponse($template['id'],$response['fifth_feedback_response_multiple_option_number'],$template['fifth_feedback_type'],$response['trans_refid'],$question_number);
                     }
                }
                  $counter = $counter + 1; 
             }
             
             if($counter>0){
                 return true;
             }else{
                 return false;
             }
                 
             }else{
                 return true;
                 
             }
             
        }
        
        
        /**
         * This is the function that determines if a feedback is with options
         */
        public function isThisFeedbackWithOptions($template){
           if($template['is_first_feedback_included'] == 1){
               if($this->isFirstFeedbackWithOptions($template['first_feedback_type'])){
                   return true;
               }
           }else if($template['is_second_feedback_included']==1){
               if($this->isSecondFeedbackWithOptions($template['second_feedback_type'])){
                   return true;
               }
           }else if($template['is_third_feedback_included'] == 1){
               if($this->isThirdFeedbackWithOptions($template['third_feedback_type'])){
                   return true;
               }
           }else if($template['is_fourth_feedback_included'] == 1){
               if($this->isFourthFeedbackWithOptions($template['fourth_feedback_type'])){
                   return true;
               }
           }else if($template['is_fifth_feedback_included'] == 1){
                if($this->isFifthFeedbackWithOptions($template['fifth_feedback_type'])){
                   return true;
               }
           }
            return false;
        }
        
        
        /**
         * This is the function that confirms if the first feedback is with options
         */
        public function isFirstFeedbackWithOptions($feedback_type){
            if($feedback_type =="single_option"){
                return true;
            }else if($feedback_type =="multiple_option"){
                return true;
            }else if($feedback_type == "single_option_number"){
                return true;
            }else if($feedback_type == "multiple_option_number"){
                return true;
            }else{
                return false;
            }
        }
        
        
         /**
         * This is the function that confirms if the second feedback is with options
         */
        public function isSecondFeedbackWithOptions($feedback_type){
            if($feedback_type =="single_option"){
                return true;
            }else if($feedback_type =="multiple_option"){
                return true;
            }else if($feedback_type == "single_option_number"){
                return true;
            }else if($feedback_type == "multiple_option_number"){
                return true;
            }else{
                return false;
            }
        }
        
        
           /**
         * This is the function that confirms if the third feedback is with options
         */
        public function isThirdFeedbackWithOptions($feedback_type){
            if($feedback_type =="single_option"){
                return true;
            }else if($feedback_type =="multiple_option"){
                return true;
            }else if($feedback_type == "single_option_number"){
                return true;
            }else if($feedback_type == "multiple_option_number"){
                return true;
            }else{
                return false;
            }
        }
        
        
           /**
         * This is the function that confirms if the fourth feedback is with options
         */
        public function isFourthFeedbackWithOptions($feedback_type){
            if($feedback_type =="single_option"){
                return true;
            }else if($feedback_type =="multiple_option"){
                return true;
            }else if($feedback_type == "single_option_number"){
                return true;
            }else if($feedback_type == "multiple_option_number"){
                return true;
            }else{
                return false;
            }
        }
        
        
        
        /**
         * This is the function that confirms if the fifth feedback is with options
         */
        public function isFifthFeedbackWithOptions($feedback_type){
            if($feedback_type =="single_option"){
                return true;
            }else if($feedback_type =="multiple_option"){
                return true;
            }else if($feedback_type == "single_option_number"){
                return true;
            }else if($feedback_type == "multiple_option_number"){
                return true;
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the function that generates a reference id for a feedback
         */
        public function getTheReferenceIdForThisFeedbackResponse(){
            //get a random number from 1 to 10
                $random_number = $this->generateTheRandomNumber();
                $timestamp = time();
                $ref = "$timestamp$random_number";
                return $ref;
        }
        
        
        /**
             * This is the function that generates a random number
             */
            public function generateTheRandomNumber(){
                
                //get todays date
                $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                //generate random numbe from 0 to $today
                $random_number = mt_rand(0,$today);
               return $random_number;
            }
            
            
          
            
         /**
         * This is the function that confirms if a feedback is with options
         */
        public function isIssueTypeWithOptions($feedback_type){
            if($feedback_type =="single_option"){
                return true;
            }else if($feedback_type =="multiple_option"){
                return true;
            }else if($feedback_type == "single_option_number"){
                return true;
            }else if($feedback_type == "multiple_option_number"){
                return true;
            }else{
                return false;
            }
        }
        
        
        
         /**
         * This is the function that confirms if a feedback type is boolean
         */
        public function isIssueTypeBoolean($feedback_type){
            if($feedback_type =="boolean"){
                return true;
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the function that retreives option data responses for analysis
         */
        public function retrieveRelevantResponsesForEachOption($issue_type,$template_id,$question_number,$start_date,$end_date){
            $data = [];
            /**$q = "select b.option, count(c.response) as response from feedback_template_options b
                    JOIN feedback_template_option_response c ON b.option=c.response
                    Where (b.question_number=$question_number AND b.template_id=$template_id) AND (c.response_date between '$start_date' AND '$end_date')
                    group by b.option";
             * 
             */
            
            $q = "select b.response as `option`, count(c.response) as response from feedback_template_option_response b
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid 
                    Where (b.question_number=$question_number AND b.template_id=$template_id) AND (c.response_date between '$start_date' AND '$end_date') and 
                    b.option_id=c.option_id group by b.response order by b.option_id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
             return $data;
            
        }
        
        
        /**
        * This is the function that provides the total number of responses on a feedback question
        */
        public function getTheTotalResponseOnThisFeedbackIssue($issue_type,$template_id,$question_number,$start_date,$end_date){
           /** $q = "select count(c.response) as response from feedback_template_options b
                    JOIN feedback_template_option_response c ON b.option=c.response
                    Where (b.question_number=$question_number AND b.template_id=$template_id) AND (c.response_date between '$start_date' AND '$end_date')";
            * 
            */
            $q = "select count(c.response) as response from feedback_template_option_response b
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    Where (b.question_number=$question_number AND b.template_id=$template_id) AND (c.response_date between '$start_date' AND '$end_date') and b.option_id=c.option_id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
        }
        
        
        /**
         * This is the function that retrieves the total number of responses for each option in a feedback issue within a period
         */
        public function retrieveTheTotalNumberOfResponseForEachOption($issue_type,$template_id,$question_number,$start_date,$end_date){
             $data = [];
            $q = "select b.response as `option`, count(c.response) as response from feedback_template_option_response b
                    JOIN feedback_template_option_response c ON b.option_id=c.option_id
                    Where (b.question_number=$question_number AND b.template_id=$template_id) AND (c.response_date between '$start_date' AND '$end_date')
                    and b.trans_refid=c.trans_refid group by b.response";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
             return $data;
            
        }
        
        
        /**
         * This is the function that gets the total number of feedback available options
         */
        public function getTheTotalNumberOfFeedbackAvailableOptions($issue_type,$template_id,$question_number){
             $q = "select count(b.option)as response from feedback_template_options b
                    Where (b.question_number=$question_number AND b.template_id=$template_id)";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
        }
        
        
         /**
         * This is the function that retreives option data responses for analysis
         */
        public function retrieveRelevantConditionalResponsesForEachOptionWithNoConditional($issue_type,$template_id,$question_number,$start_date,$end_date){
            $data = [];
            $q = "select b.response as `option`,b.option_id as `id`, count(c.response) as response from feedback_template_option_response b
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    Where (b.question_number=$question_number AND b.template_id=$template_id) AND (c.response_date between '$start_date' AND '$end_date')
                    and b.option_id=c.option_id group by b.response";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
             return $data;
            
        }
        
        //addressing no variable conditionals
        
         /**
         * This is the function that retrieves the total number of responses for each option in a feedback issue within a period
         */
        public function retrieveTheTotalNumberOfConditionalResponseForEachOptionWithNoCondtions($issue_type,$template_id,$question_number,$start_date,$end_date){
             $data = [];
            $q = "select b.response as `option`, count(c.response) as response from feedback_template_option_response b
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    Where (b.question_number=$question_number AND b.template_id=$template_id) AND (c.response_date between '$start_date' AND '$end_date')
                    and b.option_id=c.option_id group by b.response";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
             return $data;
            
        }
        
        
        /**
        * This is the function that provides the total number of responses on a feedback question
        */
        public function getTheTotalConditionalResponseOnThisFeedbackIssueWithNoCondtions($issue_type,$template_id,$question_number,$start_date,$end_date){
            $q = "select count(c.response) as response from feedback_template_option_response b
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    Where (b.question_number=$question_number AND b.template_id=$template_id) AND (c.response_date between '$start_date' AND '$end_date') and b.option_id=c.option_id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
        }
        
        
        /**
         * This is the function that gets the total number of feedback available options
         */
        public function getTheTotalNumberOfFeedbackAvailableOptionsWithNoConditional($issue_type,$template_id,$question_number){
             $q = "select count(b.option)as response from feedback_template_options b
                    Where (b.question_number=$question_number AND b.template_id=$template_id)";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
        }
        
        
        /**
         * This is the function that gets the total feedback responses base on one condition
         */
        public function getTheTotalConditionalResponseOnThisFeedbackIssueWithOneCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value){
            $q = "select count(b.response) as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid 
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition b.response like '%$univariate_advance_first_independent_variable_value%') and
                    (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number)";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
        }
        
        //addressing one variable conditionals
        
        /**
         * This is the function that retrieves all feedback responses base on one condition
         */
        public function retrieveTheTotalNumberOfConditionalResponseForEachOptionWithOneCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value){
            
             $data = [];
            $q = "select a.option_id,a.response as `option`, count(b.response) as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid 
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition b.response like '%$univariate_advance_first_independent_variable_value%') and
                    (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number) group by a.response";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
             return $data;
        }
        
        /**
         * This is the function that gets the total number of available feedback responses base on one condition
         */
        public function getTheTotalNumberOfFeedbackAvailableOptionsWithOneConditional($issue_type,$template_id,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value){
            
             $q = "select count(b.response) as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid 
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition b.response like '%$univariate_advance_first_independent_variable_value%')";
                       
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
            
        }
        
        
         /**
         * This is the function that retrieves all feedback responses base on one condition
         */
        public function retrieveRelevantConditionalResponsesForEachOptionWithOneConditional($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value){
            
             $data = [];
            $q = "select a.response as `option`, count(b.response) as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid 
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition b.response like '%$univariate_advance_first_independent_variable_value%') and
                    (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number) group by a.response";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
             return $data;
        }
        
        //addressing two variable conditionals
        
        /**
         * This is the function that gets the total number of available feedback responses base on two condition
         */
        public function getTheTotalConditionalResponseOnThisFeedbackIssueWithTwoCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value){
            
             $q = "select count(b.response) as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid 
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')and 
                    (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number)";
                       
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
            
        }
        
        
         /**
         * This is the function that retrieves all feedback responses base on two condition
         */
        public function retrieveTheTotalNumberOfConditionalResponseForEachOptionWithTwoCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value){
            
             $data = [];
            $q = "select a.response as `option`, count(b.response) as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid 
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%') and
                    (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number) group by a.response";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
             return $data;
        }
        
        
         /**
         * This is the function that gets the total number of available feedback responses base on two condition
         */
        public function getTheTotalNumberOfFeedbackAvailableOptionsWithTwoConditional($issue_type,$template_id,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value){
            
             $q = "select count(b.response) as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid 
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')";
                       
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
            
        }
        
        
        
        /**
         * This is the function that retrieves all feedback responses base on two condition
         */
        public function retrieveRelevantConditionalResponsesForEachOptionWithTwoConditional($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value){
            
             $data = [];
            $q = "select a.response as `option`, count(b.response) as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid 
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%') and
                    (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number) group by a.response";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
             return $data;
        }
        
        //addressing three variable conditionals
        
         /**
         * This is the function that gets the total number of available feedback responses base on three condition
         */
        public function getTheTotalConditionalResponseOnThisFeedbackIssueWithThreeCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value){
            
             $q = "select count(b.response) as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid 
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%') and 
                    (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number)";
                       
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
            
        }
        
        
        /**
         * This is the function that gets the total number of available feedback responses base on three condition
         */
        public function getTheTotalNumberOfFeedbackAvailableOptionsWithThreeConditional($issue_type,$template_id,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value){
            
             $q = "select count(b.response) as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid 
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%')";
                       
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
            
        }
        
        
        
         /**
         * This is the function that retrieves all feedback responses base on three condition
         */
        public function retrieveTheTotalNumberOfConditionalResponseForEachOptionWithThreeCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value){
            
             $q = "select a.response as `option`, count(b.response) as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid 
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%') and 
                    (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number) group by a.response";
                       
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
            
        }
        
        
        /**
         * This is the function that retrieves all feedback responses base on three condition
         */
        public function retrieveRelevantConditionalResponsesForEachOptionWithThreeConditional($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value){
            
             $q = "select a.response as `option`, count(b.response) as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid 
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%') and 
                    (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number) group by a.response";
                       
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
            
        }
        
        
        //addressing the four variable conditionals
        
        
        
        /**
         * This is the function that gets the total number of available feedback responses base on four condition
         */
        public function getTheTotalConditionalResponseOnThisFeedbackIssueWithFourCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value){
            
             $q = "select count(b.response) as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid 
                    JOIN feedback_template_option_response e ON d.trans_refid=e.trans_refid 
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%')$univariate_advance_fourth_variable_condition
                    e.response like '%$univariate_advance_fourth_independent_variable_value%')and 
                    (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number)";
                       
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
            
        }
        
        
        /**
         * This is the function that gets the total number of available feedback responses base on four condition
         */
        public function getTheTotalNumberOfFeedbackAvailableOptionsWithFourConditional($issue_type,$template_id,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value){
            
             $q = "select count(b.response) as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid
                    JOIN feedback_template_option_response e ON d.trans_refid=e.trans_refid 
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%')$univariate_advance_fourth_variable_condition
                    e.response like '%$univariate_advance_fourth_independent_variable_value%')";
                       
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
            
        }
        
        
        
         /**
         * This is the function that retrieves all feedback responses base on four condition
         */
        public function retrieveTheTotalNumberOfConditionalResponseForEachOptionWithFourCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value){
            
             $q = "select a.response as `option`, count(b.response) as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid
                    JOIN feedback_template_option_response e ON d.trans_refid=e.trans_refid 
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%')$univariate_advance_fourth_variable_condition
                    e.response like '%$univariate_advance_fourth_independent_variable_value%')and 
                   (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number) group by a.response";
                       
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
            
        }
        
        
        /**
         * This is the function that retrieves all feedback responses base on four condition
         */
        public function retrieveRelevantConditionalResponsesForEachOptionWithFourConditional($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value){
            
             $q = "select a.response as `option`, count(b.response) as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid
                    JOIN feedback_template_option_response e ON d.trans_refid=e.trans_refid 
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%')$univariate_advance_fourth_variable_condition
                    e.response like '%$univariate_advance_fourth_independent_variable_value%')and 
                    (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number) group by a.response";
                       
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
            
        }
        
        
        //addressing the five variable conditionals
        
        
        
        /**
         * This is the function that gets the total number of available feedback responses base on five condition
         */
        public function getTheTotalConditionalResponseOnThisFeedbackIssueWithFiveCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value){
            
             $q = "select count(b.response) as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid 
                    JOIN feedback_template_option_response e ON d.trans_refid=e.trans_refid 
                    JOIN feedback_template_option_response f ON e.trans_refid=f.trans_refid 
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%')$univariate_advance_fourth_variable_condition
                    e.response like '%$univariate_advance_fourth_independent_variable_value%')$univariate_advance_fifth_variable_condition 
                    f.response like '%$univariate_advance_fifth_independent_variable_value%')and 
                    (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number)";
                       
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
            
        }
        
        
        /**
         * This is the function that gets the total number of available feedback responses base on five condition
         */
        public function getTheTotalNumberOfFeedbackAvailableOptionsWithFiveConditional($issue_type,$template_id,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value){
            
             $q = "select count(b.response) as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid
                    JOIN feedback_template_option_response e ON d.trans_refid=e.trans_refid
                    JOIN feedback_template_option_response f ON e.trans_refid=f.trans_refid 
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%')$univariate_advance_fourth_variable_condition
                    e.response like '%$univariate_advance_fourth_independent_variable_value%')$univariate_advance_fifth_variable_condition 
                    f.response like '%$univariate_advance_fifth_independent_variable_value%')";
                       
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
            
        }
        
        
        
         /**
         * This is the function that retrieves all feedback responses base on five condition
         */
        public function retrieveTheTotalNumberOfConditionalResponseForEachOptionWithFiveCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value){
            
             $q = "select a.response as `option`, count(b.response) as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid
                    JOIN feedback_template_option_response e ON d.trans_refid=e.trans_refid
                    JOIN feedback_template_option_response f ON e.trans_refid=f.trans_refid 
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%')$univariate_advance_fourth_variable_condition
                    e.response like '%$univariate_advance_fourth_independent_variable_value%')$univariate_advance_fifth_variable_condition 
                    f.response like '%$univariate_advance_fifth_independent_variable_value%')and 
                    (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number) group by a.response";
                       
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
            
        }
        
        
        /**
         * This is the function that retrieves all feedback responses base on five condition
         */
        public function retrieveRelevantConditionalResponsesForEachOptionWithFiveConditional($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value){
            
             $q = "select a.response as `option`, count(b.response) as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid
                    JOIN feedback_template_option_response e ON d.trans_refid=e.trans_refid
                    JOIN feedback_template_option_response f ON e.trans_refid=f.trans_refid 
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%')$univariate_advance_fourth_variable_condition
                    e.response like '%$univariate_advance_fourth_independent_variable_value%')$univariate_advance_fifth_variable_condition 
                    f.response like '%$univariate_advance_fifth_independent_variable_value%')and 
                    (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number) group by a.response";
                       
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
            
        }
        
        
        
         //addressing the six variable conditionals
        
        
        /**
         * This is the function that gets the total number of available feedback responses base on six condition
         */
        public function getTheTotalConditionalResponseOnThisFeedbackIssueWithSixCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value){
            
             $q = "select count(b.response) as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid 
                    JOIN feedback_template_option_response e ON d.trans_refid=e.trans_refid 
                    JOIN feedback_template_option_response f ON e.trans_refid=f.trans_refid
                    JOIN feedback_template_option_response g ON f.trans_refid=g.trans_refid 
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%')$univariate_advance_fourth_variable_condition
                    e.response like '%$univariate_advance_fourth_independent_variable_value%')$univariate_advance_fifth_variable_condition 
                    f.response like '%$univariate_advance_fifth_independent_variable_value%')$univariate_advance_sixth_variable_condition 
                    g.response like '%$univariate_advance_sixth_independent_variable_value%')and 
                    (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number)";
                       
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
            
        }
        
        
        /**
         * This is the function that gets the total number of available feedback responses base on six condition
         */
        public function getTheTotalNumberOfFeedbackAvailableOptionsWithSixConditional($issue_type,$template_id,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value){
            
             $q = "select count(b.response) as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid
                    JOIN feedback_template_option_response e ON d.trans_refid=e.trans_refid
                    JOIN feedback_template_option_response f ON e.trans_refid=f.trans_refid
                    JOIN feedback_template_option_response g ON f.trans_refid=g.trans_refid 
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%')$univariate_advance_fourth_variable_condition
                    e.response like '%$univariate_advance_fourth_independent_variable_value%')$univariate_advance_fifth_variable_condition 
                    f.response like '%$univariate_advance_fifth_independent_variable_value%')$univariate_advance_sixth_variable_condition 
                    g.response like '%$univariate_advance_sixth_independent_variable_value%')";
                       
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
            
        }
        
        
        
         /**
         * This is the function that retrieves all feedback responses base on six condition
         */
        public function retrieveTheTotalNumberOfConditionalResponseForEachOptionWithSixCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value){
            
             $q = "select a.response as `option`, count(b.response) as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid
                    JOIN feedback_template_option_response e ON d.trans_refid=e.trans_refid
                    JOIN feedback_template_option_response f ON e.trans_refid=f.trans_refid 
                    JOIN feedback_template_option_response g ON f.trans_refid=g.trans_refid 
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%')$univariate_advance_fourth_variable_condition
                    e.response like '%$univariate_advance_fourth_independent_variable_value%')$univariate_advance_fifth_variable_condition 
                    f.response like '%$univariate_advance_fifth_independent_variable_value%')$univariate_advance_sixth_variable_condition 
                    g.response like '%$univariate_advance_sixth_independent_variable_value%')and 
                    (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number) group by a.response";
                       
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
            
        }
        
        
        /**
         * This is the function that retrieves all feedback responses base on six condition
         */
        public function retrieveRelevantConditionalResponsesForEachOptionWithSixConditional($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value){
            
             $q = "select a.response as `option`, count(b.response) as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid
                    JOIN feedback_template_option_response e ON d.trans_refid=e.trans_refid
                    JOIN feedback_template_option_response f ON e.trans_refid=f.trans_refid
                    JOIN feedback_template_option_response g ON f.trans_refid=g.trans_refid 
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%')$univariate_advance_fourth_variable_condition
                    e.response like '%$univariate_advance_fourth_independent_variable_value%')$univariate_advance_fifth_variable_condition 
                    f.response like '%$univariate_advance_fifth_independent_variable_value%')$univariate_advance_sixth_variable_condition 
                    g.response like '%$univariate_advance_sixth_independent_variable_value%')and 
                    (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number) group by a.response";
                       
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
            
        }
        
        
       //addressing the seven variable conditionals
        
        
        /**
         * This is the function that gets the total number of available feedback responses base on seven condition
         */
        public function getTheTotalConditionalResponseOnThisFeedbackIssueWithSevenCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value){
            
             $q = "select count(b.response) as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid 
                    JOIN feedback_template_option_response e ON d.trans_refid=e.trans_refid 
                    JOIN feedback_template_option_response f ON e.trans_refid=f.trans_refid
                    JOIN feedback_template_option_response g ON f.trans_refid=g.trans_refid
                    JOIN feedback_template_option_response h ON g.trans_refid=h.trans_refid
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%')$univariate_advance_fourth_variable_condition
                    e.response like '%$univariate_advance_fourth_independent_variable_value%')$univariate_advance_fifth_variable_condition 
                    f.response like '%$univariate_advance_fifth_independent_variable_value%')$univariate_advance_sixth_variable_condition 
                    g.response like '%$univariate_advance_sixth_independent_variable_value%')$univariate_advance_seventh_variable_condition 
                    h.response like '%$univariate_advance_seventh_independent_variable_value%')and 
                    (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number)";
                       
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
            
        }
        
        
        /**
         * This is the function that gets the total number of available feedback responses base on seven condition
         */
        public function getTheTotalNumberOfFeedbackAvailableOptionsWithSevenConditional($issue_type,$template_id,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value){
            
             $q = "select count(b.response) as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid
                    JOIN feedback_template_option_response e ON d.trans_refid=e.trans_refid
                    JOIN feedback_template_option_response f ON e.trans_refid=f.trans_refid
                    JOIN feedback_template_option_response g ON f.trans_refid=g.trans_refid
                    JOIN feedback_template_option_response h ON g.trans_refid=h.trans_refid
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%')$univariate_advance_fourth_variable_condition
                    e.response like '%$univariate_advance_fourth_independent_variable_value%')$univariate_advance_fifth_variable_condition 
                    f.response like '%$univariate_advance_fifth_independent_variable_value%')$univariate_advance_sixth_variable_condition 
                    g.response like '%$univariate_advance_sixth_independent_variable_value%')$univariate_advance_seventh_variable_condition 
                    h.response like '%$univariate_advance_seventh_independent_variable_value%')";
                       
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
            
        }
        
        
        
         /**
         * This is the function that retrieves all feedback responses base on seven condition
         */
        public function retrieveTheTotalNumberOfConditionalResponseForEachOptionWithSevenCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value){
            
             $q = "select a.response as `option`, count(b.response) as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid
                    JOIN feedback_template_option_response e ON d.trans_refid=e.trans_refid
                    JOIN feedback_template_option_response f ON e.trans_refid=f.trans_refid 
                    JOIN feedback_template_option_response g ON f.trans_refid=g.trans_refid
                    JOIN feedback_template_option_response h ON g.trans_refid=h.trans_refid
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%')$univariate_advance_fourth_variable_condition
                    e.response like '%$univariate_advance_fourth_independent_variable_value%')$univariate_advance_fifth_variable_condition 
                    f.response like '%$univariate_advance_fifth_independent_variable_value%')$univariate_advance_sixth_variable_condition 
                    g.response like '%$univariate_advance_sixth_independent_variable_value%')$univariate_advance_seventh_variable_condition 
                    h.response like '%$univariate_advance_seventh_independent_variable_value%')and 
                    (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number) group by a.response";
                       
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
            
        }
        
        
        /**
         * This is the function that retrieves all feedback responses base on seven condition
         */
        public function retrieveRelevantConditionalResponsesForEachOptionWithSevenConditional($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value){
            
             $q = "select a.response as `option`, count(b.response) as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid
                    JOIN feedback_template_option_response e ON d.trans_refid=e.trans_refid
                    JOIN feedback_template_option_response f ON e.trans_refid=f.trans_refid
                    JOIN feedback_template_option_response g ON f.trans_refid=g.trans_refid
                    JOIN feedback_template_option_response h ON g.trans_refid=h.trans_refid
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%')$univariate_advance_fourth_variable_condition
                    e.response like '%$univariate_advance_fourth_independent_variable_value%')$univariate_advance_fifth_variable_condition 
                    f.response like '%$univariate_advance_fifth_independent_variable_value%')$univariate_advance_sixth_variable_condition 
                    g.response like '%$univariate_advance_sixth_independent_variable_value%')$univariate_advance_seventh_variable_condition 
                    h.response like '%$univariate_advance_seventh_independent_variable_value%')and 
                   (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number) group by a.response";
                       
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
            
        }
        
        
        //addressing the eight variable conditionals
        
        
        /**
         * This is the function that gets the total number of available feedback responses base on eight condition
         */
        public function getTheTotalConditionalResponseOnThisFeedbackIssueWithEightCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value){
            
             $q = "select count(b.response) as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid 
                    JOIN feedback_template_option_response e ON d.trans_refid=e.trans_refid 
                    JOIN feedback_template_option_response f ON e.trans_refid=f.trans_refid
                    JOIN feedback_template_option_response g ON f.trans_refid=g.trans_refid
                    JOIN feedback_template_option_response h ON g.trans_refid=h.trans_refid
                    JOIN feedback_template_option_response i ON h.trans_refid=i.trans_refid
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%')$univariate_advance_fourth_variable_condition
                    e.response like '%$univariate_advance_fourth_independent_variable_value%')$univariate_advance_fifth_variable_condition 
                    f.response like '%$univariate_advance_fifth_independent_variable_value%')$univariate_advance_sixth_variable_condition 
                    g.response like '%$univariate_advance_sixth_independent_variable_value%')$univariate_advance_seventh_variable_condition 
                    h.response like '%$univariate_advance_seventh_independent_variable_value%')$univariate_advance_eighth_variable_condition 
                    i.response like '%$univariate_advance_eighth_independent_variable_value%')and 
                    (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number)";
                       
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
            
        }
        
        
        /**
         * This is the function that gets the total number of available feedback responses base on eight condition
         */
        public function getTheTotalNumberOfFeedbackAvailableOptionsWithEightConditional($issue_type,$template_id,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value){
            
             $q = "select count(b.response) as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid
                    JOIN feedback_template_option_response e ON d.trans_refid=e.trans_refid
                    JOIN feedback_template_option_response f ON e.trans_refid=f.trans_refid
                    JOIN feedback_template_option_response g ON f.trans_refid=g.trans_refid
                    JOIN feedback_template_option_response h ON g.trans_refid=h.trans_refid
                    JOIN feedback_template_option_response i ON h.trans_refid=i.trans_refid
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%')$univariate_advance_fourth_variable_condition
                    e.response like '%$univariate_advance_fourth_independent_variable_value%')$univariate_advance_fifth_variable_condition 
                    f.response like '%$univariate_advance_fifth_independent_variable_value%')$univariate_advance_sixth_variable_condition 
                    g.response like '%$univariate_advance_sixth_independent_variable_value%')$univariate_advance_seventh_variable_condition 
                    h.response like '%$univariate_advance_seventh_independent_variable_value%')$univariate_advance_eighth_variable_condition 
                    i.response like '%$univariate_advance_eighth_independent_variable_value%')";
                       
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
            
        }
        
        
        
         /**
         * This is the function that retrieves all feedback responses base on eight condition
         */
        public function retrieveTheTotalNumberOfConditionalResponseForEachOptionWithEightCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value){
            
             $q = "select a.response as `option`, count(b.response) as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid
                    JOIN feedback_template_option_response e ON d.trans_refid=e.trans_refid
                    JOIN feedback_template_option_response f ON e.trans_refid=f.trans_refid 
                    JOIN feedback_template_option_response g ON f.trans_refid=g.trans_refid
                    JOIN feedback_template_option_response h ON g.trans_refid=h.trans_refid
                    JOIN feedback_template_option_response i ON h.trans_refid=i.trans_refid
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%')$univariate_advance_fourth_variable_condition
                    e.response like '%$univariate_advance_fourth_independent_variable_value%')$univariate_advance_fifth_variable_condition 
                    f.response like '%$univariate_advance_fifth_independent_variable_value%')$univariate_advance_sixth_variable_condition 
                    g.response like '%$univariate_advance_sixth_independent_variable_value%')$univariate_advance_seventh_variable_condition 
                    h.response like '%$univariate_advance_seventh_independent_variable_value%')$univariate_advance_eighth_variable_condition 
                    i.response like '%$univariate_advance_eighth_independent_variable_value%')and 
                    (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number) group by a.response";
                       
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
            
        }
        
        
        /**
         * This is the function that retrieves all feedback responses base on eight condition
         */
        public function retrieveRelevantConditionalResponsesForEachOptionWithEightConditional($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value){
            
             $q = "select a.response as `option`, count(b.response) as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid
                    JOIN feedback_template_option_response e ON d.trans_refid=e.trans_refid
                    JOIN feedback_template_option_response f ON e.trans_refid=f.trans_refid
                    JOIN feedback_template_option_response g ON f.trans_refid=g.trans_refid
                    JOIN feedback_template_option_response h ON g.trans_refid=h.trans_refid
                    JOIN feedback_template_option_response i ON h.trans_refid=i.trans_refid
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%')$univariate_advance_fourth_variable_condition
                    e.response like '%$univariate_advance_fourth_independent_variable_value%')$univariate_advance_fifth_variable_condition 
                    f.response like '%$univariate_advance_fifth_independent_variable_value%')$univariate_advance_sixth_variable_condition 
                    g.response like '%$univariate_advance_sixth_independent_variable_value%')$univariate_advance_seventh_variable_condition 
                    h.response like '%$univariate_advance_seventh_independent_variable_value%')$univariate_advance_eighth_variable_condition 
                    i.response like '%$univariate_advance_eighth_independent_variable_value%')and 
                    (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number) group by a.response";
                       
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
            
        }
        
        
        
        //addressing the nine variable conditionals
        
        
        /**
         * This is the function that gets the total number of available feedback responses base on nine condition
         */
        public function getTheTotalConditionalResponseOnThisFeedbackIssueWithNineCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value,$univariate_advance_nineth_variable_condition,$univariate_advance_nineth_independent_variable_type,$univariate_advance_nineth_independent_variable_question_number,$univariate_advance_nineth_independent_variable_value){
            
             $q = "select count(b.response) as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid 
                    JOIN feedback_template_option_response e ON d.trans_refid=e.trans_refid 
                    JOIN feedback_template_option_response f ON e.trans_refid=f.trans_refid
                    JOIN feedback_template_option_response g ON f.trans_refid=g.trans_refid
                    JOIN feedback_template_option_response h ON g.trans_refid=h.trans_refid
                    JOIN feedback_template_option_response i ON h.trans_refid=i.trans_refid
                    JOIN feedback_template_option_response j ON i.trans_refid=j.trans_refid
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%')$univariate_advance_fourth_variable_condition
                    e.response like '%$univariate_advance_fourth_independent_variable_value%')$univariate_advance_fifth_variable_condition 
                    f.response like '%$univariate_advance_fifth_independent_variable_value%')$univariate_advance_sixth_variable_condition 
                    g.response like '%$univariate_advance_sixth_independent_variable_value%')$univariate_advance_seventh_variable_condition 
                    h.response like '%$univariate_advance_seventh_independent_variable_value%')$univariate_advance_eighth_variable_condition 
                    i.response like '%$univariate_advance_eighth_independent_variable_value%')$univariate_advance_nineth_variable_condition 
                    j.response like '%$univariate_advance_nineth_independent_variable_value%')and     
                    (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number)";
                       
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
            
        }
        
        
        /**
         * This is the function that gets the total number of available feedback responses base on nine condition
         */
        public function getTheTotalNumberOfFeedbackAvailableOptionsWithNineConditional($issue_type,$template_id,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value,$univariate_advance_nineth_variable_condition,$univariate_advance_nineth_independent_variable_type,$univariate_advance_nineth_independent_variable_question_number,$univariate_advance_nineth_independent_variable_value){
            
             $q = "select count(b.response) as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid
                    JOIN feedback_template_option_response e ON d.trans_refid=e.trans_refid
                    JOIN feedback_template_option_response f ON e.trans_refid=f.trans_refid
                    JOIN feedback_template_option_response g ON f.trans_refid=g.trans_refid
                    JOIN feedback_template_option_response h ON g.trans_refid=h.trans_refid
                    JOIN feedback_template_option_response i ON h.trans_refid=i.trans_refid
                    JOIN feedback_template_option_response j ON i.trans_refid=j.trans_refid
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%')$univariate_advance_fourth_variable_condition
                    e.response like '%$univariate_advance_fourth_independent_variable_value%')$univariate_advance_fifth_variable_condition 
                    f.response like '%$univariate_advance_fifth_independent_variable_value%')$univariate_advance_sixth_variable_condition 
                    g.response like '%$univariate_advance_sixth_independent_variable_value%')$univariate_advance_seventh_variable_condition 
                    h.response like '%$univariate_advance_seventh_independent_variable_value%')$univariate_advance_eighth_variable_condition 
                    i.response like '%$univariate_advance_eighth_independent_variable_value%')$univariate_advance_nineth_variable_condition 
                    j.response like '%$univariate_advance_nineth_independent_variable_value%')";
                       
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
            
        }
        
        
        
         /**
         * This is the function that retrieves all feedback responses base on nine condition
         */
        public function retrieveTheTotalNumberOfConditionalResponseForEachOptionWithNineCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value,$univariate_advance_nineth_variable_condition,$univariate_advance_nineth_independent_variable_type,$univariate_advance_nineth_independent_variable_question_number,$univariate_advance_nineth_independent_variable_value){
            
             $q = "select a.response as `option`, count(b.response) as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid
                    JOIN feedback_template_option_response e ON d.trans_refid=e.trans_refid
                    JOIN feedback_template_option_response f ON e.trans_refid=f.trans_refid 
                    JOIN feedback_template_option_response g ON f.trans_refid=g.trans_refid
                    JOIN feedback_template_option_response h ON g.trans_refid=h.trans_refid
                    JOIN feedback_template_option_response i ON h.trans_refid=i.trans_refid
                    JOIN feedback_template_option_response j ON i.trans_refid=j.trans_refid
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%')$univariate_advance_fourth_variable_condition
                    e.response like '%$univariate_advance_fourth_independent_variable_value%')$univariate_advance_fifth_variable_condition 
                    f.response like '%$univariate_advance_fifth_independent_variable_value%')$univariate_advance_sixth_variable_condition 
                    g.response like '%$univariate_advance_sixth_independent_variable_value%')$univariate_advance_seventh_variable_condition 
                    h.response like '%$univariate_advance_seventh_independent_variable_value%')$univariate_advance_eighth_variable_condition 
                   i.response like '%$univariate_advance_eighth_independent_variable_value%')$univariate_advance_nineth_variable_condition 
                   j.response like '%$univariate_advance_nineth_independent_variable_value%')and     
                   (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number) group by a.response";
                       
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
            
        }
        
        
        /**
         * This is the function that retrieves all feedback responses base on nine condition
         */
        public function retrieveRelevantConditionalResponsesForEachOptionWithNineConditional($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value,$univariate_advance_nineth_variable_condition,$univariate_advance_nineth_independent_variable_type,$univariate_advance_nineth_independent_variable_question_number,$univariate_advance_nineth_independent_variable_value){
            
             $q = "select a.response as `option`, count(b.response) as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid
                    JOIN feedback_template_option_response e ON d.trans_refid=e.trans_refid
                    JOIN feedback_template_option_response f ON e.trans_refid=f.trans_refid
                    JOIN feedback_template_option_response g ON f.trans_refid=g.trans_refid
                    JOIN feedback_template_option_response h ON g.trans_refid=h.trans_refid
                    JOIN feedback_template_option_response i ON h.trans_refid=i.trans_refid
                    JOIN feedback_template_option_response j ON i.trans_refid=j.trans_refid
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%')$univariate_advance_fourth_variable_condition
                    e.response like '%$univariate_advance_fourth_independent_variable_value%')$univariate_advance_fifth_variable_condition 
                    f.response like '%$univariate_advance_fifth_independent_variable_value%')$univariate_advance_sixth_variable_condition 
                    g.response like '%$univariate_advance_sixth_independent_variable_value%')$univariate_advance_seventh_variable_condition 
                    h.response like '%$univariate_advance_seventh_independent_variable_value%')$univariate_advance_eighth_variable_condition 
                    i.response like '%$univariate_advance_eighth_independent_variable_value%')$univariate_advance_nineth_variable_condition 
                    j.response like '%$univariate_advance_nineth_independent_variable_value%')and     
                    (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number) group by a.response";
                       
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
            
        }
        
        
        
         //addressing the tenth variable conditionals
        
        
        /**
         * This is the function that gets the total number of available feedback responses base on ten condition
         */
        public function getTheTotalConditionalResponseOnThisFeedbackIssueWithTenCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value,$univariate_advance_nineth_variable_condition,$univariate_advance_nineth_independent_variable_type,$univariate_advance_nineth_independent_variable_question_number,$univariate_advance_nineth_independent_variable_value,$univariate_advance_tenth_variable_condition,$univariate_advance_tenth_independent_variable_type,$univariate_advance_tenth_independent_variable_question_number,$univariate_advance_tenth_independent_variable_value){
            
             $q = "select count(b.response) as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid 
                    JOIN feedback_template_option_response e ON d.trans_refid=e.trans_refid 
                    JOIN feedback_template_option_response f ON e.trans_refid=f.trans_refid
                    JOIN feedback_template_option_response g ON f.trans_refid=g.trans_refid
                    JOIN feedback_template_option_response h ON g.trans_refid=h.trans_refid
                    JOIN feedback_template_option_response i ON h.trans_refid=i.trans_refid
                    JOIN feedback_template_option_response j ON i.trans_refid=j.trans_refid
                    JOIN feedback_template_option_response k ON j.trans_refid=k.trans_refid
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%')$univariate_advance_fourth_variable_condition
                    e.response like '%$univariate_advance_fourth_independent_variable_value%')$univariate_advance_fifth_variable_condition 
                    f.response like '%$univariate_advance_fifth_independent_variable_value%')$univariate_advance_sixth_variable_condition 
                    g.response like '%$univariate_advance_sixth_independent_variable_value%')$univariate_advance_seventh_variable_condition 
                    h.response like '%$univariate_advance_seventh_independent_variable_value%')$univariate_advance_eighth_variable_condition 
                    i.response like '%$univariate_advance_eighth_independent_variable_value%')$univariate_advance_nineth_variable_condition 
                    j.response like '%$univariate_advance_nineth_independent_variable_value%')$univariate_advance_tenth_variable_condition
                    k.response like '%$univariate_advance_tenth_independent_variable_value%')and     
                    (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number)";
                       
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
            
        }
        
        
        /**
         * This is the function that gets the total number of available feedback responses base on ten condition
         */
        public function getTheTotalNumberOfFeedbackAvailableOptionsWithTenConditional($issue_type,$template_id,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value,$univariate_advance_nineth_variable_condition,$univariate_advance_nineth_independent_variable_type,$univariate_advance_nineth_independent_variable_question_number,$univariate_advance_nineth_independent_variable_value,$univariate_advance_tenth_variable_condition,$univariate_advance_tenth_independent_variable_type,$univariate_advance_tenth_independent_variable_question_number,$univariate_advance_tenth_independent_variable_value){
            
             $q = "select count(b.response) as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid
                    JOIN feedback_template_option_response e ON d.trans_refid=e.trans_refid
                    JOIN feedback_template_option_response f ON e.trans_refid=f.trans_refid
                    JOIN feedback_template_option_response g ON f.trans_refid=g.trans_refid
                    JOIN feedback_template_option_response h ON g.trans_refid=h.trans_refid
                    JOIN feedback_template_option_response i ON h.trans_refid=i.trans_refid
                    JOIN feedback_template_option_response j ON i.trans_refid=j.trans_refid
                    JOIN feedback_template_option_response k ON j.trans_refid=k.trans_refid
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%')$univariate_advance_fourth_variable_condition
                    e.response like '%$univariate_advance_fourth_independent_variable_value%')$univariate_advance_fifth_variable_condition 
                    f.response like '%$univariate_advance_fifth_independent_variable_value%')$univariate_advance_sixth_variable_condition 
                    g.response like '%$univariate_advance_sixth_independent_variable_value%')$univariate_advance_seventh_variable_condition 
                    h.response like '%$univariate_advance_seventh_independent_variable_value%')$univariate_advance_eighth_variable_condition 
                    i.response like '%$univariate_advance_eighth_independent_variable_value%')$univariate_advance_nineth_variable_condition 
                    j.response like '%$univariate_advance_nineth_independent_variable_value%')$univariate_advance_tenth_variable_condition
                    k.response like '%$univariate_advance_tenth_independent_variable_value%')";
                       
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
            
        }
        
        
        
         /**
         * This is the function that retrieves all feedback responses base on ten condition
         */
        public function retrieveTheTotalNumberOfConditionalResponseForEachOptionWithTenCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value,$univariate_advance_nineth_variable_condition,$univariate_advance_nineth_independent_variable_type,$univariate_advance_nineth_independent_variable_question_number,$univariate_advance_nineth_independent_variable_value,$univariate_advance_tenth_variable_condition,$univariate_advance_tenth_independent_variable_type,$univariate_advance_tenth_independent_variable_question_number,$univariate_advance_tenth_independent_variable_value){
            
             $q = "select a.response as `option`, count(b.response) as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid
                    JOIN feedback_template_option_response e ON d.trans_refid=e.trans_refid
                    JOIN feedback_template_option_response f ON e.trans_refid=f.trans_refid 
                    JOIN feedback_template_option_response g ON f.trans_refid=g.trans_refid
                    JOIN feedback_template_option_response h ON g.trans_refid=h.trans_refid
                    JOIN feedback_template_option_response i ON h.trans_refid=i.trans_refid
                    JOIN feedback_template_option_response j ON i.trans_refid=j.trans_refid
                    JOIN feedback_template_option_response k ON j.trans_refid=k.trans_refid
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%')$univariate_advance_fourth_variable_condition
                    e.response like '%$univariate_advance_fourth_independent_variable_value%')$univariate_advance_fifth_variable_condition 
                    f.response like '%$univariate_advance_fifth_independent_variable_value%')$univariate_advance_sixth_variable_condition 
                    g.response like '%$univariate_advance_sixth_independent_variable_value%')$univariate_advance_seventh_variable_condition 
                    h.response like '%$univariate_advance_seventh_independent_variable_value%')$univariate_advance_eighth_variable_condition 
                   i.response like '%$univariate_advance_eighth_independent_variable_value%')$univariate_advance_nineth_variable_condition 
                   j.response like '%$univariate_advance_nineth_independent_variable_value%')$univariate_advance_tenth_variable_condition
                   k.response like '%$univariate_advance_tenth_independent_variable_value%')and     
                   (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number) group by a.response";
                       
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
            
        }
        
        
        /**
         * This is the function that retrieves all feedback responses base on ten condition
         */
        public function retrieveRelevantConditionalResponsesForEachOptionWithTenConditional($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value,$univariate_advance_nineth_variable_condition,$univariate_advance_nineth_independent_variable_type,$univariate_advance_nineth_independent_variable_question_number,$univariate_advance_nineth_independent_variable_value,$univariate_advance_tenth_variable_condition,$univariate_advance_tenth_independent_variable_type,$univariate_advance_tenth_independent_variable_question_number,$univariate_advance_tenth_independent_variable_value){
            
             $q = "select a.response as `option`, count(b.response) as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid
                    JOIN feedback_template_option_response e ON d.trans_refid=e.trans_refid
                    JOIN feedback_template_option_response f ON e.trans_refid=f.trans_refid
                    JOIN feedback_template_option_response g ON f.trans_refid=g.trans_refid
                    JOIN feedback_template_option_response h ON g.trans_refid=h.trans_refid
                    JOIN feedback_template_option_response i ON h.trans_refid=i.trans_refid
                    JOIN feedback_template_option_response j ON i.trans_refid=j.trans_refid
                    JOIN feedback_template_option_response k ON j.trans_refid=k.trans_refid
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%')$univariate_advance_fourth_variable_condition
                    e.response like '%$univariate_advance_fourth_independent_variable_value%')$univariate_advance_fifth_variable_condition 
                    f.response like '%$univariate_advance_fifth_independent_variable_value%')$univariate_advance_sixth_variable_condition 
                    g.response like '%$univariate_advance_sixth_independent_variable_value%')$univariate_advance_seventh_variable_condition 
                    h.response like '%$univariate_advance_seventh_independent_variable_value%')$univariate_advance_eighth_variable_condition 
                    i.response like '%$univariate_advance_eighth_independent_variable_value%')$univariate_advance_nineth_variable_condition 
                    j.response like '%$univariate_advance_nineth_independent_variable_value%')$univariate_advance_tenth_variable_condition
                    k.response like '%$univariate_advance_tenth_independent_variable_value%')and     
                    (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number) group by a.response";
                       
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
            
        }
        
        
        /**
         * This is the function that gets the percentage response of a feedback option
         */
        public function getThePercentageResponseOfThisOption($option_id,$template_id,$total_responses_received,$start_date,$end_date){
            $data = [];
            $q = "select a.response as `option`, count(b.response)/$total_responses_received*100 as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.option_id=b.option_id 
                    where (a.template_id=$template_id and b.option_id=$option_id) and (b.response_date between '$start_date' AND '$end_date') 
                   and a.trans_refid=b.trans_refid group by a.response order by a.option_id";
            
             $cmd = Yii::app()->db->createCommand($q);
             //$result = $cmd->queryScalar();
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
             return $data;
        }
     
        
         /**
         * This is the function that retrieves the percentage responses of a feedback question
         */
        public function getThePercentageResponsesOfFeedbackQuestionOptions($template_id,$question_number,$total_responses_received,$start_date,$end_date){
           /** $data = [];
            $q = "select a.id,a.question_number,a.template_id,a.option, count(b.response)/$total_responses_received*100 as response from feedback_template_options a 
                    JOIN feedback_template_option_response b ON a.id=b.option_id 
                    where (a.template_id=$template_id and a.question_number=$question_number) and (b.response_date between '$start_date' AND '$end_date') 
                    group by a.option order by a.id";
            
             $cmd = Yii::app()->db->createCommand($q);
             //$result = $cmd->queryScalar();
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
             return $data;
           
            
            
            $data = [];
            $q = "select b.id, b.option, count(c.response)/$total_responses_received*100 as response from feedback_template_options b
                    JOIN feedback_template_option_response c ON b.option=c.response
                    Where (b.question_number=$question_number AND b.template_id=$template_id) AND (c.response_date between '$start_date' AND '$end_date')
                    group by b.option order by b.id";
            * 
            */
            
             $data = [];
            $q = "select b.option_id as id, b.response as  `option`, count(c.response)/$total_responses_received*100 as response from feedback_template_option_response b
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    Where (b.question_number=$question_number AND b.template_id=$template_id) AND (c.response_date between '$start_date' AND '$end_date')
                    and b.option_id=c.option_id group by b.response order by b.option_id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
             return $data;
            
            
        }
        
        
        
         /**
         * This is the function that gets the percentage response of a feedback option with no condition
         */
        public function getThePercentageResponsesOfFeedbackQuestionOptionsWithNoCondition($option_id,$template_id,$total_responses_received,$start_date,$end_date){
            $data = [];
           /** $q = "select a.option, count(b.response)/$total_responses_received*100 as response from feedback_template_options a 
                    JOIN feedback_template_option_response b ON a.id=b.option_id 
                    where (a.template_id=$template_id and b.option_id=$option_id) and (b.response_date between '$start_date' AND '$end_date') 
                    group by a.option";
            * 
            */
            $q = "select a.option_id,a.response as `option`, count(b.response)/$total_responses_received*100 as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.option_id=b.option_id
                    where (a.template_id=$template_id and b.option_id=$option_id) and (b.response_date between '$start_date' AND '$end_date') 
                    and a.trans_refid=b.trans_refid group by a.response";
            
             $cmd = Yii::app()->db->createCommand($q);
             //$result = $cmd->queryScalar();
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
             return $data;
        }
        
        
         /**
         * This is the function that gets the percentage response of a feedback option with one condition
         */
        public function getThePercentageResponsesOfFeedbackQuestionOptionsWithOneCondition($option_id,$template_id,$total_responses_received,$start_date,$end_date,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value){
            $data = [];
            $q = "select a.option_id,a.response as `option`, count(b.response)/$total_responses_received*100 as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid 
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition b.response like '%$univariate_advance_first_independent_variable_value%') and
                    (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number and a.option_id=$option_id)group by a.response order by a.option_id";
            
             $cmd = Yii::app()->db->createCommand($q);
             //$result = $cmd->queryScalar();
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
             return $data;
        }
        
        
         /**
         * This is the function that gets the percentage response of a feedback option with two conditions
         */
        public function getThePercentageResponsesOfFeedbackQuestionOptionsWithTwoCondition($option_id,$template_id,$total_responses_received,$start_date,$end_date,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value){
            $data = [];
            $q = "select a.option_id, a.response as `option`, count(b.response)/$total_responses_received*100 as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid 
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%') and
                    (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number)and a.option_id=$option_id group by a.response order by a.option_id";
           
             $cmd = Yii::app()->db->createCommand($q);
             //$result = $cmd->queryScalar();
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
             return $data;
        }
        
        
        /**
         * This is the function that gets the percentage response of a feedback option with three conditions
         */
        public function getThePercentageResponsesOfFeedbackQuestionOptionsWithThreeCondition($option_id,$template_id,$total_responses_received,$start_date,$end_date,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value){
            $data = [];
            $q = "select a.option_id,a.response as `option`, count(b.response)/$total_responses_received*100 as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid 
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%') and 
                    (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number) and a.option_id=$option_id group by a.response order by a.option_id";
            
             $cmd = Yii::app()->db->createCommand($q);
             //$result = $cmd->queryScalar();
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
             return $data;
        }
        
        
        /**
         * This is the function that gets the percentage response of a feedback option with four conditions
         */
        public function getThePercentageResponsesOfFeedbackQuestionOptionsWithFourCondition($option_id,$template_id,$total_responses_received,$start_date,$end_date,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value){
            $data = [];
            $q = "select a.option_id,a.response as `option`, count(b.response)/$total_responses_received*100 as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid
                    JOIN feedback_template_option_response e ON d.trans_refid=e.trans_refid 
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%')$univariate_advance_fourth_variable_condition
                    e.response like '%$univariate_advance_fourth_independent_variable_value%')and 
                   (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number)and a.option_id=$option_id group by a.response order by a.option_id";
            
             $cmd = Yii::app()->db->createCommand($q);
             //$result = $cmd->queryScalar();
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
             return $data;
        }
        
        
        
        /**
         * This is the function that gets the percentage response of a feedback option with five conditions
         */
        public function getThePercentageResponsesOfFeedbackQuestionOptionsWithFiveCondition($option_id,$template_id,$total_responses_received,$start_date,$end_date,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value){
            $data = [];
            $q = "select a.option_id,a.response as `option`, count(b.response)/$total_responses_received*100 as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid
                    JOIN feedback_template_option_response e ON d.trans_refid=e.trans_refid
                    JOIN feedback_template_option_response f ON e.trans_refid=f.trans_refid 
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%')$univariate_advance_fourth_variable_condition
                    e.response like '%$univariate_advance_fourth_independent_variable_value%')$univariate_advance_fifth_variable_condition 
                    f.response like '%$univariate_advance_fifth_independent_variable_value%')and 
                    (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number) and a.option_id=$option_id group by a.response order by a.option_id";
            
             $cmd = Yii::app()->db->createCommand($q);
             //$result = $cmd->queryScalar();
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
             return $data;
        }
        
        
        /**
         * This is the function that gets the percentage response of a feedback option with six conditions
         */
        public function getThePercentageResponsesOfFeedbackQuestionOptionsWithSixCondition($option_id,$template_id,$total_responses_received,$start_date,$end_date,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value){
            $data = [];
            $q = "select a.option_id,a.response as `option`, count(b.response)/$total_responses_received*100 as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid
                    JOIN feedback_template_option_response e ON d.trans_refid=e.trans_refid
                    JOIN feedback_template_option_response f ON e.trans_refid=f.trans_refid 
                    JOIN feedback_template_option_response g ON f.trans_refid=g.trans_refid 
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%')$univariate_advance_fourth_variable_condition
                    e.response like '%$univariate_advance_fourth_independent_variable_value%')$univariate_advance_fifth_variable_condition 
                    f.response like '%$univariate_advance_fifth_independent_variable_value%')$univariate_advance_sixth_variable_condition 
                    g.response like '%$univariate_advance_sixth_independent_variable_value%')and 
                    (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number) and a.option_id=$option_id group by a.response order by a.option_id";
            
             $cmd = Yii::app()->db->createCommand($q);
             //$result = $cmd->queryScalar();
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
             return $data;
        }
        
        
        
        
        /**
         * This is the function that gets the percentage response of a feedback option with seven conditions
         */
        public function getThePercentageResponsesOfFeedbackQuestionOptionsWithSevenCondition($option_id,$template_id,$total_responses_received,$start_date,$end_date,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value){
            $data = [];
            $q = "select a.option_id,a.response as `option`, count(b.response)/$total_responses_received*100 as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid
                    JOIN feedback_template_option_response e ON d.trans_refid=e.trans_refid
                    JOIN feedback_template_option_response f ON e.trans_refid=f.trans_refid 
                    JOIN feedback_template_option_response g ON f.trans_refid=g.trans_refid
                    JOIN feedback_template_option_response h ON g.trans_refid=h.trans_refid
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%')$univariate_advance_fourth_variable_condition
                    e.response like '%$univariate_advance_fourth_independent_variable_value%')$univariate_advance_fifth_variable_condition 
                    f.response like '%$univariate_advance_fifth_independent_variable_value%')$univariate_advance_sixth_variable_condition 
                    g.response like '%$univariate_advance_sixth_independent_variable_value%')$univariate_advance_seventh_variable_condition 
                    h.response like '%$univariate_advance_seventh_independent_variable_value%')and 
                    (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number) and a.option_id=$option_id group by a.response order by a.option_id";
            
             $cmd = Yii::app()->db->createCommand($q);
             //$result = $cmd->queryScalar();
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
             return $data;
        }
        
        
        
        /**
         * This is the function that gets the percentage response of a feedback option with eight conditions
         */
        public function getThePercentageResponsesOfFeedbackQuestionOptionsWithEightCondition($option_id,$template_id,$total_responses_received,$start_date,$end_date,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value){
            $data = [];
            $q = "select a.option_id,a.response as `option`, count(b.response)/$total_responses_received*100 as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid
                    JOIN feedback_template_option_response e ON d.trans_refid=e.trans_refid
                    JOIN feedback_template_option_response f ON e.trans_refid=f.trans_refid 
                    JOIN feedback_template_option_response g ON f.trans_refid=g.trans_refid
                    JOIN feedback_template_option_response h ON g.trans_refid=h.trans_refid
                    JOIN feedback_template_option_response i ON h.trans_refid=i.trans_refid
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%')$univariate_advance_fourth_variable_condition
                    e.response like '%$univariate_advance_fourth_independent_variable_value%')$univariate_advance_fifth_variable_condition 
                    f.response like '%$univariate_advance_fifth_independent_variable_value%')$univariate_advance_sixth_variable_condition 
                    g.response like '%$univariate_advance_sixth_independent_variable_value%')$univariate_advance_seventh_variable_condition 
                    h.response like '%$univariate_advance_seventh_independent_variable_value%')$univariate_advance_eighth_variable_condition 
                    i.response like '%$univariate_advance_eighth_independent_variable_value%')and 
                    (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number) and a.option_id=$option_id group by a.response order by a.option_id";
            
             $cmd = Yii::app()->db->createCommand($q);
             //$result = $cmd->queryScalar();
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
             return $data;
        }
        
        
        
         /**
         * This is the function that gets the percentage response of a feedback option with nine conditions
         */
        public function getThePercentageResponsesOfFeedbackQuestionOptionsWithNineCondition($option_id,$template_id,$total_responses_received,$start_date,$end_date,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value,$univariate_advance_nineth_variable_condition,$univariate_advance_nineth_independent_variable_type,$univariate_advance_nineth_independent_variable_question_number,$univariate_advance_nineth_independent_variable_value){
            $data = [];
            $q = "select a.option_id,a.response as `option`, count(b.response)/$total_responses_received*100 as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid
                    JOIN feedback_template_option_response e ON d.trans_refid=e.trans_refid
                    JOIN feedback_template_option_response f ON e.trans_refid=f.trans_refid 
                    JOIN feedback_template_option_response g ON f.trans_refid=g.trans_refid
                    JOIN feedback_template_option_response h ON g.trans_refid=h.trans_refid
                    JOIN feedback_template_option_response i ON h.trans_refid=i.trans_refid
                    JOIN feedback_template_option_response j ON i.trans_refid=j.trans_refid
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%')$univariate_advance_fourth_variable_condition
                    e.response like '%$univariate_advance_fourth_independent_variable_value%')$univariate_advance_fifth_variable_condition 
                    f.response like '%$univariate_advance_fifth_independent_variable_value%')$univariate_advance_sixth_variable_condition 
                    g.response like '%$univariate_advance_sixth_independent_variable_value%')$univariate_advance_seventh_variable_condition 
                    h.response like '%$univariate_advance_seventh_independent_variable_value%')$univariate_advance_eighth_variable_condition 
                   i.response like '%$univariate_advance_eighth_independent_variable_value%')$univariate_advance_nineth_variable_condition 
                   j.response like '%$univariate_advance_nineth_independent_variable_value%')and     
                   (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number) and a.option_id=$option_id group by a.response order by a.option_id";
            
             $cmd = Yii::app()->db->createCommand($q);
             //$result = $cmd->queryScalar();
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
             return $data;
        }
        
        
        /**
         * This is the function that gets the percentage response of a feedback option with ten conditions
         */
        public function getThePercentageResponsesOfFeedbackQuestionOptionsWithTenCondition($option_id,$template_id,$total_responses_received,$start_date,$end_date,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value,$univariate_advance_nineth_variable_condition,$univariate_advance_nineth_independent_variable_type,$univariate_advance_nineth_independent_variable_question_number,$univariate_advance_nineth_independent_variable_value,$univariate_advance_tenth_variable_condition,$univariate_advance_tenth_independent_variable_type,$univariate_advance_tenth_independent_variable_question_number,$univariate_advance_tenth_independent_variable_value){
            $data = [];
            $q = "select a.option_id,a.response as `option`, count(b.response)/$total_responses_received*100 as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid
                    JOIN feedback_template_option_response e ON d.trans_refid=e.trans_refid
                    JOIN feedback_template_option_response f ON e.trans_refid=f.trans_refid 
                    JOIN feedback_template_option_response g ON f.trans_refid=g.trans_refid
                    JOIN feedback_template_option_response h ON g.trans_refid=h.trans_refid
                    JOIN feedback_template_option_response i ON h.trans_refid=i.trans_refid
                    JOIN feedback_template_option_response j ON i.trans_refid=j.trans_refid
                    JOIN feedback_template_option_response k ON j.trans_refid=k.trans_refid
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%')$univariate_advance_fourth_variable_condition
                    e.response like '%$univariate_advance_fourth_independent_variable_value%')$univariate_advance_fifth_variable_condition 
                    f.response like '%$univariate_advance_fifth_independent_variable_value%')$univariate_advance_sixth_variable_condition 
                    g.response like '%$univariate_advance_sixth_independent_variable_value%')$univariate_advance_seventh_variable_condition 
                    h.response like '%$univariate_advance_seventh_independent_variable_value%')$univariate_advance_eighth_variable_condition 
                   i.response like '%$univariate_advance_eighth_independent_variable_value%')$univariate_advance_nineth_variable_condition 
                   j.response like '%$univariate_advance_nineth_independent_variable_value%')$univariate_advance_tenth_variable_condition
                   k.response like '%$univariate_advance_tenth_independent_variable_value%')and     
                   (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number) and a.option_id=$option_id group by a.response order by a.option_id";
            
             $cmd = Yii::app()->db->createCommand($q);
             //$result = $cmd->queryScalar();
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
             return $data;
        }
        
        
        
          /**
         * This is the function that retrieves the total number of responses in percentages for each option in a feedback issue within a period
         */
        public function retrieveTheTotalNumberOfConditionalResponseForEachOptionWithNoCondtionsInPercentages($total_response,$issue_type,$template_id,$question_number,$start_date,$end_date){
             $data = [];
           $q = "select b.option_id as `id`, b.response as `option`, count(c.response)/$total_response*100 as response from feedback_template_option_response b
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    Where (b.question_number=$question_number AND b.template_id=$template_id) AND (c.response_date between '$start_date' AND '$end_date')
                    and b.option_id=c.option_id group by b.response order by b.id ";
           
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
             return $data;
            
        }
        
        
         //addressing one variable conditionals
        
        /**
         * This is the function that retrieves all feedback responsesin percentages base on one condition
         */
        public function retrieveTheTotalNumberOfConditionalResponseForEachOptionWithOneCondtionsInPercentages($total_response,$issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value){
            
             $data = [];
            $q = "select a.option_id as `id`,a.response as `option`, count(b.response)/$total_response*100 as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid 
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition b.response like '%$univariate_advance_first_independent_variable_value%') and
                    (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number) group by a.response order by a.option_id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
             return $data;
        }
        
        
        
         /**
         * This is the function that retrieves all feedback responses in percentages base on two condition
         */
        public function retrieveTheTotalNumberOfConditionalResponseForEachOptionWithTwoCondtionsInPercentages($total_response,$issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value){
            
             $data = [];
            $q = "select a.option_id as `id`,a.response as `option`, count(b.response)/$total_response*100 as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid 
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%') and
                    (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number) group by a.response order by a.option_id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
             return $data;
        }
        
        
         /**
         * This is the function that retrieves all feedback responses base on three condition
         */
        public function retrieveTheTotalNumberOfConditionalResponseForEachOptionWithThreeCondtionsInPercentages($total_response,$issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value){
            
             $q = "select a.option_id as `id`, a.response as `option`, count(b.response)/$total_response*100 as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid 
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%') and 
                    (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number) group by a.response order by a.option_id";
                       
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
            
        }
        
        
         /**
         * This is the function that retrieves all feedback responses base on four condition
         */
        public function retrieveTheTotalNumberOfConditionalResponseForEachOptionWithFourCondtionsInPercentages($total_response,$issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value){
            
             $q = "select a.option_id as `id`,a.response as `option`, count(b.response)/$total_response*100 as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid
                    JOIN feedback_template_option_response e ON d.trans_refid=e.trans_refid 
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%')$univariate_advance_fourth_variable_condition
                    e.response like '%$univariate_advance_fourth_independent_variable_value%')and 
                   (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number) group by a.response order by a.option_id";
                       
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
            
        }
        
        
        
        /**
         * This is the function that retrieves all feedback responses in percentages base on five condition
         */
        public function retrieveTheTotalNumberOfConditionalResponseForEachOptionWithFiveCondtionsInPercentages($total_response,$issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value){
            
             $q = "select a.option_id as `id`, a.response as `option`, count(b.response)/$total_response*100 as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid
                    JOIN feedback_template_option_response e ON d.trans_refid=e.trans_refid
                    JOIN feedback_template_option_response f ON e.trans_refid=f.trans_refid 
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%')$univariate_advance_fourth_variable_condition
                    e.response like '%$univariate_advance_fourth_independent_variable_value%')$univariate_advance_fifth_variable_condition 
                    f.response like '%$univariate_advance_fifth_independent_variable_value%')and 
                    (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number) group by a.response order by a.option_id";
                       
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
            
        }
        
        
        /**
         * This is the function that retrieves all feedback responses in percentages base on six condition
         */
        public function retrieveTheTotalNumberOfConditionalResponseForEachOptionWithSixCondtionsInPercentages($total_response,$issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value){
            
             $q = "select a.option_id as `id`, a.response as `option`, count(b.response)/$total_response*100 as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid
                    JOIN feedback_template_option_response e ON d.trans_refid=e.trans_refid
                    JOIN feedback_template_option_response f ON e.trans_refid=f.trans_refid 
                    JOIN feedback_template_option_response g ON f.trans_refid=g.trans_refid 
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%')$univariate_advance_fourth_variable_condition
                    e.response like '%$univariate_advance_fourth_independent_variable_value%')$univariate_advance_fifth_variable_condition 
                    f.response like '%$univariate_advance_fifth_independent_variable_value%')$univariate_advance_sixth_variable_condition 
                    g.response like '%$univariate_advance_sixth_independent_variable_value%')and 
                    (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number) group by a.response order by a.option_id";
                       
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
            
        }
        
        
        /**
         * This is the function that retrieves all feedback responses base on seven condition
         */
        public function retrieveTheTotalNumberOfConditionalResponseForEachOptionWithSevenCondtionsInPercentages($total_response,$issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value){
            
             $q = "select a.option_id as `id`,a.response as `option`, count(b.response)/$total_response*100 as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid
                    JOIN feedback_template_option_response e ON d.trans_refid=e.trans_refid
                    JOIN feedback_template_option_response f ON e.trans_refid=f.trans_refid 
                    JOIN feedback_template_option_response g ON f.trans_refid=g.trans_refid
                    JOIN feedback_template_option_response h ON g.trans_refid=h.trans_refid
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%')$univariate_advance_fourth_variable_condition
                    e.response like '%$univariate_advance_fourth_independent_variable_value%')$univariate_advance_fifth_variable_condition 
                    f.response like '%$univariate_advance_fifth_independent_variable_value%')$univariate_advance_sixth_variable_condition 
                    g.response like '%$univariate_advance_sixth_independent_variable_value%')$univariate_advance_seventh_variable_condition 
                    h.response like '%$univariate_advance_seventh_independent_variable_value%')and 
                    (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number) group by a.response order by a.option_id";
                       
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
            
        }
        
        
         /**
         * This is the function that retrieves all feedback responses base on eight condition
         */
        public function retrieveTheTotalNumberOfConditionalResponseForEachOptionWithEightCondtionsInPercentages($total_response,$issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value){
            
             $q = "select a.option_id as `id`, a.response as `option`, count(b.response)/$total_response*100 as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid
                    JOIN feedback_template_option_response e ON d.trans_refid=e.trans_refid
                    JOIN feedback_template_option_response f ON e.trans_refid=f.trans_refid 
                    JOIN feedback_template_option_response g ON f.trans_refid=g.trans_refid
                    JOIN feedback_template_option_response h ON g.trans_refid=h.trans_refid
                    JOIN feedback_template_option_response i ON h.trans_refid=i.trans_refid
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%')$univariate_advance_fourth_variable_condition
                    e.response like '%$univariate_advance_fourth_independent_variable_value%')$univariate_advance_fifth_variable_condition 
                    f.response like '%$univariate_advance_fifth_independent_variable_value%')$univariate_advance_sixth_variable_condition 
                    g.response like '%$univariate_advance_sixth_independent_variable_value%')$univariate_advance_seventh_variable_condition 
                    h.response like '%$univariate_advance_seventh_independent_variable_value%')$univariate_advance_eighth_variable_condition 
                    i.response like '%$univariate_advance_eighth_independent_variable_value%')and 
                    (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number) group by a.response order by a.option_id";
                       
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
            
        }
        
        
         /**
         * This is the function that retrieves all feedback responses as percentages base on nine condition
         */
        public function retrieveTheTotalNumberOfConditionalResponseForEachOptionWithNineCondtionsInPercentages($total_response,$issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value,$univariate_advance_nineth_variable_condition,$univariate_advance_nineth_independent_variable_type,$univariate_advance_nineth_independent_variable_question_number,$univariate_advance_nineth_independent_variable_value){
            
             $q = "select a.option_id as `id`, a.response as `option`, count(b.response)/$total_response*100 as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid
                    JOIN feedback_template_option_response e ON d.trans_refid=e.trans_refid
                    JOIN feedback_template_option_response f ON e.trans_refid=f.trans_refid 
                    JOIN feedback_template_option_response g ON f.trans_refid=g.trans_refid
                    JOIN feedback_template_option_response h ON g.trans_refid=h.trans_refid
                    JOIN feedback_template_option_response i ON h.trans_refid=i.trans_refid
                    JOIN feedback_template_option_response j ON i.trans_refid=j.trans_refid
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%')$univariate_advance_fourth_variable_condition
                    e.response like '%$univariate_advance_fourth_independent_variable_value%')$univariate_advance_fifth_variable_condition 
                    f.response like '%$univariate_advance_fifth_independent_variable_value%')$univariate_advance_sixth_variable_condition 
                    g.response like '%$univariate_advance_sixth_independent_variable_value%')$univariate_advance_seventh_variable_condition 
                    h.response like '%$univariate_advance_seventh_independent_variable_value%')$univariate_advance_eighth_variable_condition 
                   i.response like '%$univariate_advance_eighth_independent_variable_value%')$univariate_advance_nineth_variable_condition 
                   j.response like '%$univariate_advance_nineth_independent_variable_value%')and     
                   (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number) group by a.response order by a.option_id";
                       
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
            
        }
        
        
        
        /**
         * This is the function that retrieves all feedback responses base on ten condition
         */
        public function retrieveTheTotalNumberOfConditionalResponseForEachOptionWithTenCondtionsInPercentages($total_response,$issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value,$univariate_advance_nineth_variable_condition,$univariate_advance_nineth_independent_variable_type,$univariate_advance_nineth_independent_variable_question_number,$univariate_advance_nineth_independent_variable_value,$univariate_advance_tenth_variable_condition,$univariate_advance_tenth_independent_variable_type,$univariate_advance_tenth_independent_variable_question_number,$univariate_advance_tenth_independent_variable_value){
            
             $q = "select a.option_id as `id`, a.response as `option`, count(b.response)/$total_response*100 as response from feedback_template_option_response a 
                    JOIN feedback_template_option_response b ON a.trans_refid=b.trans_refid
                    JOIN feedback_template_option_response c ON b.trans_refid=c.trans_refid
                    JOIN feedback_template_option_response d ON c.trans_refid=d.trans_refid
                    JOIN feedback_template_option_response e ON d.trans_refid=e.trans_refid
                    JOIN feedback_template_option_response f ON e.trans_refid=f.trans_refid 
                    JOIN feedback_template_option_response g ON f.trans_refid=g.trans_refid
                    JOIN feedback_template_option_response h ON g.trans_refid=h.trans_refid
                    JOIN feedback_template_option_response i ON h.trans_refid=i.trans_refid
                    JOIN feedback_template_option_response j ON i.trans_refid=j.trans_refid
                    JOIN feedback_template_option_response k ON j.trans_refid=k.trans_refid
                    where (a.template_id=$template_id $univariate_advance_first_variable_condition
                    b.response like '%$univariate_advance_first_independent_variable_value%' $univariate_advance_second_variable_condition
                    c.response like '%$univariate_advance_second_independent_variable_value%')$univariate_advance_third_variable_condition 
                    d.response like '%$univariate_advance_third_independent_variable_value%')$univariate_advance_fourth_variable_condition
                    e.response like '%$univariate_advance_fourth_independent_variable_value%')$univariate_advance_fifth_variable_condition 
                    f.response like '%$univariate_advance_fifth_independent_variable_value%')$univariate_advance_sixth_variable_condition 
                    g.response like '%$univariate_advance_sixth_independent_variable_value%')$univariate_advance_seventh_variable_condition 
                    h.response like '%$univariate_advance_seventh_independent_variable_value%')$univariate_advance_eighth_variable_condition 
                   i.response like '%$univariate_advance_eighth_independent_variable_value%')$univariate_advance_nineth_variable_condition 
                   j.response like '%$univariate_advance_nineth_independent_variable_value%')$univariate_advance_tenth_variable_condition
                   k.response like '%$univariate_advance_tenth_independent_variable_value%')and     
                   (a.response_date between '$start_date' AND '$end_date') and (a.question_number=$question_number) group by a.response order by a.option_id";
                       
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
            
             
             return $result;
            
        }
        
        /**
         * This is the function that retrieves the response to a question
         */
        public function getTheResponseToThisQuestionByThisUser($template_id,$question_number,$reference_id,$issue_type){
            
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='template_id=:tempid and trans_refid=:refid';
            $criteria->params = array(':tempid'=>$template_id,':refid'=>$reference_id);
            $response= FeedbacksTemplateResponse::model()->find($criteria);
            
            if($question_number == 1){
                if($issue_type == 'short_text'){
                    return $response['first_feedback_response_text'];
                }else if($issue_type == 'long_text'){
                    return $response['first_feedback_response_text'];
                }else if($issue_type == 'boolean'){
                    return $response['first_feedback_response_boolean'];
                }else if($issue_type =='integer'){
                    return $response['first_feedback_response_integer'];
                }else if($issue_type =='double'){
                    return $response['first_feedback_response_double'];
                }else if($issue_type =='single_option'){
                    return $response['first_feedback_response_single_option'];
                }else if($issue_type =='multiple_option'){
                    return $response['first_feedback_response_multiple_option'];
                }else if($issue_type == 'single_option_number'){
                    return $response['first_feedback_response_single_option_number'];
                }else if($issue_type == 'multiple_option_number'){
                    return $response['first_feedback_response_multiple_option_number'];
                }
            }else if($question_number == 2){
                if($issue_type == 'short_text'){
                    return $response['second_feedback_response_text'];
                }else if($issue_type == 'long_text'){
                    return $response['second_feedback_response_text'];
                }else if($issue_type == 'boolean'){
                    return $response['second_feedback_response_boolean'];
                }else if($issue_type =='integer'){
                    return $response['second_feedback_response_integer'];
                }else if($issue_type =='double'){
                    return $response['second_feedback_response_double'];
                }else if($issue_type =='single_option'){
                    return $response['second_feedback_response_single_option'];
                }else if($issue_type =='multiple_option'){
                    return $response['second_feedback_response_multiple_option'];
                }else if($issue_type == 'single_option_number'){
                    return $response['second_feedback_response_single_option_number'];
                }else if($issue_type == 'multiple_option_number'){
                    return $response['second_feedback_response_multiple_option_number'];
                }
                
                
            }else if($question_number == 3){
                if($issue_type == 'short_text'){
                    return $response['third_feedback_response_text'];
                }else if($issue_type == 'long_text'){
                    return $response['third_feedback_response_text'];
                }else if($issue_type == 'boolean'){
                    return $response['third_feedback_response_boolean'];
                }else if($issue_type =='integer'){
                    return $response['third_feedback_response_integer'];
                }else if($issue_type =='double'){
                    return $response['third_feedback_response_double'];
                }else if($issue_type =='single_option'){
                    return $response['third_feedback_response_single_option'];
                }else if($issue_type =='multiple_option'){
                    return $response['third_feedback_response_multiple_option'];
                }else if($issue_type == 'single_option_number'){
                    return $response['third_feedback_response_single_option_number'];
                }else if($issue_type == 'multiple_option_number'){
                    return $response['third_feedback_response_multiple_option_number'];
                }
                
            }else if($question_number == 4){
                if($issue_type == 'short_text'){
                    return $response['fourth_feedback_response_text'];
                }else if($issue_type == 'long_text'){
                    return $response['fourth_feedback_response_text'];
                }else if($issue_type == 'boolean'){
                    return $response['fourth_feedback_response_boolean'];
                }else if($issue_type =='integer'){
                    return $response['fourth_feedback_response_integer'];
                }else if($issue_type =='double'){
                    return $response['fourth_feedback_response_double'];
                }else if($issue_type =='single_option'){
                    return $response['fourth_feedback_response_single_option'];
                }else if($issue_type =='multiple_option'){
                    return $response['fourth_feedback_response_multiple_option'];
                }else if($issue_type == 'single_option_number'){
                    return $response['fourth_feedback_response_single_option_number'];
                }else if($issue_type == 'multiple_option_number'){
                    return $response['fourth_feedback_response_multiple_option_number'];
                }
                
                
            }else if($question_number == 5){
                if($issue_type == 'short_text'){
                    return $response['fifth_feedback_response_text'];
                }else if($issue_type == 'long_text'){
                    return $response['fifth_feedback_response_text'];
                }else if($issue_type == 'boolean'){
                    return $response['fifth_feedback_response_boolean'];
                }else if($issue_type =='integer'){
                    return $response['fifth_feedback_response_integer'];
                }else if($issue_type =='double'){
                    return $response['fifth_feedback_response_double'];
                }else if($issue_type =='single_option'){
                    return $response['fifth_feedback_response_single_option'];
                }else if($issue_type =='multiple_option'){
                    return $response['fifth_feedback_response_multiple_option'];
                }else if($issue_type == 'single_option_number'){
                    return $response['fifth_feedback_response_single_option_number'];
                }else if($issue_type == 'multiple_option_number'){
                    return $response['fifth_feedback_response_multiple_option_number'];
                }
                
                
            }
        }
        
        
}
