# ext-theme-neptune-9f4bcb7c-6e62-49ee-bf6d-ab0a615c20f7/resources

This folder contains static resources (typically an `"images"` folder as well).
