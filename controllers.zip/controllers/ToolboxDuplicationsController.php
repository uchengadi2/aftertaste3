<?php

class ToolboxDuplicationsController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','ListAllToolboxesInThisDomain','CreateNewToolboxDuplication',
                                    'UpdateToolboxDuplication','DeleteOneDuplicateToolbox','ListAllDuplicatedToolboxes',
                                    'ListAllDuplicatedToolboxesInThisDomain','retrieveOriginalToolboxName','obtainTheMainOriginalToolboxId',
                                    'justtesting','retrieveTheOriginalToolboxIdForThisToolbox','ListAllToolsInThisToolbox',
                                    'DeleteOneToolFromDuplicatedToolbox','AddNewToolToDuplicateToolbox','isPermittedToRemoveToolFromToolboxByThisDomain',
                                    'isPermittedToAddToolToToolboxByThisDomain','retrieveReconstructableToolboxValue'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that retrieves all toolboxes assigned to this domain
         */
        public function actionListAllToolboxesInThisDomain(){
            
            //get the id of the logged in user
            $userid = Yii::app()->user->id;
            
            $domainid = $this->determineAUserDomainIdGiven($userid);
            
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='category_id=:id';
            $criteria->params = array(':id'=>$domainid);
            $toolboxes = ResourcegroupHasResourcegroupcategory::model()->findAll($criteria);
            
            $all_toolboxes = [];
            
            foreach($toolboxes as $toolbox){
                $criteria1 = new CDbCriteria();
                $criteria1->select = '*';
                $criteria1->condition='id=:id';
                $criteria1->params = array(':id'=>$toolbox['resourcegroup_id']);
                $toolboxname = Resourcegroup::model()->find($criteria1);
                
                $all_toolboxes[] = $toolboxname;
            }
            
            if($all_toolboxes===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "toolbox" => $all_toolboxes
                          
                           
                           
                          
                       ));
                       
                }
        }
        
        
        /**
         * This is the function that creates new toolbox duplication
         */
        public function actionCreateNewToolboxDuplication(){
            
            $model=new ToolboxDuplications;
            
            //get the logged in user id
            $userid = Yii::app()->user->id;
            
            //determine the domain of the logged in user
            $domainid = $this->determineAUserDomainIdGiven($userid);
            
            if(is_numeric($_POST['original_toolbox'])){
               $model->original_toolbox_id = $_POST['original_toolbox'];
            }else{
                $model->original_toolbox_id = $_POST['original_toolbox_id'];
            }
             $model->name = $_POST['name'];
          
            if(isset($_POST['duplicate'])){
                $model->duplicate = $_POST['duplicate'];
            }else{
                $model->duplicate = 0;
            }
            if(isset($_POST['reconstruct_toolbox'])){
                $model->reconstruct_toolbox = $_POST['reconstruct_toolbox'];
            }else{
                $model->reconstruct_toolbox = 0;
            }
            
            //retrieve all the values from the original toolbox and assign to the duplicate toolbox
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$model->original_toolbox_id);
            $original = Resourcegroup::model()->find($criteria);
            
            $model->price = $original['price'];
            $model->discount_rate = $original['discount_rate'];
            $model->is_duplicate = 1;
            $model->discount_proof = $original['discount_proof'];
            $model->select_value = $original['select_value'];
            $model->cumulative_component_price = $original['cumulative_component_price'];
            $model->price_preference = $original['price_preference'];
            if(isset($_POST['description'])){
                 $model->description = $_POST['description'];
             }else{
                 $model->description = $original['description'];
             }
             if(isset($_POST['visibility'])){
                  $model->visibility = strtolower($_POST['visibility']);
             }else{
                 $model->visibility = $original['visibility'];
             }
            $model->create_user_id = $userid;
            $model->create_time = new CDbExpression('NOW()');
            $model->domain_id = $domainid;
            
            //obtain the domain of the user that created the toolbox
            $toolbox_domain_id = $this->determineAUserDomainIdGiven($original['create_user_id']); 
            
            if($model->save()){
                        if($this->assignSameToolsToThisToolbox($model->id,$model->original_toolbox_id,$domainid,$toolbox_domain_id)){
                            $msg = "$original->name Folder was successfully duplicated";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                            );
                        }else{
                            $msg = "Some or all of the files from $original->name folder was not assigned to the duplicate";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                            ); 
                        }
                           
                           
                       
                        
                 }else {
                         //$result['success'] = 'false';
                         $msg = "Validation Error: Folder Duplication was not successful";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  } 
            
        }
        
        /**
         * This is the function that is used to edit the duplicates of a toolbox
         */
        public function actionUpdateToolboxDuplication(){
            
                     
            $_id = $_POST['id'];
            $model=ToolboxDuplications::model()->findByPk($_id);
            
            //get the logged in user id
            $userid = Yii::app()->user->id;
             $domainid = $this->determineAUserDomainIdGiven($userid);
             
             if(is_numeric($_POST['original_toolbox'])){
               $model->original_toolbox_id = $_POST['original_toolbox'];
            }else{
                $model->original_toolbox_id = $_POST['original_toolbox_id'];
            }
             $model->name = $_POST['name'];
          
            if(isset($_POST['duplicate'])){
                $model->duplicate = $_POST['duplicate'];
            }else{
                $model->duplicate = 0;
            }
            if(isset($_POST['reconstruct_toolbox'])){
                $model->reconstruct_toolbox = $_POST['reconstruct_toolbox'];
            }else{
                $model->reconstruct_toolbox = 0;
            }
            
            //retrieve all the values from the original toolbox and assign to the duplicate toolbox
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$model->original_toolbox_id);
            $original = Resourcegroup::model()->find($criteria);
            
            $model->price = $original['price'];
            $model->discount_rate = $original['discount_rate'];
            $model->is_duplicate = 1;
            $model->discount_proof = $original['discount_proof'];
            $model->select_value = $original['select_value'];
            $model->cumulative_component_price = $original['cumulative_component_price'];
            $model->price_preference = $original['price_preference'];
            if(isset($_POST['description'])){
                 $model->description = $_POST['description'];
             }else{
                 $model->description = $original['description'];
             }
             if(isset($_POST['visibility'])){
                  $model->visibility = strtolower($_POST['visibility']);
             }else{
                 $model->visibility = $original['visibility'];
             }
            $model->update_user_id = $userid;
            $model->update_time = new CDbExpression('NOW()');
            $model->domain_id = $domainid;
            
            //obtain the domain of the user that created the toolbox
            //$toolbox_domain_id = $this->determineAUserDomainIdGiven($original['create_user_id']);
            
            if($model->save()){
                           $msg = "$model->name duplicate folder was successfully updated";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                            );
                       
                        
                 }else {
                         //$result['success'] = 'false';
                         $msg = "Validation Error: $model->name folder Duplication update was not successful";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  } 
        
        }
        
        
        /**
         * This is the function that list all duplicate toolboxes for this domain
         */
        public function actionListAllDuplicatedToolboxesInThisDomain(){
            
              //obtain the id of the logged in user
            $userid = Yii::app()->user->id;
            
            $domainid = $this->determineAUserDomainIdGiven($userid);
            
            if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin")|| $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformToolboxDuplicationSupport")){
                $criteria3 = new CDbCriteria();
                $criteria3->select = '*';
                $criteria3->condition='is_duplicate=:duplicate';
                $criteria3->params = array(':duplicate'=>1);
                $toolboxes = Resourcegroup::model()->findAll($criteria3);
                
                if($toolboxes===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "toolbox" => $toolboxes
                          
                           
                           
                          
                       ));
                       
                }
                
                
                
            }else{
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='category_id=:id';
                $criteria->params = array(':id'=>$domainid);
                $toolboxes = ResourcegroupHasResourcegroupcategory::model()->findAll($criteria);
            
            $all_toolboxes = [];
            
            foreach($toolboxes as $toolbox){
                $criteria1 = new CDbCriteria();
                $criteria1->select = '*';
                $criteria1->condition='id=:id and is_duplicate=:duplicate';
                $criteria1->params = array(':id'=>$toolbox['resourcegroup_id'],':duplicate'=>1);
                $toolboxname = Resourcegroup::model()->findAll($criteria1);
                
                $all_toolboxes = array_merge($all_toolboxes,$toolboxname);
            }
            
            if($all_toolboxes===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "toolbox" => $all_toolboxes
                          
                           
                           
                          
                       ));
                       
                }
                
                
            }
            
            
            
        }
        
        
        /**
         * This is the function that assigns all tools in the original toolbox to the duplicate toolbox too
         */
        public function assignSameToolsToThisToolbox($duplicate_id,$original_id,$domainid,$toolbox_domain_id){
            
            //assign the duplicate toolbox to the domain
            if($this->isAssignedDuplicateToolboxToDomain($duplicate_id, $domainid,$original_id,$toolbox_domain_id)){
                
                //retrieve all tools in the original toolbox
                $all_tools = [];
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='resourcegroup_id=:id';
                $criteria->params = array(':id'=>$original_id);
                $tools= ResourceHasResourcegroups::model()->findAll($criteria);
                
                foreach($tools as $tool){
                    //assign this tool to this toolbox
                    $this->assignThisToolsToThisDuplicateToolbox($duplicate_id,$tool['resource_id'],$original_id);
                }
                return true;
                
            }else{
                return false;
            }
            
            
        }
        
        
        /**
         * This is the function that assigns the duplicate toolbox to the domain
         */
        public function isAssignedDuplicateToolboxToDomain($duplicate_id, $domainid,$original_id,$original_toolbox_domain_id){
            
            if($this->noOccurrenceOfThisToolboxInDomain($duplicate_id, $domainid)){
                //retrieve all values of the original toolbox in the original domain
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='resourcegroup_id=:id and category_id=:domainid';
                $criteria->params = array(':id'=>$original_id, ':domainid'=>$original_toolbox_domain_id);
                $original_para= ResourcegroupHasResourcegroupcategory::model()->find($criteria);
                
                //Assign this original paras to the new toolbox assignment
                $cmd =Yii::app()->db->createCommand();
                $result = $cmd->insert('resourcegroup_has_resourcegroupcategory',
                	array('resourcegroup_id'=>$duplicate_id,
				'category_id'=>$domainid,
                                'assign_name'=>$original_para['assign_name'],
                                'assign_description'=>$original_para['assign_description'],
                                'start_date'=>$original_para['start_date'],
                                'end_date'=>$original_para['end_date'],
                                'min_date'=>$original_para['min_date'],
                                'max_date'=>$original_para['max_date'],
                                'excluded_days'=>$original_para['excluded_days']
		
			)
			
		);
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return false;
            }
            
            
        }
        
        /**
         * This is the function that verifies if that toolbox is not already assigned to that domain
         */
        public function noOccurrenceOfThisToolboxInDomain($duplicate_id, $domainid){
            
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('resourcegroup_has_resourcegroupcategory')
                    ->where("category_id = $domainid && resourcegroup_id =$duplicate_id");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return false;
                }else{
                    return true;
                }
        }
        
        /**
         * This is the function that assigns tools in the original toolbox to the duplicate toolbox
         */
        public function assignThisToolsToThisDuplicateToolbox($toolbox_id,$tool_id,$original_toolbox_id){
            if($this->noOccurrenceOfThisToolInThisToolbox($toolbox_id,$tool_id)){
                
                //retrieve all values of this tool in the original toolbox
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='resourcegroup_id=:id and resource_id=:resourceid';
                $criteria->params = array(':id'=>$original_toolbox_id, ':resourceid'=>$tool_id);
                $original_para= ResourceHasResourcegroups::model()->find($criteria);
                
                //Assign this original paras to the new toolbox assignment
                $cmd =Yii::app()->db->createCommand();
                $result = $cmd->insert('resource_has_resourcegroups',
                	array('resourcegroup_id'=>$toolbox_id,
				'resource_id'=>$tool_id,
                                'assign_name'=>$original_para['assign_name'],
                                'assign_description'=>$original_para['assign_description'],
                                'start_date'=>$original_para['start_date'],
                                'end_date'=>$original_para['end_date'],
                                'min_date'=>$original_para['min_date'],
                                'max_date'=>$original_para['max_date'],
                                'excluded_days'=>$original_para['excluded_days']
		
			)
			
		);
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return false;
            }
            
        }
        
        
        /**
         * This is the function that verifies that this tool is not already in this toolbox
         */
        public function noOccurrenceOfThisToolInThisToolbox($toolbox_id,$tool_id){
            
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('resource_has_resourcegroups')
                    ->where("resource_id = $tool_id && resourcegroup_id =$toolbox_id");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return false;
                }else{
                    return true;
                }
        }
        
        /**
         * This is the function that retreives the name of the original toolbox
         */
        public function actionRetrieveOriginalToolboxName(){
            
            $original_toolbox_id = $_POST['original_id'];
            $id = $_POST['id'];
            
             //get the id of the logged in user
            $user_id = Yii::app()->user->id;
            
            //get the domain of the logged in user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            //retrieve the preferred currency for this domain
            
            $preferred_currency = $this->getThisDomainPreferredCurrency($domain_id);
            
            //get the prefferred currency code
            
            $currency_code = $this->getThisCurrencyCode($preferred_currency);
            
            //get the platform base currency
            $base_currency = $this->getThePlatformBaseCurrency();
            
            //retrieve the name of the original toolbox
           if($this->isOriginalNotAlsoADuplicate($original_toolbox_id)){
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='id=:id';
               $criteria->params = array(':id'=>$original_toolbox_id);
               $original_name= Resourcegroup::model()->find($criteria);
               
               //retrieve other parameters
               $criteria3 = new CDbCriteria();
               $criteria3->select = '*';
               $criteria3->condition='id=:id';
               $criteria3->params = array(':id'=>$original_toolbox_id);
               $other_parameters= Resourcegroup::model()->find($criteria3);
               
               
               if($base_currency == $preferred_currency){
                //get the toolbox price
                $price = $this->getTheOriginalToolboxPrice($original_toolbox_id);
            }else{
                //retrieve the exchange rate of the preferred currency
                        $dprice = $this->getTheOriginalToolboxPrice($original_toolbox_id);
                        $exchange_rate = $this->getThePreferredCurrencyExchangeRate($preferred_currency,$base_currency);
                        //divide the value by the exchange rate to get the dollar value
                        $new_value = ((double)$dprice) * ((double)$exchange_rate);
                        $price = $new_value;
            }
            
                if($original_name===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "toolboxname" => $original_name,
                           "original"=>$other_parameters,
                           "price"=>$price,
                           "currency_code"=>$currency_code
                          
                           
                           
                          
                       ));
                       
                }
            
               
           }else{
               $main_original_id = $this->obtainTheMainOriginalToolboxId($original_toolbox_id);
               //retrieve the name of the duplicate toolbox
               $criteria1 = new CDbCriteria();
               $criteria1->select = '*';
               $criteria1->condition='id=:id';
               $criteria1->params = array(':id'=>$original_toolbox_id);
               $duplicate_name= Resourcegroup::model()->find($criteria1);
               
               //obtain the other details of the main original toolbox
               
               $criteria2 = new CDbCriteria();
               $criteria2->select = '*';
               $criteria2->condition='id=:id';
               $criteria2->params = array(':id'=>$main_original_id);
               $original_name= Resourcegroup::model()->find($criteria2);
               
               
               if($base_currency == $preferred_currency){
                //get the toolbox price
                $price = $this->getTheOriginalToolboxPrice($original_toolbox_id);
            }else{
                //retrieve the exchange rate of the preferred currency
                        $dprice = $this->getTheOriginalToolboxPrice($original_toolbox_id);
                        $exchange_rate = $this->getThePreferredCurrencyExchangeRate($preferred_currency,$base_currency);
                        //divide the value by the exchange rate to get the dollar value
                        $new_value = ((double)$dprice) * ((double)$exchange_rate);
                        $price = $new_value;
            }
               
                if($original_name===null) {
                    //http_response_code(404);
                   // $data['Error'] ='No record found';
                    //echo CJSON::encode($data);
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "toolbox_id" => $main_original_id,
                           "original"=>$original_name,
                           "price"=>$price,
                           "currency_code"=>$currency_code
                               
                          
                           
                           
                          
                       ));
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "toolboxname" => $duplicate_name,
                           "original"=>$original_name,
                           "price"=>$price,
                           "currency_code"=>$currency_code
                          
                           
                           
                          
                       ));
                       
                }
           } 
            
            
        }
        
        
        /**
         * This is the function that determines if a toolbox is not also a duplicate
         * 
         */
        public function isOriginalNotAlsoADuplicate($toolbox_id){
            
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='id=:id';
               $criteria->params = array(':id'=>$toolbox_id);
               $original= Resourcegroup::model()->find($criteria);
               
               if($original['is_duplicate'] == 1){
                   return false;
                   
               }else{
                   return true;
                   
               }
        }
        
        /**
         * This is the function that determines if a toolbox is the root of all the duplicate chain
         */
        public function obtainTheMainOriginalToolboxId($toolbox_id){
            $original = 0;
            if($this->isOriginalNotAlsoADuplicate($toolbox_id)){
                //retrieve its original toolbox
                $original = $this->retrieveTheOriginalToolboxIdForThisToolbox($toolbox_id);
                if($this->isOriginalNotAlsoADuplicate($original)){
                    ;
                    
                }else{
                  $original = $this->obtainTheMainOriginalToolboxId($original);
                }
            }else{
               $original = $this->retrieveTheOriginalToolboxIdForThisToolbox($toolbox_id);
               $original = $this->obtainTheMainOriginalToolboxId($original);
                
            }
             
            return $original;
        }
        
        /**
         * function for testing
         */
        public function actionjusttesting($toolbox_id=2){
            $toolbox_id = $this->obtainTheMainOriginalToolboxId($toolbox_id);
            
            if($toolbox_id===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "toolboxname" => $toolbox_id,
                           //"original"=>$other_parameters
                          
                           
                           
                          
                       ));
                       
                }
        }
        
        /**
         * This is the function that is used to retrieve the original toolbox for a given duplicate toolbox
         */
        public function retrieveTheOriginalToolboxIdForThisToolbox($toolbox_id){
            
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='id=:id';
               $criteria->params = array(':id'=>$toolbox_id);
               $original= Resourcegroup::model()->find($criteria);
               
               return $original['original_toolbox_id'];
               
        }
        
        /**
         * This is the function to delete one duplicated toolbox
         */
        public function actionDeleteOneDuplicateToolbox(){
            
            $_id = $_POST['id'];
            $model=ToolboxDuplications::model()->findByPk($_id);
            if($model === null){
                 $msg = 'No Such Record Exist'; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                                      
            }else if($model->delete()){
                    $msg = 'This Duplicated Folder had been deleted successfully'; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
            } else {
                    $msg = 'Validation Error: This Duplicated Folder was not deleted'; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                            
                }
        }
        
        
        /**
         * This is the function that list all tools in a duplicate toolbox
         */
        public function actionListAllToolsInThisToolbox(){
            
              //obtain the id of the logged in user
            $userid = Yii::app()->user->id;
            
            //$domainid = $this->determineAUserDomainIdGiven($userid);
            
            $toolbox_id = $_REQUEST['id'];
           // $toolbox_id = 84;
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='resourcegroup_id=:id';
            $criteria->params = array(':id'=>$toolbox_id);
            $toolboxes = ResourceHasResourcegroups::model()->findAll($criteria);
            
                       
            if($toolboxes===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "tool" => $toolboxes
                          
                           
                           
                          
                       ));
                       
                }
            
        }
        
        /**
         * This is the function that removes a tool from a toolbox
         */
        public function actionDeleteOneToolFromDuplicatedToolbox(){
            
            $tool_id = $_POST['resource_id'];
            $toolbox_id = $_POST['resourcegroup_id'];
            
            $toolbox_creator = $this->retrieveTheIdOfThePersonThatCreatedThisToolbox($toolbox_id);
            //get the domain of the toolbox creator
            $domainid = $this->determineAUserDomainIdGiven($toolbox_creator);
            
            if($this->isPermittedToRemoveToolFromToolboxByThisDomain($domainid)){
                $cmd =Yii::app()->db->createCommand();  
                $cmd->delete('resource_has_resourcegroups', 'resource_id=:id and resourcegroup_id=:groupid', array(':id'=>$tool_id, ':groupid'=>$toolbox_id ));
            
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>'The File had successfully been removed from the Folder',
                       ));
                
                }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>'The owner of the folder does not permit the removal of files from their folder',
                       ));
                
                }
            
           
        }
        
        
        /**
         * This is the function that determines if a domain permits the removal of tools from duplicated toolbox
         */
        public function isPermittedToRemoveToolFromToolboxByThisDomain($domainid){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='domain_id=:id and status=:status';
            $criteria->params = array(':id'=>$domainid,':status'=>'active');
            $permit = DomainPolicy::model()->find($criteria); 
                          
            if($permit['allow_tool_removal_from_duplicate_reconstructable_toolboxes'] == 1){
                return true;
                
            }else{
                return false;
                
            }
        }
        
         /**
         * This is the function that determines if a domain permits the addition of tools to duplicated toolboxes
         */
        public function isPermittedToAddToolToToolboxByThisDomain($domainid){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='domain_id=:id and status=:status';
            $criteria->params = array(':id'=>$domainid,':status'=>'active');
            $permit = DomainPolicy::model()->find($criteria); 
                          
            if($permit['allow_tool_addition_to_duplicate_reconstructable_toolboxes'] == 1){
                return true;
                
            }else{
                return false;
                 
            }
        }
        
        /**
         * This is the function that retrieves the original creator of the toolbox
         */
        public function retrieveTheIdOfThePersonThatCreatedThisToolbox($toolbox_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$toolbox_id);
            $creator = Resourcegroup::model()->find($criteria); 
            
            return $creator['create_user_id'];
            
        }
        
        /**
         * This is the function that add new tool to a duplicated toolbox
         */
        public function actionAddNewToolToDuplicateToolbox(){
            
            $tool_id = $_POST['tool_id'];
            $toolbox_id = $_POST['id'];
            $assign_name = $_POST['assign_name'];
            $assign_description = $_POST['assign_description'];
            
            $toolbox_creator = $this->retrieveTheIdOfThePersonThatCreatedThisToolbox($toolbox_id);
            //get the domain of the toolbox creator
            $domainid = $this->determineAUserDomainIdGiven($toolbox_creator);
            
            if($this->isPermittedToAddToolToToolboxByThisDomain($domainid)){
                if($this->noOccurrenceOfThisToolInThisToolbox($toolbox_id,$tool_id)){
                   
                    $cmd =Yii::app()->db->createCommand();
                    $result = $cmd->insert('resource_has_resourcegroups',
                	array('resourcegroup_id'=>$toolbox_id,
				'resource_id'=>$tool_id,
                                'assign_name'=>$assign_name,
                                'assign_description'=>$assign_description
                               
		
			)
			
		);
                if($result > 0){
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>'This file is successfully added to the folder',
                       ));
                    
                }else{
                   header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>'This file was not added to the folder',
                       )); 
                }   
                    
                }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>'This file already exist in the folder',
                       ));
                    
                }//tool not already in the toolbox if statement
              }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>'The owner of the folder does not permit the addition of files to their folder',
                       ));
                
                }
            
        }
        
        /**
         * This is the function that retrieves the reconstructable value of a toolbox
         */
        public function actionretrieveReconstructableToolboxValue(){
            
            $toolbox_id = $_REQUEST['id'];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$toolbox_id);
            $recon = Resourcegroup::model()->find($criteria); 
            
            //return $creator['create_user_id'];
            if($recon===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "reconstruct" => $recon['reconstruct_toolbox']
                          
                           
                           
                          
                       ));
                       
                }
            
        }
        
        /**
         * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainIdGiven_old($userid){
            
            //determine the usertype id of the user
            $typeid = $this->determineAUserUsertypeId($userid);
            //determine the usertype name of this usertypeid
            $typename = $this->determineUserTypeName($typeid);
            
            //determine the domain id given usertype name
            $domainid = $this->determineDomainIdGiveUsertypeName($typename);
            
            //determine the domain name given its id
            $name = $this->determineDomainNameGivenItId($domainid);
            //determine the domain id given its name
            $domainname = $this->determineDomainIdGivenItsName($name);
            
            return $domainname;
            
            
        }
        
        
         /**
         * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainIdGiven($userid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$userid);
            $user= User::model()->find($criteria1);
            
            return $user['domain_id'];
        }
        
        
              
        /**
         * this is the function that retrieves the grouptype id given domain name
         */
        public function determineGrouptypeIdGivenDomainName($domainname){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='name=:name';
            $criteria->params = array(':name'=>$domainname);
            $grouptypeid= GroupType::model()->find($criteria);
            
            return $grouptypeid['id'];
            
            
        }
           
        /**
         * Determine a users usertype_id
         */
        public function determineAUserUsertypeId($userid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, usertype_id';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$userid);
            $usertype= User::model()->find($criteria);
            
            return $usertype['usertype_id'];
            
            
        }
        
        /*
         * Determine a usertype name given its id
         */
        public function determineUserTypeName($usertypeid){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$usertypeid);
            $name= UserType::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /*
         *  determine a usertype id given its name
         */
        public function determineUsertypeNameGiveId($usertypename){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$usertypename);
            $id= UserType::model()->find($criteria1);
            
            return $id['id'];
        }
        
        /*
         * Determine a domain name given a usetypername
         */
        public function determineDomainNameGiveUsertypeName($usertypename){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$usertypename);
            $name= ResourcegroupCategory::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /*
         * Determine a domain id given a usetypername
         */
        public function determineDomainIdGiveUsertypeName($usertypename){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$usertypename);
            $id= ResourcegroupCategory::model()->find($criteria1);
            
            return $id['id'];
            
        }
        
        
        /**
         * Determine a domain id given its name
         */
        public function determineDomainIdGivenItsName($name){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$name);
            $id= ResourcegroupCategory::model()->find($criteria1);
            
            return $id['id'];
            
        }
        
        /**
         * Determine a domain name given its id
         */
        public function determineDomainNameGivenItId($domainid){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$domainid);
            $name= ResourcegroupCategory::model()->find($criteria1);
            
            return $name['name'];
            
            
        }
        
        /**
         * This is the function that retrieves a resource/tool id given its name
         */
        public function determineResourceOrToolId($toolname){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$toolname);
            $id= Resources::model()->find($criteria1);
            
            return $id['id'];
            
        }
        
        
        /**
         * This is the function that retrieves a resource/tool name given its id
         */
        public function determineResourceOrToolName($toolid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$toolid);
            $name= Resources::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /**
         * This is the function that retrieves a resource/tool name given its id
         */
        public function determineGrouptypeGivenDomainId($domainid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$domainid);
            $name= GroupType::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /**
         * This is the function the retrieves a group id given the group name
         */
        public function determineGroupIdGivenGroupName($groupname,$domainid){
            
            //obtain the grouptype id given a domain id
            $grouptype_id = $this->determineGrouptypeIdGivenDomainId($domainid);
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='name=:name and grouptype_id=:id';
            $criteria->params = array(':name'=>$groupname, ':id'=>$grouptype_id);
            $id= Group::model()->find($criteria);
            
            return $id['id'];
            
            
        }
        
        /**
         * This is the function to retrieve subgroup id given subgroup name
         */
        public function determineSubgroupIdGivenSubgroupName($subgroupname, $domainid){
            //determine the group for this subgroup            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name, group_id';
            $criteria->condition='name=:name';
            $criteria->params = array(':name'=>$subgroupname);
            $groups= SubGroup::model()->findAll($criteria);
            
            foreach($groups as $group){
                $groupdomainid = $this->determineDomainIdGivenGroupId($group['group_id']);
                if($groupdomainid == $domainid){
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = 'id, name';
                    $criteria1->condition='name=:name';
                    $criteria1->params = array(':name'=>$subgroupname);
                    $id= SubGroup::model()->find($criteria1);
                    
                     return $id['id'];
                    
                }
                
                
            }
            
           
            
        }
        
        /**
         * This is the function that determines grouptype is given domain id
         */
        public function determineGrouptypeIdGivenDomainId($domainid){
            
            //determine domain name
            $domainname = $this->determineDomainNameGivenItId($domainid);
            //Determine grouptype id given domain name
            $grouptypeid = $this->determineGrouptypeIdGivenDomainName($domainname);
            
            return $grouptypeid;
            
        }
        
        
        /**
         * This is the function that determines domain id given group id
         */
        public function determineDomainIdGivenGroupId($groupid){
            //determine grouptype id given group id
            $grouptypeid = $this->determineGrouptypeIdGivenGroupId($groupid);
            //determine domain id given grouptype id
            $domainid = $this->determineDomainIdGivenGrouptypeId($grouptypeid);
            
            return $domainid;
            
            
        }
        
        /**
         * This is the function that determines the grouptypeid given group id
         */
        public function determineGrouptypeIdGivenGroupId($groupid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name, grouptype_id';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$groupid);
            $type= Group::model()->find($criteria);
            
            return $type['grouptype_id'];
            
        }
        
        /**
         * This is the function that returns domain id given grouptype id
         */
        public function determineDomainIdGivenGrouptypeId($grouptypeid){
            
            //determine the grouptype name
            $typename = $this->determineGrouptypeNameGivenGrouptypeId($grouptypeid);
            
            $domainname = $this->determineDomainNameGivenGrouptypeName($typename);
           
            //determine domain id given its id
            $domainid = $this->determineDomainIdGivenItsName($domainname);
            
            return $domainid;
            
            
        }
        
        /**
         * This is the function that determines grouptype name given its id
         **/
        public function determineGrouptypeNameGivenGrouptypeId($typeid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$typeid);
            $type= GroupType::model()->find($criteria);
            
            return $type['name'];
            
        }
        
        /**
         * This is the function that determines domain name given grouptype name
         */
        public function determineDomainNameGivenGrouptypeName($typename){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='name=:name';
            $criteria->params = array(':name'=>$typename);
            $domain= ResourcegroupCategory::model()->find($criteria);
            
            return $domain['name'];
            
        }
        
        /**
         * This is the function that obtains a toolbox name given its id 
         */
        public function determineToolboxNameGivenItsId($toolboxid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$toolboxid);
            $toolbox= Resourcegroup::model()->find($criteria);
            
            return $toolbox['name'];
            
        }
        
        
        /**
         * This is the function that obtains a toolbox id given its name
         */
        public function determineToolboxIdGivenItsName($toolboxname){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='name=:name';
            $criteria->params = array(':name'=>$toolboxname);
            $toolbox= Resourcegroup::model()->find($criteria);
            
            return $toolbox['id'];
            
        }
        
        
        /**
         * get the preferred currency code
         */
        public function getThisCurrencyCode($preferred_currency){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$preferred_currency);
            $currency = Currencies::model()->find($criteria); 
            
            return $currency['currency_code'];
        }
        
        
        /**
         * This is the function that gets the resource type name
         */
        public function getTheResourcetypeName($resourcetype_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';  
            $criteria->params = array(':id'=>$resourcetype_id);
            $type = ResourceType::model()->find($criteria);
            
            return $type['name'];
            
        }
        
        
        /**
         * This is the function that gets the platform base currency
         */
        public function getThePlatformBaseCurrency(){
            
                     $criteria = new CDbCriteria();
                     $criteria->select = '*';
                    // $criteria->condition='country_id=:id';
                   //  $criteria->params = array(':id'=>$country_id);
                     $platform= PlatformSettings::model()->find($criteria);
                     
                     return $platform['platform_default_currency_id'];
            
        }
        
        /**
         * This is the function that gets the exchange rate of a currency
         */
        public function getThePreferredCurrencyExchangeRate($currency,$base_currency){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='base_currency_id=:baseid and currency_id=:currencyid';
            $criteria->params = array(':baseid'=>$base_currency,':currencyid'=>$currency);
            $currency= CurrencyExchange::model()->find($criteria);
            
            return $currency['exchange_rate'];
        }
        
        
        /**
         * This is the function that gets the tool or task price from the original resource
         */
        public function getTheOriginalToolboxPrice($original_toolbox_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$original_toolbox_id);
            $toolbox = Resourcegroup::model()->find($criteria); 
            
            return $toolbox['price'];
            
        }
        
        /**
         * This is the function that gets the preferred currency for a domain
         */
        public function getThisDomainPreferredCurrency($domain_id){
            
                     $criteria = new CDbCriteria();
                     $criteria->select = '*';
                     $criteria->condition='domain_id=:id and status="active"';
                     $criteria->params = array(':id'=>$domain_id);
                     $domain= DomainPolicy::model()->find($criteria);
                     
                     return $domain['domain_currency_preference'];
            
            
        }
        
        
         /**
         * This is a function that determines if a user has a particular privilege assigned to him
         */
        public function determineIfAUserHasThisPrivilegeAssigned($userid, $privilegename){
            
             $allprivileges = [];
            //spool all the privileges assigned to a user
                $criteria7 = new CDbCriteria();
                $criteria7->select = 'itemname, userid';
                $criteria7->condition='userid=:userid';
                $criteria7->params = array(':userid'=>$userid);
                $priv= AuthAssignment::model()->find($criteria7);
                
                //retrieve all the children of the role
                
                $criteria = new CDbCriteria();
                $criteria->select = 'child';
                $criteria->condition='parent=:parent';
                $criteria->params = array(':parent'=>$priv['itemname']);
                $allprivs= Authitemchild::model()->findAll($criteria);
                 
                //check to see if this privilege exist for this user
                foreach($allprivs as $pris){
                    if($this->privilegeType($pris['child'])== 0){
                        $allprivileges[] = $pris['child'];
                        
                    }elseif($this->privilegeType($pris['child'])== 1){
                        
                       $allprivileges[] = $this->retrieveAllTaskPrivileges($pris['child']); 
                    }elseif($this->privilegeType($pris['child'])== 2){
                        
                        $allprivileges[] = $this->retrieveAllRolePrivileges($pris['child']);
                    }
                    
                    
                    
                    
                }
               
                
                if(in_array($privilegename, $allprivileges)){
                    
                    return true;
                     
                }else{
                    
                    return false;
                     
                }
      
        }
        
        
          /**
         * This is the function that determines a privilege type
         */
        public function privilegeType($privname){
            
            $criteria7 = new CDbCriteria();
                $criteria7->select = 'name, type';
                $criteria7->condition='name=:name';
                $criteria7->params = array(':name'=>$privname);
                $privs= Authitem::model()->find($criteria7);
                
                return $privs['type'];
                
                
        }
        
        
         /**
         * This is the function that returns all member privileges of a task
         */
        public function retrieveAllTaskPrivileges($task){
            
            $member = [];
            
                $criteria = new CDbCriteria();
                $criteria->select = 'child';
                $criteria->condition='parent=:parent';
                $criteria->params = array(':parent'=>$task);
                $allprivs= Authitemchild::model()->findAll($criteria);
                
                foreach($allprivs as $privs){
                    if($this->privilegeType($privs['child'])== 0){
                         $member[] = $privs['child'];
                        
                    }elseif($this->privilegeType($privs['child'])== 1){
                        
                        $member[] = $this->retrieveAllTaskPrivileges($privs['child']); 
                    }
                   
                    
                }
              return $member;
               
            
        }
        
        /**
         * This is the function that returns all members in a role
         */
        public function retrieveAllRolePrivileges($role){
            
            $member = [];
            
                $criteria = new CDbCriteria();
                $criteria->select = 'child';
                $criteria->condition='parent=:parent';
                $criteria->params = array(':parent'=>$role);
                $allprivs= Authitemchild::model()->findAll($criteria);
                
                foreach($allprivs as $privs){
                    if($this->privilegeType($privs['child'])== 0){
                         $member[] = $privs['child'];
                        
                    }elseif($this->privilegeType($privs['child'])== 1){
                        
                        $member[] = $this->retrieveAllTaskPrivileges($privs['child']); 
                    }elseif($this->privilegeType($privs['child'])== 2){
                        
                        $member[] = $this->retrieveAllRolePrivileges($privs['child']); 
                    }
                   
                    
                }
              return $member;
                
            
        }
        

	/**
	 * Returns the data model based on the primary key given in the GET variable.
	 * If the data model is not found, an HTTP exception will be raised.
	 * @param integer $id the ID of the model to be loaded
	 * @return ToolboxDuplications the loaded model
	 * @throws CHttpException
	 */
	public function loadModel($id)
	{
		$model=ToolboxDuplications::model()->findByPk($id);
		if($model===null)
			throw new CHttpException(404,'The requested page does not exist.');
		return $model;
	}

	/**
	 * Performs the AJAX validation.
	 * @param ToolboxDuplications $model the model to be validated
	 */
	protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='toolbox-duplications-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
}
