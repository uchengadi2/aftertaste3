<?php

class PreviewTrailController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','registerThisPreviewEntry','registerClosingPreviewEntry'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	
	/**
         * Register this preview audit trail
         */
        public function actionRegisterThisPreviewEntry(){
            $model = new PreviewTrail;
            
            $user_id = Yii::app()->user->id;
            $model->media_id = $_REQUEST['id'];
            
            $model->user_id = $user_id;
            
            $model->start_time = new CDbExpression('NOW()');
            
             //get all other trailer information
            $model->session_id = $this->getThisMediaSlotSessionId( $model->media_id);
            $model->user_city_id = $this->getThisPreviewerOrDownloaderCity($user_id);
            $model->user_country_id = $this->getTheCountryOfThisPreviewerOrDownloader($user_id);
            $model->user_domain_id = $this->getThisPreviewerOrDownloaderDomain($user_id);
            
            //insert into the preview audit trail table
           if($model->save()){
               $msg = "Successful audit trail capture";
               header('Content-Type: application/json');
               echo CJSON::encode(array(
                      "success" => mysql_errno() == 0,
                       "msg" => $msg
                       ));
           }else{
                $msg = "preview audit trail not captured successfully";
               header('Content-Type: application/json');
               echo CJSON::encode(array(
                      "success" => mysql_errno() != 0,
                       "msg" => $msg
                       ));
           }
            
    
	
        }
        
        
        /**
         * This is the function that registers the closing preview audit trails
         */
        public function actionRegisterClosingPreviewEntry(){
            
             $user_id = Yii::app()->user->id;
             $media_id = $_REQUEST['id'];
             
             $stop_time = new CDbExpression('NOW()');
            
             if($this->isMediaCurrentlyOpenedForPreview($media_id,$user_id)){
                 //get the ids of the opened preview media
                 $trail_ids = $this->getTheCurrentlyOpenedPreviewMedia($media_id,$user_id);
                 
                 if(is_array($trail_ids)){
                     foreach($trail_ids as $id ){
                         //update this trail
                         $this->updateTheClosingTimeOfThisTrail($id,$stop_time);
                     }
                 }else{
                     //update the closing time of this trail
                     $this->updateTheClosingTimeOfThisTrail($id,$stop_time);
                 }
                 
                 
             }
            
             
        }
        
        
      /**
       * This is the function that determines if media is still currently opened
       */  
        public function isMediaCurrentlyOpenedForPreview($media_id,$user_id){
            
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('preview_trail')
                    ->where("(media_id = $media_id and user_id=$user_id) and stop_time is NULL");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        /**
         * This is the function that gets all the currently opened preview media
         */
        public function getTheCurrentlyOpenedPreviewMedia($media_id,$user_id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='(media_id=:mediaid and user_id=:userid) and stop_time is null';
                $criteria->params = array(':mediaid'=>$media_id,':userid'=>$user_id);
                $ids = PreviewTrail::model()->findAll($criteria); 
                
                $all_ids = [];
                foreach($ids as $id){
                    $all_ids[] = $id['id'];
                }
                return $all_ids;
        }
        
        
        /**
         * This is the function that performs the actual update of the trail
         */
        public function updateTheClosingTimeOfThisTrail($id,$stop_time){
            
             $cmd =Yii::app()->db->createCommand();
             $result = $cmd->update('preview_trail',
                          array(
                            'stop_time'=>$stop_time
                                     
      
                            ),
                     ("id=$id"));
        }
        
        
        
        /**
         * This is the function that gets the session id of a media slot
         */
        public function getThisMediaSlotSessionId($media_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$media_id);
            $session= Resources::model()->find($criteria);
            
            return $session['parent_id'];
            
        }
        
        
        /**
         * This is the function that gets the  city of the downloader or previewer
         */
        public function getThisPreviewerOrDownloaderCity($user_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$user_id);
            $user= User::model()->find($criteria);
            
            return $user['city_id'];
        }
        
        /**
         * This is the function that gets the state/county of the downloader or previewer
         */
       public function getTheStateOfThisPreviewerOrDownloader($user_id){
           
           $city_id = $this->getThisPreviewerOrDownloaderCity($user_id);
           
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$city_id);
            $city= City::model()->find($criteria);
            
            return $city['state_id'];
           
       }
       
       
       /**
        * This is the function that gets the previewer or downloader domain id
        */
       public function getThisPreviewerOrDownloaderDomain($user_id){
           
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$user_id);
            $user= User::model()->find($criteria);
            
            return $user['domain_id'];
       }
       
       
         /**
        * This is the function that gets the country id of the previewer or downloader
        */
       public function getTheCountryOfThisPreviewerOrDownloader($user_id){
           
           $state_id = $this->getTheStateOfThisPreviewerOrDownloader($user_id);
           
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$state_id);
            $country= State::model()->find($criteria);
            
            return $country['country_id']; 
           
       }
}
