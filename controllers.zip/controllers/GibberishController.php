<?php

class GibberishController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','AddNewGibberish','UpdateGibberish','DeleteOneGibberish',
                                    'listPlatformgibberish','listDomaingibberish'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	
        
        /**
         * This is the function that adds a new gibberish
         */
        public function actionAddNewGibberish(){
            
            $model = new Gibberish;
            
            $user_id = Yii::app()->user->id;
            
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            
            $domain_name = $this->getTheNameOfThisDomain($domain_id);
            
                       
            $model->name = $_POST['name'];
            $model->description = $_POST['description'];
            $model->domain_id = $domain_id;
            $model->create_time = new CDbExpression('NOW()');
            $model->create_user_id = Yii::app()->user->id;
            
            $file_error_counter = 0;
             if($_FILES['filename']['name'] != ""){
                    if($this->isDocumentTypeAndSizeLegal()){
                       $filename = $_FILES['filename']['name'];
                       $filesize = $_FILES['filename']['size'];
                       
                    }else{
                          $file_error_counter = $file_error_counter + 1;
                         
                        
                    }//end of the determine size and type statement
                }else{
                   $filename = null;
                   $filesize = 0;
                   
                }   
                
               if(($file_error_counter ==0)){
                     
                 $model->filename = $this->moveTheGibberishDocumentToItsPathAndReturnTheDocumentFilename($model,$filename); 
                   
                 if($model->save()){
                   $msg = "Successfully created the  '$model->name' gibberish";
                        header('Content-Type: application/json');
                        echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                             "msg" => $msg
                         ));
                    }else{
                     $msg = "'$model->name' gibberish could not be created";
                    header('Content-Type: application/json');
                    echo CJSON::encode(array(
                        "success" => mysql_errno() != 0,
                         "msg" => $msg
                      ));
           } 
            
                   
                 }else if($file_error_counter > 0){
                    //get the platform settings for this property
                    $max_gibberish_file_size = $this->retrieveTheMaximumGibberishFileSize();
                    $msg = "Please check your document file type or size as the maximum allowable file size is '$max_gibberish_file_size'kb and types must be a pdf document";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                           "success" => mysql_errno() != 0,
                             "msg" => $msg)
                       );
                 }      
            
            
        }
        
        
        /**
         * This is the function that moves the gibberish document to its path and returns its  filename
         */
        public function moveTheGibberishDocumentToItsPathAndReturnTheDocumentFilename($model,$filename){
            
                     
            if(isset($_FILES['filename']['name'])){
                        $tmpName = $_FILES['filename']['tmp_name'];
                        //$videoName = $_FILES['filename']['name'];    
                        $filetype = $_FILES['filename']['type'];
                        $filesize = $_FILES['filename']['size'];
                  
                    }
                    
                    if($filename !== null) {
                        if($model->id === null){
                            $docFileName = time().'_'.$filename;
                             // upload the video file
                        if($filename !== null){
                           // validate to save file
                               	$documentPath = Yii::app()->params['gibberish'].$docFileName;
				move_uploaded_file($tmpName,  $documentPath);
                                        
                        
                                return $docFileName; 
                        }else{
                            return null;
                        } 
                        }else{
                            if($this->noNewDocumentFileProvided($model->id,$filename)){
                                $docFileName = $filename;
                                return $docFileName;
                            }else{
                             if($filename !== null){
                                  if($this->removedThisExistingDocumentFile($model->id)){
                               
                                //move the new file to the disk
                                    $docFileName = time().'_'.$filename;
                                    $documentPath = Yii::app()->params['gibberish'].$docFileName;
                                    move_uploaded_file($tmpName,  $documentPath);
                                    return $docFileName; 
                              }
                                
                             }
                               
                                
                               
                            } 
                            
                            
                        }
                      
                     }else{
                         return null;
                     }
            
            
        }
        
        
        /**
         * This is the function that determines if a new document is found
         */
        public function noNewDocumentFileProvided($id,$filename){
            
                $criteria = new CDbCriteria();
                $criteria->select = 'id, filename';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $document= Gibberish::model()->find($criteria);
                
                if($document['filename']==$filename){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        
        /**
         * This is the function that removes the existing gibberish file
         */
        public function removedThisExistingDocumentFile($id){
            
            //retreve the existing zip file from the database
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $document= Gibberish::model()->find($criteria);
                
                //$directoryPath = dirname(Yii::app()->request->scriptFile);
                $directoryPath = "c:\\xampp\htdocs\appspace_assets\\gibberish\\";
                //$videopath = '..\appspace_assets\videos'.$video['filename'];
               
                $filepath = $directoryPath.$document['filename'];
                        
                
                //$filepath = Yii::app()->params['videos'].$video['filename'];
                
                if(unlink($filepath)){
                    return true;
                }else{
                    return false;
                }
            
        }
 
       /**
         * This is the function that determines the type and size of th pdf document file;
          * Note: that video here represents the pdf document and must be taking as such
         */
        public function isDocumentTypeAndSizeLegal(){
            
            $documenttype = [];
            if(isset($_FILES['filename']['name'])){
                $tmpName = $_FILES['filename']['tmp_name'];
                $documentFileName = $_FILES['filename']['name'];    
                $documentType = $_FILES['filename']['type'];
                $documentFileSize = $_FILES['filename']['size'];
            } 
            //obtain the maximum gibberish file size 
        
            $size = $this->retrieveTheMaximumGibberishFileSize(); 
            
        
             $documenttype = $this->retrieveGibberishDocumentMimeType();
            
            //$size = 1024 * 1024 * 10 ;
           
         //if(($videoType === 'video/mp4' && $videoFileSize <= $size)){
             if((in_array($documentType,$documenttypes) && $documentFileSize <= $size)){    
                return true;
            }else{
                return false;
            }
         
         
        }
        
        
        
        /**
         * This is the function that retrieves the maximum allowable gibbberish file size
         */
        public function retrieveTheMaximumGibberishFileSize(){
            
             //retreive the platform set video size
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            //$criteria->condition='id=:id';
            //$criteria->params = array(':id'=>$id);
            $document = PlatformSettings::model()->find($criteria); 
            
            return $document['maximum_gibberish_filesize']; 
            
        }
        
        
        /**
         * This is the function that retrieves the allowable gibberish file mime type
         */
        public function retrieveGibberishDocumentMimeType(){
            
              //retreive the platform set video size
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            //$criteria->condition='id=:id';
            //$criteria->params = array(':id'=>$id);
            $document = PlatformSettings::model()->find($criteria); 
            
            return $document['gibberish_file_mime_type']; 
            
        }
        
        /**
         * This is the function that gets the domain id of a user
         */
        public function getTheDomainIdOfThisUser($user_id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$user_id);
             $domain = User::model()->find($criteria);   
             
             return $domain['domain_id'];
        }
        
        
        /**
         * This  is the function that gets the name of a domain
         */
        public function getTheNameOfThisDomain($domain_id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$domain_id);
             $domain = Resourcegroupcategory::model()->find($criteria);   
             
             return $domain['name'];
        }
        
        /**
         * This is the function that updates gibberish information
         */
        public function actionUpdateGibberish(){
            
            $_id = $_POST['id'];
            $model= Gibberish::model()->findByPk($_id);
            
            $user_id = Yii::app()->user->id;
            
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            
            $domain_name = $this->getTheNameOfThisDomain($domain_id);
            
                       
            $model->name = $_POST['name'];
            $model->description = $_POST['description'];
            $model->domain_id = $domain_id;
            $model->create_time = new CDbExpression('NOW()');
            $model->create_user_id = Yii::app()->user->id;
            
            $file_error_counter = 0;
             if($_FILES['filename']['name'] != ""){
                    if($this->isDocumentTypeAndSizeLegal()){
                       $filename = $_FILES['filename']['name'];
                       $filesize = $_FILES['filename']['size'];
                       
                    }else{
                          $file_error_counter = $file_error_counter + 1;
                         
                        
                    }//end of the determine size and type statement
                }else{
                   $filename = null;
                   $filesize = 0;
                   
                }   
                
               if(($file_error_counter ==0)){
                     
                 $model->filename = $this->moveTheGibberishDocumentToItsPathAndReturnTheDocumentFilename($model,$filename); 
                   
                 if($model->save()){
                   $msg = "Successfully updated the  '$model->name' gibberish";
                        header('Content-Type: application/json');
                        echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                             "msg" => $msg
                         ));
                    }else{
                     $msg = "'$model->name' gibberish could not be updated";
                    header('Content-Type: application/json');
                    echo CJSON::encode(array(
                        "success" => mysql_errno() != 0,
                         "msg" => $msg
                      ));
           } 
            
                   
                 }else if($file_error_counter > 0){
                    //get the platform settings for this property
                    $max_gibberish_file_size = $this->retrieveTheMaximumGibberishFileSize();
                    $msg = "Please check your document file type or size as the maximum allowable file size is '$max_gibberish_file_size'kb and types must be a pdf document";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                           "success" => mysql_errno() != 0,
                             "msg" => $msg)
                       );
                 } 
            
            
        }
        
        
        /**
         * This is the function that deletes a gibberish
         */
        public function actionDeleteOneGibberish(){
            
            $_id = $_POST['id'];
            //get the name of this location
            $gibberish = $this->getThisGibberishName($_id);
            $model= Gibberish::model()->findByPk($_id);
            if($model === null){
                 $msg = 'No Such Record Exist'; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                                      
            }else if($model->delete()){
                //remove the file at its location
                $this->removedThisExistingDocumentFile($_id);
                    $msg = "'$gibberish' gibberish was successfully deleted"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
            } else {
                    $msg = "'$gibberish' gibberish could not be deleted"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                            
                }
        }
        
        
        /**
         * This is the function that gets a gibberish name
         */
        public function getThisGibberishName($id){
            
            $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$user_id);
             $file = Gibberish::model()->find($criteria);   
             
             return $file['filename'];
            
        }
        
        /**
         * This is the function that list all gibberishes on the platform
         */
        public function actionlistPlatformgibberish(){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
              // $criteria->condition='type!=:type';
              // $criteria->params = array(':type'=>'special_report');
            $gibberish = Gibberish::model()->findAll($criteria);
                 
            if($gibberish===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "gibberish" => $gibberish
            
                       ));
                       
                }
            
            
        }
        
        /**
         * This is the function that list all domain gibberishes
         */
        public function actionlistDomaingibberish(){
            
             $user_id = Yii::app()->user->id;
            
           $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
           
                     
           $criteria = new CDbCriteria();
           $criteria->select = '*';
           $criteria->condition='domain_id=:domainid';
           $criteria->params = array(':domainid'=>$domain_id);
           $gibberish = Gibberish::model()->findAll($criteria);
                 
           if($gibberish===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "gibberish" => $gibberish
            
                       ));
                       
                }
            
            
        }
        
}
