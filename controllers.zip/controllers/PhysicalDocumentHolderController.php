<?php

class PhysicalDocumentHolderController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listAllDomainPhysicalDocumentWithDomain','getTheDocumentDetail',
                                   'ReturnThisPhysicalDocumentToStorage','RejectTheReturnOfThisPhysicalDocumentToStorage',
                                    'ConfirmTheReturnOfThisPhysicalDocumentToStorage','RejectTheAssignmentOfThisPhysicalDocument','ConfirmTheAssignmentOfThisPhysicalDocument',
                                    'isDomainVerifierRequired','AssignThisPhysicalDocument','listAllOtherDomainPhysicalDocumentWithDomain','ReturnThisOtherDomainPhysicalDocument',
                                    'AssignThisOtherDomainPhysicalDocument','listAllReassignedPhysicalDocumentInDomain','listAllReturnedPhysicalDocumentFromOtherDomain',
                                    'listAllDomainOffStationPhysicalDocuments','RecallThisPhysicalDocument','getTheDocumentDetailDuringConsumption','ReturnThisPhysicalDocumentToStorageAtConsumption',
                                    'ReturnThisPhysicalOtherDomainDocumentAtConsumption','AssignThisPhysicalDocumentAtConsumption','UnitTester'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that list all  own domain physical documents that are returnable by a domain
         */
        public function actionlistAllDomainPhysicalDocumentWithDomain(){
            
           $user_id = Yii::app()->user->id;
            
           $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
           
                     
           $criteria = new CDbCriteria();
           $criteria->select = '*';
            $criteria->condition='(holder_domain_id=:domainid and is_recall_initiated=:recalled) and (is_returned=:returned and is_return_initiated=:initiated)';
           $criteria->params = array(':domainid'=>$domain_id, ':recalled'=>false,':returned'=>false,':initiated'=>true);
           $documents = PhysicalDocumentHolder::model()->findAll($criteria);
           
           $all_own_documents = [];
           foreach($documents as $document){
               if($this->isDocumentOwnByThisDomain($document['document_id'],$domain_id)){
                   $all_own_documents[] = $document['id'];
                   
                 }
           }
           
           $domain_documents = [];
           
           foreach($all_own_documents as $own){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$own);
                $own_doc = PhysicalDocumentHolder::model()->find($criteria);
               
                $domain_documents[] =  $own_doc;
           }
                 
           if($documents===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "document" => $domain_documents
                        ));
                       
                }
            
        }
        
        
        /**
         * This is the function that deternines if a document belongs to a domain
         */
       public function isDocumentOwnByThisDomain($id,$domain_id){
           
           $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('resources')
                    ->where("id = $id && domain_id =$domain_id");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
       }
       
       
       /**
         * This is the function that gets the domain id of a user
         */
        public function getTheDomainIdOfThisUser($user_id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$user_id);
             $domain = User::model()->find($criteria);   
             
             return $domain['domain_id'];
        }
        
        
        /**
         * This is the function that retrieves a document's name
         */
        public function actiongetTheDocumentDetail(){
            
          
            $document_id = $_POST['document_id'];
            $batch_id = $_POST['batch_id'];
            $box_id = $_POST['box_id'];
            $id = $_POST['id'];
            $returneeid = $_POST['return_initiated_by'];
                    
            
            //get the document name 
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$document_id);
             $doc = Resources::model()->find($criteria);  
             
             //get the batch name
             $criteria1 = new CDbCriteria();
             $criteria1->select = '*';
             $criteria1->condition='id=:id';
             $criteria1->params = array(':id'=>$batch_id);
             $batch = Resources::model()->find($criteria1);  
             
             //get the box name
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='id=:id';
             $criteria2->params = array(':id'=>$box_id);
             $box = Resourcegroup::model()->find($criteria2);  
             
             //get the device name
             $criteria3 = new CDbCriteria();
             $criteria3->select = '*';
             $criteria3->condition='id=:id';
             $criteria3->params = array(':id'=>$doc['physical_document_storage_device_type_id']);
             $device = StorageDevice::model()->find($criteria3);  
             
             
              //get the storage room
             $criteria4 = new CDbCriteria();
             $criteria4->select = '*';
             $criteria4->condition='id=:id';
             $criteria4->params = array(':id'=>$doc['physical_document_location_room_id']);
             $room = StorageRoom::model()->find($criteria4);  
             
             
             //get the storage location
             $criteria5 = new CDbCriteria();
             $criteria5->select = '*';
             $criteria5->condition='id=:id';
             $criteria5->params = array(':id'=>$doc['physical_document_location_id']);
             $location = Location::model()->find($criteria5);  
             
             //get the  user id of the document holder
             $criteria6 = new CDbCriteria();
             $criteria6->select = '*';
             $criteria6->condition='id=:id';
             $criteria6->params = array(':id'=>$id);
             $holder = PhysicalDocumentHolder::model()->find($criteria6);  
             
             //get the name of this user
             $criteria7 = new CDbCriteria();
             $criteria7->select = '*';
             $criteria7->condition='id=:id';
             $criteria7->params = array(':id'=>$holder['user_id']);
             $holdername = User::model()->find($criteria7);
             $name = $holdername['firstname']. ' ' . $holdername['lastname'];
             
             //get the domain name of the document
             //get the document name 
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$doc['domain_id']);
             $domain = Resourcegroupcategory::model()->find($criteria);  
             
              //get the name of the user that initiated the return
             $criteria8 = new CDbCriteria();
             $criteria8->select = '*';
             $criteria8->condition='id=:id';
             $criteria8->params = array(':id'=>$returneeid);
             $returneename = User::model()->find($criteria8);
             $returnee_name = $returneename['firstname']. ' ' . $returneename['lastname'];
             
               //get the returnee domain
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$returneename['domain_id']);
             $returnee_domain = Resourcegroupcategory::model()->find($criteria);  
             
             if($doc===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "document" => $doc['name'],
                            "batch"=>$batch['name'],
                            "box"=>$box['name'],
                            "device"=>$device['label'],
                            "room"=>$room['name'],
                            "location"=>$location['name'],
                           "holder"=>$name,
                           "currentholder"=>$returnee_name,
                           "ownerdomainid"=>$doc['domain_id'],
                           "domainname"=>$domain['name'],
                           "holderdomain"=>$returnee_domain['name']
                    ));
                       
                }
            
            
        }
        
        
         /**
         * This is the function that retrieves a document's name
         */
        public function actiongetTheDocumentDetailDuringConsumption(){
            
          //get the user is
            
            $user_id = Yii::app()->user->id;
            
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            
            $document_id = $_POST['document_id'];
            $batch_id = $_POST['batch_id'];
            $box_id = $_POST['box_id'];
           // $id = $_POST['id'];
            $returneeid = $user_id;
                    
            
            //get the document name 
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$document_id);
             $doc = Resources::model()->find($criteria);  
             
             //get the batch name
             $criteria1 = new CDbCriteria();
             $criteria1->select = '*';
             $criteria1->condition='id=:id';
             $criteria1->params = array(':id'=>$batch_id);
             $batch = Resources::model()->find($criteria1);  
             
             //get the box name
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='id=:id';
             $criteria2->params = array(':id'=>$box_id);
             $box = Resourcegroup::model()->find($criteria2);  
             
             //get the device name
             $criteria3 = new CDbCriteria();
             $criteria3->select = '*';
             $criteria3->condition='id=:id';
             $criteria3->params = array(':id'=>$doc['physical_document_storage_device_type_id']);
             $device = StorageDevice::model()->find($criteria3);  
             
             
              //get the storage room
             $criteria4 = new CDbCriteria();
             $criteria4->select = '*';
             $criteria4->condition='id=:id';
             $criteria4->params = array(':id'=>$doc['physical_document_location_room_id']);
             $room = StorageRoom::model()->find($criteria4);  
             
             //get the detail of this document holding
                      
             $document_assigned_but_not_returned = $this->isThisPhysicalDocumentAssignedToThisUserButItsYetReturned($document_id,$batch_id,$box_id,$user_id,$domain_id);
             
             $never_with_physical_document =$this->isUserNotTheCurrentHolderOfThisPhysicalDocument($document_id,$batch_id,$box_id,$user_id,$domain_id);
             
             $requested_but_not_yet_assigned = $this->isDocumentRequestedByUserButNotYetAssigned($document_id,$batch_id,$box_id,$user_id,$domain_id);
             
             $idd = $this->getTheIdOfThisPhysicallyHeldDocument($document_id,$batch_id,$box_id,$user_id,$domain_id);
             
             //confirm if the request for this document is no longer concellable
             
             $cancellable = $this->isThisDocumentRequestStillCancellable($document_id,$batch_id,$box_id,$user_id);
            
             //get the storage location
             $criteria5 = new CDbCriteria();
             $criteria5->select = '*';
             $criteria5->condition='id=:id';
             $criteria5->params = array(':id'=>$doc['physical_document_location_id']);
             $location = Location::model()->find($criteria5);  
                              
             //get the name of this user
             $criteria7 = new CDbCriteria();
             $criteria7->select = '*';
             $criteria7->condition='id=:id';
             $criteria7->params = array(':id'=>$user_id);
             $holdername = User::model()->find($criteria7);
             $name = $holdername['firstname']. ' ' . $holdername['lastname'];
             
             //get the domain name of the document
             //get the document name 
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$doc['domain_id']);
             $domain = Resourcegroupcategory::model()->find($criteria);  
             
              //get the name of the user that initiated the return
             $criteria8 = new CDbCriteria();
             $criteria8->select = '*';
             $criteria8->condition='id=:id';
             $criteria8->params = array(':id'=>$returneeid);
             $returneename = User::model()->find($criteria8);
             $returnee_name = $returneename['firstname']. ' ' . $returneename['lastname'];
             
               //get the returnee domain
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$returneename['domain_id']);
             $returnee_domain = Resourcegroupcategory::model()->find($criteria);  
             
             if($doc===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "document" => $doc['name'],
                            "batch"=>$batch['name'],
                            "box"=>$box['name'],
                            "device"=>$device['label'],
                            "room"=>$room['name'],
                            "location"=>$location['name'],
                           "holder"=>$name,
                           "currentholder"=>$returnee_name,
                           "ownerdomainid"=>$doc['domain_id'],
                           "domainname"=>$domain['name'],
                           "holderdomain"=>$returnee_domain['name'],
                           "assigned_but_not_returned"=>$document_assigned_but_not_returned,
                           "never_with_physical"=>$never_with_physical_document,
                           "requested_but_not_assigned"=>$requested_but_not_yet_assigned,
                           "idd"=>$idd,
                           "cancellable"=>$cancellable,
                           "owner"=>true
                    ));
                       
                }
            
            
        }
        
     
        
        /**
         * This is the function that confirms if assignment is done but its yet to be returned
         */
        public function isThisPhysicalDocumentAssignedToThisUserButItsYetReturned($document_id,$batch_id,$box_id,$user_id,$domain_id){
           
           $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('physical_document_holder')
                    ->where("(is_returned = 0 && is_assigned =1) && (document_id=$document_id && user_id=$user_id)");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
    
 
        }
        
        
               
        /**
         * This is the function that confirms if  this user was never the current holder of this physical document
         */
        public function isUserNotTheCurrentHolderOfThisPhysicalDocument($document_id,$batch_id,$box_id,$user_id,$domain_id){
            
            if($this->isThisUserNotTheCurrentHolderOfThisDocument($document_id,$batch_id,$box_id,$user_id,$domain_id)){
                return true;
            }else{
                return false;
            }
            
            
        }
        
        /**
         * This is the function that confirms that this user is not current holder of this document
         */
        public function isThisUserNotTheCurrentHolderOfThisDocument($document_id,$batch_id,$box_id,$user_id,$domain_id){
            
             $criteria6 = new CDbCriteria();
             $criteria6->select = '*';
             $criteria6->condition='document_id=:doc and (is_returned=:returned or is_assigned=:assigned)';
             $criteria6->params = array(':doc'=>$document_id,':returned'=>false,':assigned'=>true);
             $holder = PhysicalDocumentHolder::model()->find($criteria6);  
             
             if($holder['user_id'] == $user_id){
                 return false;
             }else{
                 return true;
             }
            
        }
        
        
        /**
         * This is the function that confirms if document is requested but not yet assigned to the user
         */
        public function isDocumentRequestedByUserButNotYetAssigned($document_id,$batch_id,$box_id,$user_id,$domain_id){
            
           if($this->isThisRequestNotYetAssigned($document_id,$batch_id,$box_id,$user_id,$domain_id)){
                   return true;
               }else{
                   return false;
               }
     
            
        }
        
        /**
         * This is the function that confirms if a request is not assigned to a user
         */
        public function isThisRequestNotYetAssigned($document_id,$batch_id,$box_id,$user_id,$domain_id){
            
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('physical_document_holder')
                    ->where("(is_returned = 0 && is_assigned =0) && (document_id=$document_id && user_id=$user_id)");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
            
            
        }
        
              
        /**
         * This is the function that derive the id of the current physical holder of this document if its the user in question
         */
        public function getTheIdOfThisPhysicallyHeldDocument($document_id,$batch_id,$box_id,$user_id,$domain_id){
            
             $criteria6 = new CDbCriteria();
             $criteria6->select = '*';
             $criteria6->condition='(document_id=:doc and user_id=:userid) and (is_returned=:returned and is_assigned=:assigned)';
             $criteria6->params = array(':doc'=>$document_id,':userid'=>$user_id,':returned'=>false,':assigned'=>true);
             $holder = PhysicalDocumentHolder::model()->find($criteria6);
             
             if($holder['id'] != null){
                 return $holder['id'];
                 
             }else{
                 return 0;
             }
        }
        
        /**
         * This is the function that returns a physical document to its original storage location
         */
        public function actionReturnThisPhysicalDocumentToStorage(){
            
            
            $user_id = Yii::app()->user->id;
            $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
            $document_id = $_POST['document_id'];
            $batch_id = $_POST['batch_id'];
            $box_id = $_POST['box_id'];
            $id = $_POST['id'];
            
            $document_name = $this->getThisDocumentName($document_id);
            
            if($this->isThisDocumentReturnRequestInitiated($id)== false){
                if($this->isInitiatorVerifierRequired($domain_id)){
                
                if($this->isThisReturnInitiationSuccessful($id)){
                     header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "Return of '$document_name' document was initiated successfully"
                        ));
                    
                }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Could not initiate the return of '$document_name' document"
                        ));
                }
                
            }else{
                if($this->isReturnOfThisDocumentToStorageSuccessful($id)){
                    header('Content-Type: application/json');
                    echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "Return of '$document_name' document to storage was successfully"
                        ));
                }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Could not effect the return of '$document_name' document"
                        ));
                }
                
            }
            
                
            }else{
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Return of '$document_name' document had already been initiated and it's awaiting confirmation"
                        ));
            }
            
            
        }
        
        
        /**
         * This is the function that ensures the successful initiation of document returns
         */
        public function isThisReturnInitiationSuccessful($id){
            
             $cmd =Yii::app()->db->createCommand();
             $result = $cmd->update('physical_document_holder',
                                  array(
                                    'is_return_initiated'=>1, 
                                    'return_initiated_by'=>Yii::app()->user->id,  
                                    'return_initiated_date'=>new CDbExpression('NOW()'),
                                              
                            ),
                ("id=$id")
			
                        );
               if($result>0){
                   return true;
               }else{
                   return false;
               }
        }
        
        
        /**
         * This is the function that ensures that physical document return is confirmed returned
         */
        public function isReturnOfThisDocumentToStorageSuccessful($id){
            
            $cmd =Yii::app()->db->createCommand();
            $result = $cmd->update('physical_document_holder',
                                  array(
                                    'is_return_accepted'=>1, 
                                    'return_accepted_by'=>Yii::app()->user->id,  
                                    'return_accepted_date'=>new CDbExpression('NOW()'),
                                    'is_returned'=>1,   
                                              
                            ),
                ("id=$id")
			
                        );
               if($result>0){
                   return true;
               }else{
                   return false;
               }
            
        }
        
        
        /**
         * This is the function that gets a document name
         */
        public function getThisDocumentName($id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$id);
             $document = Resources::model()->find($criteria); 
             
             return $document['name'];
            
        }
        
        
                
        /**
      * This is the function that determines if initiator verifier is required by a domain
      */
     public function isInitiatorVerifierRequired($domain_id){
         
         if($this->isDomainVerifierPermittedOnThePlatform()){
             if($this->isDomainInitiatorExemptedFromVerification($domain_id)){
                 return false;
             }else{
                 return true;
             }
             
         }else{
            return false; 
         }
     }
     
      /**
      * This is the function that determines if domains initiators should be verified
      */
     public function isDomainVerifierPermittedOnThePlatform(){
         
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='id=:id';
           // $criteria->params = array(':id'=>$id);
            $settings = PlatformSettings::model()->find($criteria);
            
            if($settings['enable_domain_initiator_verifier']== 1){
                return true;
            }else{
                return false;
            }
         
     }
     
     
      /**
      * This is the fucntion that determines if domain is exempted from having a verifier 
      */
     public function isDomainInitiatorExemptedFromVerification($id){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='domain_id=:id and status=:status';
            $criteria->params = array(':id'=>$id,':status'=>'active');
            $policy = DomainPolicy::model()->find($criteria);
            
            if($policy['exempt_domain_initiator_verifier']== 1){
                return true;
            }else{
                return false;
            }
         
     }
     
     
     /**
      * This is the function that assigns physical document to a another holder(custodian)
      */
     public function actionAssignThisPhysicalDocument(){
            $user_id = Yii::app()->user->id;
            $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
            $document_id = $_POST['document_id'];
            $batch_id = $_POST['batch_id'];
            $box_id = $_POST['box_id'];
            $id = $_POST['id'];
            $max_period = $_POST['maximum_holding_period_in_days']; 
            
            if(isset($_POST['userid'])){
                $new_custodian = $_POST['userid'];
            }else if(isset($_POST['subgroupid'])){
                
                $new_custodian = $this->getTheSubgroupHeadIdOfThisSubgroup($_POST['subgroupid']);
            }else if(isset($_POST['groupid'])){
                $new_custodian = $this->getTheGroupHeadIdOfThisGroup($_POST['groupid']);
            }
         
            $document_name = $this->getThisDocumentName($document_id);
            if($this->isThisDocumentRecallRequestInitiated($id)== false){
             if($this->isThisDocumentAssignmentRequestInitiated($id) == false){
              if($this->isThisAssignmentInConformityWithDomainPolicy($domain_id)){
               if($this->isInitiatorVerifierRequired($domain_id)){
                
                if($this->isThisDocumentAssignmentInitiationSuccessful($id,$new_custodian,$max_period)){
                     header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "Assignment of '$document_name' document was initiated successfully"
                        ));
                    
                }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Could not initiate the assignment of '$document_name' document"
                        ));
                }
                
            }else{
                if($this->isAssignmentOfThisDocumentToACustodianSuccessful($id,$new_custodian,$max_period)){
                    header('Content-Type: application/json');
                    echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "Assignment of '$document_name' document to another custodian was successfully"
                        ));
                }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Could not effect the assignment of '$document_name' document"
                        ));
                }
            }
                      
                  }else{
                      header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                 "success" => mysql_errno() != 0,
                            "msg" => "This assignment is in violation with your domain policy. Please contact your domain administrator"
                        ));
                  }
                
                
                
            }else{
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "The assignment of '$document_name' document is already initiated awaiting confirmation"
                        )); 
                
            }    
               
           
            }else{
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "This '$document_name' document could not be assigned as the owner had initiated its recall process"
                        ));
                
            }
             
            
            
         
     }
     
     
     /**
      * This is the function that re-assigns document at consumption
      */
     public function actionAssignThisPhysicalDocumentAtConsumption(){
         
            $user_id = Yii::app()->user->id;
            $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
            $document_id = $_POST['document_id'];
            $batch_id = $_POST['batch_id'];
            $box_id = $_POST['box_id'];
            $id = $_POST['id'];
            $max_period = $_POST['maximum_holding_period_in_days']; 
            
            if(isset($_POST['userid'])){
                $new_custodian = $_POST['userid'];
            }else if(isset($_POST['subgroupid'])){
                
                $new_custodian = $this->getTheSubgroupHeadIdOfThisSubgroup($_POST['subgroupid']);
            }else if(isset($_POST['groupid'])){
                $new_custodian = $this->getTheGroupHeadIdOfThisGroup($_POST['groupid']);
            }
            
            $document_name = $this->getThisDocumentName($document_id);
            if($this->isThisDocumentRecallRequestInitiated($id)== false){
             if($this->isThisDocumentAssignmentRequestInitiatedAtConsumption($document_id,$user_id) == false){
                if($this->isThisDocumentCurrentlyAssignedToThisUser($id,$document_id,$user_id)){
                 if($this->isThisAssignmentInConformityWithDomainPolicy($domain_id)){
                 if($this->isInitiatorVerifierRequired($domain_id)){
                
                if($this->isThisNewDocumentAssignmentInitiationSuccessful($id,$document_id,$batch_id,$box_id,$new_custodian,$max_period,$domain_id)){
                     header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "Assignment of '$document_name' document was initiated successfully"
                        ));
                    
                }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Could not initiate the assignment of '$document_name' document"
                        ));
                }
                
            }else{
                if($this->isNewAssignmentOfThisDocumentToACustodianSuccessful($id,$document_id,$batch_id,$box_id,$new_custodian,$max_period,$domain_id)){
                    header('Content-Type: application/json');
                    echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "Assignment of '$document_name' document to another custodian was successfully"
                        ));
                }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Could not effect the assignment of '$document_name' document"
                        ));
                }
            }  
                
                
            }else{
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "This re-assignment is in violation with your domain policy. Please contact your domain admin"
                        ));
            }
         
             }else{
                   echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Could not effect the re-assignment of '$document_name' document as you are not the current holder"
                        )); 
                 
             }
             
              }else{
                      header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "The assignment of '$document_name' document is already initiated and it is awaiting confirmation"
                        )); 
                     
                 }
                 
              
                 
            
            }else{
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "This '$document_name' document could not be re-assigned as the owner had initiated its recall process"
                        ));
                
            }
            
         
         
     }
     
     
     /**
      * This is the function that determines assignment domain policy
      */
     public function isThisAssignmentInConformityWithDomainPolicy($domain_id){
         return true;
     }
     
     
     /**
      * This is the function that determines if a document is currently assigned to a user
      */
     public function isThisDocumentCurrentlyAssignedToThisUser($id,$document_id,$user_id){
         
         $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('physical_document_holder')
                    ->where("(is_returned = 0 && is_assigned =1) && (document_id=$document_id && user_id=$user_id)");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
         
         
     }
     
     /**
      * This is the function that verifies if document assignment was initiated successfully
      */
     public function isThisDocumentAssignmentInitiationSuccessful($id,$new_custodian,$max_period){
         
         $cmd =Yii::app()->db->createCommand();
         $result = $cmd->update('physical_document_holder',
                                  array(
                                    'is_assignment_initiated'=>1, 
                                    'maximum_holding_period_in_days'=>$max_period,  
                                    'assignment_initiated_by'=>Yii::app()->user->id,  
                                    'assignment_initiation_date'=>new CDbExpression('NOW()'),
                                    'user_id'=>$new_custodian
                                              
                            ),
                ("id=$id")
			
                        );
               if($result>0){
                   return true;
               }else{
                   return false;
               }
         
         
     }
     
     
     
     /**
      * This is the function that initiates  new document assignment to a user
      */
     public function isThisNewDocumentAssignmentInitiationSuccessful($id,$document_id,$batch_id,$box_id,$new_custodian,$max_period,$domain_id){
         
         //forcefully return the existing assigned document
         if($this->isThisAssignedDocumentForcefullyReturned($id)){
             if($this->thisNewAssignmentIsInitiatedSuccessfully($document_id,$batch_id,$box_id,$new_custodian,$max_period,$domain_id)){
                 return true;
             }else{
                 return false;
             }
                 
         }
         
         
         
     }
     
     
     /**
      * This is the function that forcefully return a document
      */
     public function isThisAssignedDocumentForcefullyReturned($id){
         
         $cmd =Yii::app()->db->createCommand();
         $result = $cmd->update('physical_document_holder',
                                  array(
                                    'is_returned'=>1, 
                                    'return_initiated_by'=>Yii::app()->user->id,  
                                    'return_accepted_by'=>Yii::app()->user->id,
                                    'return_initiated_date'=>new CDbExpression('NOW()'),
                                    'return_accepted_date'=>new CDbExpression('NOW()'),
                                    'is_return_initiated'=>1,
                                    'is_return_accepted'=> 1  
                     
                            ),
                ("id=$id")
			
                        );
               if($result>0){
                   return true;
               }else{
                   return false;
               }
     }
     
     /**
      * This is the function that initiates the re-assignment of  a document to another user 
      */
     public function thisNewAssignmentIsInitiatedSuccessfully($document_id,$batch_id,$box_id,$new_custodian,$max_period,$domain_id){
        
         $custodian_domain_id = $this->getTheDomainIdOfThisUser($new_custodian);
         
         $cmd =Yii::app()->db->createCommand();
         $result = $cmd->insert('physical_document_holder',
                   array(
                      'document_id'=>$document_id,
                      'batch_id'=>$batch_id,
                      'box_id'=>$box_id, 
                      'maximum_holding_period_in_days'=>$max_period, 
                      'assigned_type'=>"reassignment",
                      'user_id'=>$new_custodian,
                      'is_assignment_initiated'=>1,   
                      'assignment_initiation_date'=>new CDbExpression('NOW()'),
                      'assignment_initiated_by'=>Yii::app()->user->id,
                      'holder_domain_id'=>$custodian_domain_id,
                   )
			
                 );
            if($result>0){
                  return true;
            }else{
               return false;
            }
         
     }
     
     /**
      * This is the function that completes the initiation and confirmation of document re-assignment
      */
     public function isNewAssignmentOfThisDocumentToACustodianSuccessful($id,$document_id,$batch_id,$box_id,$new_custodian,$max_period,$domain_id){
          //forcefully return the existing assigned document
         if($this->isThisAssignedDocumentForcefullyReturned($id)){
             if($this->thisNewAssignmentIsInitiatedAndConfirmedSuccessfully($document_id,$batch_id,$box_id,$new_custodian,$max_period,$domain_id)){
                 return true;
             }else{
                 return false;
             }
         }
         
     }
     
     
     /**
      * This is the function that will forcefully initiates and comfirms an assignment based on domain policy 
      */
     public function thisNewAssignmentIsInitiatedAndConfirmedSuccessfully($document_id,$batch_id,$box_id,$new_custodian,$max_period,$domain_id){
         
         $custodian_domain_id = $this->getTheDomainIdOfThisUser($new_custodian);
         
         $cmd =Yii::app()->db->createCommand();
         $result = $cmd->insert('physical_document_holder',
                   array(
                      'document_id'=>$document_id,
                      'batch_id'=>$batch_id,
                      'box_id'=>$box_id, 
                      'maximum_holding_period_in_days'=>$max_period, 
                      'assigned_type'=>"reassignment",
                      'user_id'=>$new_custodian,
                      'is_assignment_initiated'=>1,   
                      'assignment_initiation_date'=>new CDbExpression('NOW()'),
                      'assignment_initiated_by'=>$userid,
                      'holder_domain_id'=>$custodian_domain_id,
                       'is_assignment_confirmed'=>1,
                       'assignment_confirmed_date'=>new CDbExpression('NOW()'),
                       'assignment_confirmed_by'=>Yii::app()->user->id,
                       'is_assigned'=>1
                   )
			
                 );
            if($result>0){
                  return true;
            }else{
               return false;
            }
         
     }
     
     /**
      * This is the function that ensures that document assignment is completely successful
      */
     public function isAssignmentOfThisDocumentToACustodianSuccessful($id,$new_custodian,$max_period){
         
          $cmd =Yii::app()->db->createCommand();
          $result = $cmd->update('physical_document_holder',
                                  array(
                                    'is_assignment_confirmed'=>1, 
                                    'assignment_confirmed_by'=>Yii::app()->user->id,  
                                    'assignment_confirmed_date'=>new CDbExpression('NOW()'),
                                    'is_assigned'=>1,
                                     'user_id'=>$new_custodian,
                                     'maximum_holding_period_in_days'=> $max_period 
                                              
                            ),
                ("id=$id")
			
                        );
               if($result>0){
                   return true;
               }else{
                   return false;
               }
         
     }
     
     
     /**
      * This is the function that rejects the return of document to storage
      */
     public function actionRejectTheReturnOfThisPhysicalDocumentToStorage(){
         
            $user_id = Yii::app()->user->id;
            $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
            $document_id = $_POST['document_id'];
            $batch_id = $_POST['batch_id'];
            $box_id = $_POST['box_id'];
            $id = $_POST['id'];
            
            $document_name = $this->getThisDocumentName($document_id);
            if($this->isThisDocumentReturnRequestInitiated($id)){
               if($this->isRejectionOfTheReturnOfThisThisDocumentSuccessful($id)){
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "The Return of '$document_name' document  to storage is rejected successfully"
                        ));
            }else{
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "The Return of '$document_name' document  to storage could not be rejected"
                        ));
            } 
                
            }else{
               header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "The Return of '$document_name' document  to storage was never initiated"
                        )); 
            }
            
         
     }
     
     
     /**
      * This is the function that effects the rejection of return of document to storgae
      */
     public function isRejectionOfTheReturnOfThisThisDocumentSuccessful($id){
         
         $cmd =Yii::app()->db->createCommand();
             $result = $cmd->update('physical_document_holder',
                                  array(
                                    'is_return_accepted'=>0, 
                                    'return_accepted_by'=>Yii::app()->user->id,  
                                    'return_accepted_date'=>new CDbExpression('NOW()'),
                                    'is_returned'=>0,   
                                              
                            ),
                ("id=$id")
			
                        );
               if($result>0){
                   return true;
               }else{
                   return false;
               }
         
     }
     
     
     /**
      * This is the that confirms the return of physical document to storage
      */
     public function actionConfirmTheReturnOfThisPhysicalDocumentToStorage(){
         
            $user_id = Yii::app()->user->id;
            $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
            $document_id = $_POST['document_id'];
            $batch_id = $_POST['batch_id'];
            $box_id = $_POST['box_id'];
            $id = $_POST['id'];
            
            $document_name = $this->getThisDocumentName($document_id);
            if($this->isThisDocumentReturnRequestInitiated($id)){
                if($this->isConfirmationOfTheReturnOfThisThisDocumentSuccessful($id)){
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "The Return of '$document_name' document  to storage is confirmed"
                        ));
            }else{
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "The Return of '$document_name' document  to storage could not be confirmed"
                        ));
            }
                
            }else{
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "The Return of '$document_name' document  to storage was never initiated"
                        ));
                
            }
            
         
     }
     
     
     /**
      * This is the function that effects the return of physical document to storage
      */
     public function isConfirmationOfTheReturnOfThisThisDocumentSuccessful($id){
         
          $cmd =Yii::app()->db->createCommand();
          $result = $cmd->update('physical_document_holder',
                                  array(
                                    'is_return_accepted'=>1, 
                                    'return_accepted_by'=>Yii::app()->user->id,  
                                    'return_accepted_date'=>new CDbExpression('NOW()'),
                                    'is_returned'=>1,   
                                              
                            ),
                ("id=$id")
			
                        );
               if($result>0){
                   return true;
               }else{
                   return false;
               }
         
     }
     
     /**
      * This is the function that rejects the assignment of physical document to another custodian
      */
     public function actionRejectTheAssignmentOfThisPhysicalDocument(){
            $user_id = Yii::app()->user->id;
            $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
            $document_id = $_POST['document_id'];
            $batch_id = $_POST['batch_id'];
            $box_id = $_POST['box_id'];
            $id = $_POST['id'];
            
            $document_name = $this->getThisDocumentName($document_id);
             if($this->isThisDocumentAssignmentRequestInitiated($id)){
                  if($this->isRejectionOfTheAssignmentOfThisThisDocumentSuccessful($id)){
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "The Assignment of '$document_name' document  to a custodian is rejected successfully"
                        ));
            }else{
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "The Assignment of '$document_name' document  to a custodian could not be rejected"
                        ));
            }
                 
             }else{
                 header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "The Assignment of '$document_name' document  to a custodian was never initiated"
                        ));
             }
           
         
         
     }
     
     
     
     /**
      * This is the function that rejects the assigment of documents to a custodian
      */
     public function isRejectionOfTheAssignmentOfThisThisDocumentSuccessful($id){
         
         $cmd =Yii::app()->db->createCommand();
          $result = $cmd->update('physical_document_holder',
                                  array(
                                    'is_assignment_confirmed'=>0, 
                                    'assignment_confirmed_by'=>Yii::app()->user->id,  
                                    'assignment_confirmed_date'=>new CDbExpression('NOW()'),
                                    'is_assigned'=>0,
                                    //  'user_id'=>$new_custodian
                                              
                            ),
                ("id=$id")
			
                        );
               if($result>0){
                   return true;
               }else{
                   return false;
               }
         
     }
     
     /**
      * This is the function that confirms the assignment of physical document to another custodian
      */
     public function actionConfirmTheAssignmentOfThisPhysicalDocument(){
         
            $user_id = Yii::app()->user->id;
            $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
            $document_id = $_POST['document_id'];
            $batch_id = $_POST['batch_id'];
            $box_id = $_POST['box_id'];
            $id = $_POST['id'];
            $max_period = $_POST['maximum_holding_period_in_days'];
            
            
           if(isset($_POST['user_id'])){
                $new_custodian = $_POST['user_id'];
            }
            
            $document_name = $this->getThisDocumentName($document_id);
            if($this->isThisDocumentAssignmentRequestInitiated($id)){
                if($this->isConfirmationOfTheAssignmenttOfThisThisDocumentSuccessful($id,$new_custodian,$max_period)){
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "The Assignment of '$document_name' document  to a custodian is confirmed"
                        ));
            }else{
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "The Assignment of '$document_name' document  to a custodian could not be confirmed"
                        ));
            }
               
           }else{
               header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "The Assignment of '$document_name' document  to a custodian was never initiated"
                        ));
           } 
           
         
     }
     
     
     /**
      * This is the function that effects the confirmation of document assignment to a custodian
      */
     public function isConfirmationOfTheAssignmenttOfThisThisDocumentSuccessful($id,$new_custodian,$max_period){
         
        $cmd =Yii::app()->db->createCommand();
          $result = $cmd->update('physical_document_holder',
                                  array(
                                    'is_assignment_confirmed'=>1, 
                                    'assignment_confirmed_by'=>Yii::app()->user->id,  
                                    'assignment_confirmed_date'=>new CDbExpression('NOW()'),
                                    'is_assigned'=>1,
                                    'user_id'=>$new_custodian,
                                    'maximum_holding_period_in_days'=> $max_period 
                                              
                            ),
                ("id=$id")
			
                        );
               if($result>0){
                   return true;
               }else{
                   return false;
               } 
         
     }
     
     
     /**
      * This is the function that retrieves the head of a subgroup
      */
     public function getTheSubgroupHeadIdOfThisSubgroup($subgroup_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$subgroup_id);
             $subgroup = SubGroup::model()->find($criteria);   
             
             return $subgroup['subgroup_head_id'];
         
         
     }
     
     
     /**
      * This is the function that retrieves the group head id of this group
      */
     public function getTheGroupHeadIdOfThisGroup($group_id){
         
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$group_id);
             $group = Group::model()->find($criteria);   
             
             return $group['group_head_id'];
         
         
     }
     
     
     /**
      * This is the function that determines if domain verifier is required for a domain
      */
     public function actionisDomainVerifierRequired(){
         
          $user_id = Yii::app()->user->id;
          $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
         
          if($this->isInitiatorVerifierRequired($domain_id)){
              
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "verify" => true
                        ));
          }else{
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "verify" => false
                        )); 
          }
     }

     
     /**
      * This is the function that determines if document return initiation is in place
      */
     public function isThisDocumentReturnRequestInitiated($id){
         
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$id);
             $doc = PhysicalDocumentHolder::model()->find($criteria);  
             
             if($doc['is_return_initiated'] == 1){
                 return true;
             }else{
                 return false;
             }
         
     }
     
     /**
      * This is the function that determines if document assignment initiation is already in place
      */
     public function isThisDocumentAssignmentRequestInitiated($id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$id);
             $doc = PhysicalDocumentHolder::model()->find($criteria);  
             
             if($doc['is_assignment_initiated'] == 1){
                 return true;
             }else{
                 return false;
             }
         
     }
     
     /**
       * This is the function that determines if document assignment initiation is already in place at consumption
      */
     public function isThisDocumentAssignmentRequestInitiatedAtConsumption($document_id,$user_id){
           //get the id of the transaction in question
         $id = $this->getTheIdOfThisUnconfirmedInitiatedDocumentAssignment($document_id,$user_id);
         
         if($this->isThisUnconfirmedDocumentAssignmentInitiationRequestNotRecalled($id)){
             return true;
         }else{
             return false;
         }
 
     }
     
     
     
     
     /**
      * This is the function that gets id of the unconfirmed assignment initiation
      */
     public function getTheIdOfThisUnconfirmedInitiatedDocumentAssignment($document_id,$user_id){
         
             $criteria6 = new CDbCriteria();
             $criteria6->select = '*';
             $criteria6->condition='document_id=:doc and (is_returned=:returned and is_assigned=:assigned) and (is_assignment_initiated=:initiated and assignment_initiated_by=:initiatedby )';
             $criteria6->params = array(':doc'=>$document_id,':returned'=>false,':assigned'=>false,':initiated'=>true,':initiatedby'=>$user_id);
             $holder = PhysicalDocumentHolder::model()->find($criteria6);
             
             if($holder['id'] != null){
                 return $holder['id'];
             }else{
                 return 0;
             }
         
     }
     
     
     /**
      * This is the function that confirms an unconfimed assignment had not been recalled
      */
     public function isThisUnconfirmedDocumentAssignmentInitiationRequestNotRecalled($id){
         
            if($id == 0){
                return false;
            }else{
                $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$id);
             $doc = PhysicalDocumentHolder::model()->find($criteria);  
             
             if($doc['is_recall_initiated'] == 0){
                 return true;
             }else{
                 return false;
             }
            }
             
         
     }
     
     /**
      * This is the function that list all other domain physical documents that is currently with domain
      */
     public function actionlistAllOtherDomainPhysicalDocumentWithDomain(){
         
          $user_id = Yii::app()->user->id;
            
           $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
           
                     
           $criteria = new CDbCriteria();
           $criteria->select = '*';
           $criteria->condition='(holder_domain_id=:domainid and is_recall_initiated=:recalled) and (is_returned=:returned and is_return_initiated=:initiated)';
           $criteria->params = array(':domainid'=>$domain_id, ':recalled'=>false,':returned'=>false,':initiated'=>true);
           $documents = PhysicalDocumentHolder::model()->findAll($criteria);
           
           $all_own_documents = [];
           foreach($documents as $document){
               if($this->isDocumentOwnByThisDomain($document['document_id'],$domain_id)==false){
                   $all_own_documents[] = $document['id'];
                   
                 }
           }
           
           $domain_documents = [];
           
           foreach($all_own_documents as $own){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$own);
                $own_doc = PhysicalDocumentHolder::model()->find($criteria);
               
                $domain_documents[] =  $own_doc;
           }
                 
           if($documents===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "document" => $domain_documents,
                           "all_doc"=>$documents
                        ));
                       
                }
         
         
     }
     
     
     /**
      * This is the function that returns other domain's physical document
      */
     public function actionReturnThisOtherDomainPhysicalDocument(){
         
            $user_id = Yii::app()->user->id;
            $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
            $document_id = $_POST['document_id'];
            $batch_id = $_POST['batch_id'];
            $box_id = $_POST['box_id'];
            $id = $_POST['id'];
            $owner_domain = $_POST['owner_domain_id'];
            
            $document_name = $this->getThisDocumentName($document_id);
            
            $domain_name = $this->getThisDomainName($owner_domain);
            
            if($this->isThisDocumentReturnRequestInitiated($id)== false){
                              
                if($this->isThisReturnInitiationSuccessful($id)){
                     header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "Return of '$document_name' document was initiated successfully"
                        ));
                    
                }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Could not initiate the return of '$document_name' document"
                        ));
                }
       
            }else{
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Return of '$document_name' document had already been initiated but awaiting confirmation of physical document receipt at '$domain_name' name"
                        ));
            }
         
         
     }
     
     
     /**
      * This is the function that gets the name of the document owner domain
      */
     public function getThisDomainName($owner_domain){
         
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$owner_domain);
             $domain = Resourcegroupcategory::model()->find($criteria);   
             
             return $domain['name'];
         
     }
     
     /**
      * This is the function that assigns other domain's physical document with domain 
      */
     public function actionAssignThisOtherDomainPhysicalDocument(){
         
           $user_id = Yii::app()->user->id;
            $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
            $document_id = $_POST['document_id'];
            $batch_id = $_POST['batch_id'];
            $box_id = $_POST['box_id'];
            $id = $_POST['id'];
            $max_period = $_POST['maximum_holding_period_in_days']; 
            
            if(isset($_POST['userid'])){
                $new_custodian = $_POST['userid'];
            }else if(isset($_POST['subgroupid'])){
                
                $new_custodian = $this->getTheSubgroupHeadIdOfThisSubgroup($_POST['subgroupid']);
            }else if(isset($_POST['groupid'])){
                $new_custodian = $this->getTheGroupHeadIdOfThisGroup($_POST['groupid']);
            }
         
            $document_name = $this->getThisDocumentName($document_id);
            if($this->isThisDocumentRecallRequestInitiated($id) == false){
                if($this->isThisDocumentAssignmentRequestInitiated($id) == false){
                 if($this->isInitiatorVerifierRequired($domain_id)){
                
                if($this->isThisDocumentAssignmentInitiationSuccessful($id,$new_custodian,$max_period)){
                     header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "Assignment of '$document_name' document was initiated successfully"
                        ));
                    
                }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Could not initiate the assignment of '$document_name' document"
                        ));
                }
                
            }else{
                if($this->isAssignmentOfThisDocumentToACustodianSuccessful($id,$new_custodian,$max_period)){
                    header('Content-Type: application/json');
                    echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "Assignment of '$document_name' document to another custodian was successfully"
                        ));
                }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Could not effect the assignment of '$document_name' document"
                        ));
                }
                
            }
                 
             }else{
                 header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Assignment of '$document_name' document had already been initiated"
                        ));
             }
                
                
            }else{
                 header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "This '$document_name' document could not be assigned as the owner had initiated its recall process"
                        ));
                
            }
             
         
     }
     
     
     /**
      * This is the function that list all reassigned documents within this domain
      */
     public function actionlistAllReassignedPhysicalDocumentInDomain(){
         
          $user_id = Yii::app()->user->id;
            
           $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
           
                     
           $criteria = new CDbCriteria();
           $criteria->select = '*';
           $criteria->condition='(holder_domain_id=:domainid and is_recall_initiated=:recalled) and (is_assigned=:assigned and is_assignment_initiated=:initiated)';
           $criteria->params = array(':domainid'=>$domain_id, ':recalled'=>false,':assigned'=>false,':initiated'=>true);
           $documents = PhysicalDocumentHolder::model()->findAll($criteria);
           
           $all_own_documents = [];
           foreach($documents as $document){
               if($this->isDocumentOwnByThisDomain($document['document_id'],$domain_id)){
                   $all_own_documents[] = $document['id'];
                   
                 }
           }
           
           $domain_documents = [];
           
           foreach($all_own_documents as $own){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$own);
                $own_doc = PhysicalDocumentHolder::model()->find($criteria);
               
                $domain_documents[] =  $own_doc;
           }
                 
           if($documents===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "document" => $domain_documents
                        ));
                       
                }
         
         
     }
     
     
     
     /**
      * This is the function that list all physical documents returned by other domain
      */
     public function actionlistAllReturnedPhysicalDocumentFromOtherDomain(){
         
           $user_id = Yii::app()->user->id;
            
           $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
           //$domain_id=2;
           
                     
           $criteria = new CDbCriteria();
           $criteria->select = '*';
           $criteria->condition='(holder_domain_id!=:domainid and is_recall_initiated=:recalled) and (is_returned=:returned and is_return_initiated=:initiated)';
           $criteria->params = array(':domainid'=>$domain_id, ':recalled'=>false,':returned'=>false,':initiated'=>true);
           $documents = PhysicalDocumentHolder::model()->findAll($criteria);
           
           $all_own_documents = [];
           foreach($documents as $document){
               if($this->isDocumentOwnByThisDomain($document['document_id'],$domain_id)){
                   $all_own_documents[] = $document['id'];
                   
                 }
           }
           
           $domain_documents = [];
           
           foreach($all_own_documents as $own){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$own);
                $own_doc = PhysicalDocumentHolder::model()->find($criteria);
               
                $domain_documents[] =  $own_doc;
           }
                 
           if($documents===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "document" => $domain_documents
                        ));
                       
                }
         
         
     }
     
     
     /**
      * This is the function that list all domain documents on transit
      */
     public function actionlistAllDomainOffStationPhysicalDocuments(){
         
         $user_id = Yii::app()->user->id;
            
           $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
           //$domain_id=2;
           
                     
           $criteria = new CDbCriteria();
           $criteria->select = '*';
           $criteria->condition='is_returned=:returned';
           $criteria->params = array(':returned'=>false);
           $documents = PhysicalDocumentHolder::model()->findAll($criteria);
           
           $all_own_documents = [];
           foreach($documents as $document){
               if($this->isDocumentOwnByThisDomain($document['document_id'],$domain_id)){
                   $all_own_documents[] = $document['id'];
                   
                 }
           }
           
           $domain_documents = [];
           
           foreach($all_own_documents as $own){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$own);
                $own_doc = PhysicalDocumentHolder::model()->find($criteria);
               
                $domain_documents[] =  $own_doc;
           }
                 
           if($documents===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "document" => $domain_documents
                        ));
                       
                }
         
     }
     
     
     
     /**
      * This is the function that effects the recall of a domain's document
      */
     public function actionRecallThisPhysicalDocument(){
         
            $user_id = Yii::app()->user->id;
            $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
            $document_id = $_POST['document_id'];
            $batch_id = $_POST['batch_id'];
            $box_id = $_POST['box_id'];
            $id = $_POST['id'];
            
            $document_name = $this->getThisDocumentName($document_id);
            
            if($this->isThisDocumentRecallRequestInitiated($id)== false){
                            
                if($this->isThisRecallInitiationSuccessful($id)){
                     header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "Recall of '$document_name' document was initiated successfully"
                        ));
                    
                }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Could not initiate the recall of '$document_name' document"
                        ));
                }
                
            }else{
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Recall of '$document_name' document had already been initiated"
                        ));
            }
         
         
     }
     
     
     
     /**
      * This is the function that determines if document recall had already been initiated
      */
     public function isThisDocumentRecallRequestInitiated($id){
         
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$id);
             $doc = PhysicalDocumentHolder::model()->find($criteria);  
             
             if($doc['is_recall_initiated'] == 1){
                 return true;
             }else{
                 return false;
             }
         
         
     }
    
     
     
     
     
     /**
      * This is the function that confirms the success of the recall initiation request
      */
     public function isThisRecallInitiationSuccessful($id){
         
        $cmd =Yii::app()->db->createCommand();
        $result = $cmd->update('physical_document_holder',
                                  array(
                                    'is_recall_initiated'=>1, 
                                    'recall_initiated_by'=>Yii::app()->user->id,  
                                    'recall_initiation_date'=>new CDbExpression('NOW()'),
                                              
                            ),
                ("id=$id")
			
                        );
               if($result>0){
                   return true;
               }else{
                   return false;
               }  
         
     }
     
     
     /**
      * This is the function that initiates the returns own domain document to storage at consumption
      */
     public function actionReturnThisPhysicalDocumentToStorageAtConsumption(){
         
            $user_id = Yii::app()->user->id;
            $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
            $document_id = $_POST['document_id'];
            $batch_id = $_POST['batch_id'];
            $box_id = $_POST['box_id'];
                       
            $document_name = $this->getThisDocumentName($document_id);
            
            if($this->isThisDocumentReturnRequestInitiated($id)== false){
                if($this->isInitiatorVerifierRequired($domain_id)){
                
                if($this->isThisReturnAtConsumptionInitiatedSuccessful($document_id,$batch_id,$box_id,$domain_id,$user_id)){
                     header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "Return of '$document_name' document was initiated successfully"
                        ));
                    
                }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Could not initiate the return of '$document_name' document"
                        ));
                }
                
            }else{
                if($this->isReturnOfThisDocumentToStorageSuccessful($id)){
                    header('Content-Type: application/json');
                    echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "Return of '$document_name' document to storage was successfully"
                        ));
                }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Could not effect the return of '$document_name' document"
                        ));
                }
                
            }
            
                
            }else{
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Return of '$document_name' document had already been initiated"
                        ));
            }
         
         
     }
     
     
    
     
     
       /**
         * This is the function that ensures the successful initiation of document returns
         */
     public function isThisReturnAtConsumptionInitiatedSuccessful($document_id,$batch_id,$box_id,$domain_id,$user_id){
            
              $cmd =Yii::app()->db->createCommand();
              $result = $cmd->insert('physical_document_holder',
                                  array(
                                    'document_id'=>$document_id,
                                     'batch_id'=>$batch_id,
                                      'box_id'=>$box_id,
                                      'user_id'=>$user_id,
                                      'is_returned'=>0,
                                      'is_return_initiated'=>1,
                                      'is_return_accepted'=>0,
                                      'holder_domain_id'=>$domain_id,
                                      'assigned_type'=>"returned",
                                      'return_initiated_by'=>$user_id,
                                      'return_initiated_date'=>new CDbExpression('NOW()'),
                             )
			
                        );
               if($result>0){
                   return true;
               }else{
                   return false;
               }
        }
        
        
        
       
        /**
         * This is the function that confirms the cancellation of a document request
         */
        public function isThisDocumentRequestStillCancellable($document_id,$batch_id,$box_id,$user_id){
            //get the document request id
           $id = $this->getTheIdOfThisDocumentOnRequest($document_id,$batch_id,$box_id,$user_id);
            if($id == 0){
                return false;
            }else{
             if($this->isThisDocumentRequestCancellable($id)== false){
                    return false;
                }else{
                 return true;
                }
               }
            
        }
        
        
             /**
      * This is the function that gets the id of the document on request
      */
     public function getTheIdOfThisDocumentOnRequest($document_id,$batch_id,$box_id,$user_id){
         
             $criteria6 = new CDbCriteria();
             $criteria6->select = '*';
             $criteria6->condition='(document_id=:doc and requesting_user_id=:userid) and (is_sent=:sent and is_requested=:requested) and is_request_cancelled=:cancelled';
             $criteria6->params = array(':doc'=>$document_id,':userid'=>$user_id,':sent'=>false,':requested'=>false,':cancelled'=>false);
             $holder = PhysicalDocumentRequest::model()->find($criteria6);  
             
            if($holder['id'] == 0 || $holder['id'] == null ){
                return 0;
            }else{
                return $holder['id'];
            }
         
     }
     
     
      /**
      * This is the function that determines if a batch request is cancellable
      */
     public function isThisDocumentRequestCancellable($id){
         
             $criteria6 = new CDbCriteria();
             $criteria6->select = '*';
             $criteria6->condition='id=:id';
             $criteria6->params = array(':id'=>$id);
             $request = PhysicalDocumentRequest::model()->find($criteria6);  
             
             if($request['is_sent'] == true || $request['is_sent'] == 1){
                 return false;
             }else if($request['is_request_cancelled'] == true || $request['is_request_cancelled']==1){
                 return false;
             }else{
                 return true;
             }
         
     }
     
     
     /**
      * This is a unit testing function
      */
     public function actionUnitTester($document_id=5, $user_id=1){
         $id = $this->getTheIdOfThisUnconfirmedInitiatedDocumentAssignment($document_id,$user_id);
         $result = $this->isThisDocumentAssignmentRequestInitiatedAtConsumption($document_id,$user_id);
         
          header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "result" => $result,
                           "id"=>$id
                        ));
     }
         
 
        
}
