<?php

class MessageDeliberationController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','retrieveThisMessageDeliberation','replyingtothisdeliberationmessage','sendingdeliberationmessage',
                                    'retrievethisMessageDeliberationContent','replyingtothisdeliberationmessage','deletemessagedeliberationfromthedeliberationboard',
                                    'retrieveTheAdoptersOfThisDeliberation','retrieveThisDeliberationAmendmentRequesters','retrieveThisDeliberationOnNoncommitals'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	 /**
         * This is the function that retrieves this member deliberstion all side talks
         */
        public function actionretrieveThisMessageDeliberation(){
            $model = new MessageDeliberation;
            
            $user_id = Yii::app()->user->id;
            
            $message_id = $_REQUEST['message_id'];
            $asset_id = $_REQUEST['asset_id'];
            //get all side talks sent out by user
            
            
            if($asset_id == 0){
                 $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $criteria->condition='((category=:cat and (`from`=:from and type=:type)) or ((category=:cat and type=:ttype) and `to`=:to)) and message_id=:mess';
                 $criteria->params = array(':cat'=>"chat",':from'=>$user_id,':type'=>"outbox",':to'=>$user_id,':ttype'=>"inbox",':mess'=>$message_id);
                 $criteria->order='id,parent_id';
                 $messages= MessageDeliberation::model()->findAll($criteria);
            
                if($messages===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                }else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "deliberation" => $messages,
                     
                       ));
                       
                }
                
                
            }else{
                
                $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $criteria->condition='((category=:cat and (`from`=:from and type=:type)) or ((category=:cat and type=:ttype) and `to`=:to)) and (message_id=:mess and asset_id=:asset)';
                 $criteria->params = array(':cat'=>"chat",':from'=>$user_id,':type'=>"outbox",':to'=>$user_id,':ttype'=>"inbox",':mess'=>$message_id,':asset'=>$asset_id);
                 $criteria->order='id,parent_id';
                 $messages= MessageDeliberation::model()->findAll($criteria);
            
                if($messages===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                }else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "deliberation" => $messages,
                     
                       ));
                       
                }
                
            }          
           
        }
        
        
        /**
         * This is the function that will send deiberation messages on the deliberation board
         */
        public function actionsendingdeliberationmessage(){
            
            $model = new MessageDeliberation;
            
            //get the message id on deliberation
            $message_id =$_REQUEST['message_id'];
            
            $group_id = $_REQUEST['group_id'];
            
                        
            $user_id = Yii::app()->user->id;
            
            $domain_id = $model->determineAUserDomainIdGiven($user_id);
            $message = $_REQUEST['message'];
            $counter = 0;
            $category = strtolower('chat');
            $code = $model->generateTheCodeForThisDeliberation($message_id);
            
           $decision = $_REQUEST['decision'];
           $asset_id = $_REQUEST['asset_id'];
           
            $file_error_counter = 0;
            
                 //move the mesage file if available
    if($message == ""){
                if($_FILES['deliberation_filename']['name'] != ""){
                    if($model->isFileTypeAndSizeAcceptable()){
                        
                      $filename = $_FILES['deliberation_filename']['name'];
                      $filename_size = $_FILES['deliberation_filename']['size'];
                      $file_type =  $_FILES['deliberation_filename']['type'];
                      
                      if($file_type == "application/pdf"){
                          $content_type = "document";
                      }else if($file_type == "image/png"){
                          $content_type = "image";
                      }else if($file_type == "image/jpg"){
                           $content_type = "image";
                      }else if($file_type == "image/jpeg"){
                          $content_type = "image";
                      }else if($file_type == "video/mp4"){
                          $content_type = "video";
                      }else if($file_type == "audio/mp3"){
                          $content_type = "audio";
                      }else{
                         $content_type = "text"; 
                      }
                        
                    }else{
                       
                        $file_error_counter = $file_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $filename =null;
                   $filename_size = 0;
                   $content_type = "text";
                   $file_error_counter = 0;
             
                }
                
               
            }else{
                 $content_type = "text";
                 $filename = null;
                 $file_error_counter = 0;
                 $filename_size = 0;
            }
            
        if($file_error_counter == 0){
            //move this file asset to its location and return a unique filename
            if($content_type !== "text"){
                 $filename_for_use = $model->moveThisFileToItsLocationAndReturnTheUniqueFilename($model,$filename,$content_type);
            }else{
                $filename_for_use=null;
            }
           
            $filesize = $filename_size;
            
        }
     
      
            if($group_id == 0){
                //get all the colleagues of this member
                $target_members = $this->getAllTheColleaguesOfThisMember($user_id);
            }else{
                //send to all group members
                $target_members = $this->getAllTheMembersOfThisNetwork($group_id);
            }
            
            
            //send the chat message to all eligible colleagues
          foreach($target_members as $col){
              if($col != $user_id){
                    if($this->isThisColleagueEligibleForThisMessage($this->getTheIssueAndValueIdOfThisMessage($message_id),$col)){
                        $deliberation_id =$model->executesendingChatDeliberationMessageToThisMembers($message_id,$col,$message,$code,$user_id,$domain_id,$filename_for_use,$content_type,$filesize,$decision,$asset_id);
                        $counter = $counter + 1;
                    
                  
                    }
              
                  
              }
            
                
                 
            }
          
            
             //write to the chat message outbox here
        $model->writeThisChatDeliberationMessageToTheSenderOutbox($message_id,$message,$code,$user_id,$domain_id,$filename_for_use,$content_type,$filesize,$decision,$asset_id);        
           
            $msg = "Chat Deliberation Message had been sent successfully";
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "msg" => $msg,
                                    "recepients"=>$target_members
                                  
                                   
                            ));
            
            
            
        }
        
        
         /**
         * This is the function that retrieves the colleagues of a user 
         */
        public function getAllTheColleaguesOfThisMember($user_id){
            $model = new MemberHasColleagues;
            return $model->getAllTheColleaguesOfThisMember($user_id);
        }
        
        
        /**
         * This is the function that gets all the members of a network group
         */
        public function getAllTheMembersOfThisNetwork($network_id){
            $model = new NetworkHasMembers;
            return $model->getAllTheMembersOfThisNetwork($network_id);
        }
        
        
         /**
         * This is the function that attaches the assets in buckets to main
         */
        public function attachTheAssetsInTheBucket($deliberation_id,$buckets){
            $model = new DeliberationHasBuckets;
            return $model->attachTheAssetsInTheBucket($deliberation_id,$buckets);
            
        }
        
        
        /**
         * This is the function that retrieves the issues and values of a message
         */
        public function getTheIssueAndValueIdOfThisMessage($message_id){
            $model = new Message;
            return $model->getTheIssueAndValueIdOfThisMessage($message_id);
        }
        
        
        /**
         * This is the function that replies to a deliberation message
         */
        public function actionreplyingtothisdeliberationmessage(){
            
            $model = new MessageDeliberation;
            
            $user_id = Yii::app()->user->id;
            
            $deliberation_id = $_REQUEST['deliberation_id'];
            
            $domain_id = $model->determineAUserDomainIdGiven($user_id);
            $message_id= $_REQUEST['message_id'];
            $message = $_REQUEST['message'];
            $counter = 0;
            $category = strtolower('chat');
            $code = $model->getTheCodeOfThisDeliberation($deliberation_id);
            $group_id = $_REQUEST['group_id'];
            $decision = $_REQUEST['decision'];
            $asset_id = $_REQUEST['asset_id'];
            
            $file_error_counter = 0;
           
            //move the mesage file if available
            if($message == ""){
                if($_FILES['deliberation_filename']['name'] != ""){
                    if($model->isFileTypeAndSizeAcceptable()){
                        
                      $filename = $_FILES['deliberation_filename']['name'];
                      $filename_size = $_FILES['deliberation_filename']['size'];
                      $file_type =  $_FILES['deliberation_filename']['type'];
                      
                      if($file_type == "application/pdf"){
                          $content_type = "document";
                      }else if($file_type == "image/png"){
                          $content_type = "image";
                      }else if($file_type == "image/jpg"){
                           $content_type = "image";
                      }else if($file_type == "image/jpeg"){
                          $content_type = "image";
                      }else if($file_type == "video/mp4"){
                          $content_type = "video";
                      }else if($file_type == "audio/mp3"){
                          $content_type = "audio";
                      }else{
                         $content_type = "text"; 
                      }
                        
                    }else{
                       
                        $file_error_counter = $file_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $filename =null;
                   $filename_size = 0;
                   $content_type = "text";
                   $file_error_counter = 0;
             
                }
                
               
            }else{
                 $content_type = "text";
                 $filename = null;
                 $file_error_counter = 0;
                 $filename_size = 0;
            }
            
        if($file_error_counter == 0){
            //move this file asset to its location and return a unique filename
            if($content_type !== "text"){
                 $filename_for_use = $model->moveThisFileToItsLocationAndReturnTheUniqueFilename($model,$filename,$content_type);
            }else{
                $filename_for_use=null;
            }
           
            $filesize = $filename_size;
            
        }
        
        
         
         
            if($group_id == 0){
                //get all the colleagues of this member
                $target_members = $this->getAllTheColleaguesOfThisMember($user_id);
            }else{
                //send to all group members
                $target_members = $this->getAllTheMembersOfThisNetwork($group_id);
            }
         
            //send the chat message to all eligible colleagues
          foreach($target_members as $col){
              if($col != $user_id){
                  if($this->isThisColleagueEligibleForThisMessage($this->getTheIssueAndValueIdOfThisMessage($message_id),$col)){
                    $new_deliberation_id =$model->replyingThisChatDeliberationMessageToThisColleague($deliberation_id,$message_id,$col,$message,$code,$user_id,$domain_id,$filename_for_use,$filesize,$content_type,$decision,$asset_id);
                    $counter = $counter + 1;
                }
              }
              
                
               
            }
        
            
             //write to the chat message outbox here
         $model->writeTheReplyToChatDeliberationMessageToTheSenderOutbox($deliberation_id,$message_id,$message,$code,$user_id,$domain_id,$filename_for_use,$filesize,$content_type,$decision,$asset_id);        
           
        
               $msg = "Reply to the Deliberation Message had been sent successfully";
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "msg" => $msg,
                                  "code"=>$code,
                                   "targets"=>$target_members 
                                    
                                  
                                   
                            ));
        }
        
        
         /**
         * This is the function that determines if a colleague is eligible for a chat message reciept
         */
        public function isThisColleagueEligibleForThisMessage($issue_id,$member_id){
            $model = new IssuesForMember;
            return $model->isThisColleagueEligibleForThisMessage($issue_id,$member_id);
        }
        
        
       /**
         * This is the platform that deletes a message deliberation from the deliberation board
         */
        public function actiondeletemessagedeliberationfromthedeliberationboard(){
           
           $deliberation_id = $_REQUEST['deliberation_id'];
           
            $model=  MessageDeliberation::model()->findByPk($deliberation_id);
            if($model === null){
                 $msg = 'No Such Record Exist'; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                             "msg" => $msg
                
                       ));
                                      
          }else if($model->isDeliberationAdopted($deliberation_id) == false){
             if($model->isDeliberationMessageWithChild($deliberation_id) == false){
                if($model->isTheDeliberationOnSideTalks($deliberation_id) == false){      
              
                   if($model->delete()){
                    $msg = "This deliberation message is successfully deleted"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                               "msg" => $msg
                          
                          
                       ));
                 }else{
                     $msg = "Deliberation message could not be deleted"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                               "msg" => $msg
                          
                          
                       ));
                     
                 }    
                       
                   
                    
           }else{
              if($this->isAllDeliberationSideTalksRemovedSuccessfully($deliberation_id)){
                if($model->isDeliberationMessageWithChild($deliberation_id) == false){
                    
                 if($model->delete()){
                    $msg = "This deliberation message is successfully deleted"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                               "msg" => $msg
                          
                          
                       ));
                 }else{
                     $msg = "Deliberation message could not be deleted"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                               "msg" => $msg
                          
                          
                       ));
                     
                 }    
                    
                }else{
                   if($model->isRemovalOfAllChildrenFromDeliberationMessageSuccessful($deliberation_id)){
                        if($model->delete()){
                            $msg = "This deliberation message is successfully deleted"; 
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                 "success" => mysql_errno() == 0,
                                 "msg" => $msg
                          
                          
                         ));
                        }else{
                             $msg = "Deliberation message could not be deleted"; 
                            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysql_errno() != 0,
                                "msg" => $msg
                          
                          
                            ));
                     
                 }  
                }else{
                    $msg = "Deliberation Message could not be deleted as the detachment of assets from the message was not successful"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                               "msg" => $msg
                          
                          
                       ));
                    
                } 
              }
                        
                    }else{
                        $msg = "Deliberation Message could not be deleted as side talks could not be removed. Please contact customer care for assistance"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                               "msg" => $msg
                          
                          
                       ));
                        
                    }
              }
     
            }else{
               if($model->isRemovalOfAllChildrenFromDeliberationMessageSuccessful($deliberation_id)){
                        $msg = "You have to first delete all replied messages on this deliberation before deleting it"; 
                            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysql_errno() != 0,
                                "msg" => $msg
                          
                          
                            ));
                }else{
                    $msg = "Deliberation Message could not be deleted as the detachment of assets from the message was not successful"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                               "msg" => $msg
                          
                          
                       ));
                    
                } 
                            
                }
                
            }else{
                    $msg = "This Deliberation message could not be deleted as this deliberation had already been adopted"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                               "msg" => $msg
                          
                          
                       ));
                
            }
                    
             
            
            
        }
        
        
         /**
         * This is the function that retrieves a message deliberation content
        */
        public function actionretrievethisMessageDeliberationContent(){
            $deliberation_id = $_REQUEST['deliberation_id'];
            
            $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$deliberation_id);
             $deliberation= MessageDeliberation::model()->find($criteria);
            
            if($deliberation===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                }else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "deliberation" => $deliberation,
                     
                       ));
                       
                }
        }
        
        
        /**
         * This is the function that removes all deliberation side talks
         */
        public function isAllDeliberationSideTalksRemovedSuccessfully($deliberation_id){
            $model = new DeliberationSidetalk;
            return $model->isRemovalOfThisDeliberationSidetalksASuccess($deliberation_id);
        }
        
        
        /**
         * This is the function that retrieves all adopters of a deliberstio
         * 
         */
        public function actionretrieveTheAdoptersOfThisDeliberation(){
            
            $model = new MessageDeliberation;
            
            $group_id = $_REQUEST['group_id'];
            $deliberation_id = $_REQUEST['deliberation_id'];
            
            
            
        }
        
        
         /**
         * This is the function that retrieves all deliberstion amendment requesters
         * 
         */
        public function actionretrieveThisDeliberationAmendmentRequesters(){
            
            $model = new MessageDeliberation;
            
            $group_id = $_REQUEST['group_id'];
            $deliberation_id = $_REQUEST['deliberation_id'];
            
            
            
        }
        
        
        /**
         * This is the function that retrieves all deliberstion noncommiters
         * 
         */
        public function actionretrieveThisDeliberationOnNoncommitals(){
            
            $model = new MessageDeliberation;
            
            $group_id = $_REQUEST['group_id'];
            $deliberation_id = $_REQUEST['deliberation_id'];
            
            
            
        }
}
