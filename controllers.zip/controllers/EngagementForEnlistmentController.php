<?php

class EngagementForEnlistmentController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','schedulingengagementwithuser','listAllScheduledEngagementForEnlistmentCode'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that schedules an engagement with a manufacturers/dealers customer service personnel
         */
        public function actionschedulingengagementwithuser(){
            
            $model = new EngagementForEnlistment;
            
            $model->code_id = $_REQUEST['code_id'];
            $model->user_id = $_REQUEST['user_id'];
            $model->appointment_date = date("Y-m-d H:i:s", strtotime( $_REQUEST['appointment_date']));
            $model->appointment_time = $_REQUEST['appointment_time'];
            $model->purpose = $_REQUEST['purpose'];
            if(isset($_REQUEST['reachme_by_email'])){
                $model->reachme_by_email = $_REQUEST['reachme_by_email'];
            }else{
                $model->reachme_by_email = 0;
            }
            if(isset($_REQUEST['reachme_by_phone'])){
                $model->reachme_by_phone = $_REQUEST['reachme_by_phone'];
            }else{
                $model->reachme_by_phone = 0;
            }
            if(isset($_REQUEST['reachme_by_whatsapp'])){
                $model->reachme_by_whatsapp = $_REQUEST['reachme_by_whatsapp'];
            }else{
                $model->reachme_by_whatsapp = 0;
            }
            $code = $this->getThisCode($model->code_id);
            
            if($model->isUserPermittedToScheduleAnAppointmentEngagement($model->code_id,$model->user_id)){
               if($model->save()){
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"Your appointment had been scheduled successfully. Somebody within the organization that produced or deal in that product will reach you on the  appointment date and time"
                        ));
                
                
            }else{
                header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There was a vaidation issue while trying to schedule thia appointment. Kindly check your input data and try again"
                        ));  
            }
                
            }else{
                header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"Sorry, this '$code' code does not support multiple engagement scheduling as you had already scheduled an appointment before "
                        ));
            }
        }
        
        
        /**
         * This is the function that retrieves a code given a code is
         */
        public function getThisCode($code_id){
            $model = new EnlistmentVerificationCode;
            return $model->getThisCode($code_id);
        }
        
        
        /**
         * This is the function that retrieves all scheduled engagement for an enlistment code
         */
        public function actionlistAllScheduledEngagementForEnlistmentCode(){
            
            $code_id = $_REQUEST['code_id'];
            
             //get the feedbakc template othis code
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='code_id=:codeid';
            $criteria->params = array(':codeid'=>$code_id);
            $engagement = EngagementForEnlistment::model()->findAll($criteria);
            
            
            if($code_id===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "engagement" =>$engagement
                                                                        
                    
                            ));
                       
                         }
        }
}
