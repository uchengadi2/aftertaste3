<?php

class DocumentResourceKeywordController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listAllDocumentComplementaryResourceKeyword','addNewKeywordsToThisDocument',
                                    'editComplementaryKeywordOfThisDocument','justtesting','deleteonekeyword'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	
        /**
         * This is the function that list all the complementary document resources for a document
         */
        public function actionlistAllDocumentComplementaryResourceKeyword(){
            
            //$primary_document_id = $_REQUEST['primary_id'];
            $comp_document_id = $_REQUEST['document_resource_id'];
            
            //$comp_document_id = 1;
            
             //spool all the private toolbox from this domain
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='document_resource_id=:documentid'; 
                $criteria->params = array(':documentid'=>$comp_document_id);
                $doc= DocumentResourceKeyword::model()->findAll($criteria);
           
                if($doc===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($doc);
                       
                }
            
            
        }
        
        
        /**
         * This is the function that adds new keyword to a document resource
         */
        public function actionaddNewKeywordsToThisDocument(){
         
            
           $document_resource_id = $_POST['document_resource_id'];
                       
           if(isset($_POST['keyword'])){
               $keywords = trim($_POST['keyword']);
           }
            
            
            //get the title of this document resoure
            $title = $this->getTheTitleOfThisDocumentResource($document_resource_id);
            
                         //write the kewords to this complementary document
            if($this->addKeywordsToThisComplementaryDocument($document_resource_id, $keywords)){
                       $msg = "Searchable keywords were successfully added to '$title' document resource";
                       header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => $msg)
                         );
                 }else{
                      $msg = "Addition of searchable keywords to '$title' document resource is not successful";
                       header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => $msg)
                         );
                 } 
                    
                         
            
            
            
        }
        
        
        /**
         * This is the function that adds keywords to complementary document
         */
        public function addKeywordsToThisComplementaryDocument($id,$keywords){
            
     
                $all_keywords = explode("+",$keywords);
                
                $counter = 0;
                foreach($all_keywords as $keyword){
                    //write this keyword to this document resource
                  if(!empty($keyword)){
                        if($this->isThisKeywordSuccessfullyWrittenToThisDocumentResource(trim($keyword),$id)){
                            $counter = $counter + 1;
                        }
                    }
                    
                }
                if($counter >0){
                    return true;
                    //return $counter;
                }else{
                    return false;
                   // return $counter;
                }
         
            
        }
        
           /**
         * This is just a tester function
         */
        public function actionjusttesting(){
           $keywords = "This is banana + one of the coolest + fruits";
           $trimmed_keywords = trim($keywords);
           $id =1;
            
            if(isset($keywords)){
                $all_keywords = explode("+",$keywords);
                
                $counter = 0;
                $all_trim = [];
                foreach($all_keywords as $keyword){
                    //write this keyword to this document resource
                     $all_trim[] = trim($keyword);
                  if(!empty($keyword)){
                        if($this->isThisKeywordSuccessfullyWrittenToThisDocumentResource(trim($keyword),$id)){
                            $counter = $counter + 1;
                        }
                    }
                    
                }
            }  
            
            if($counter===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "counter" => $counter,
                           "keyword"=>$keywords,
                          // "trimmed"=>$trimmed_keywords,
                           "allKeywords"=>$all_keywords,
                           "all_trimmed_keywords"=>$all_trim
                           //"original"=>$other_parameters
                          
                           
                           
                          
                       ));
                       
                }
        }
        
        
        
        
         /**
         * This is the function that confirms if the addition of keywords to a document resources is auccessful
         */
        public function isThisKeywordSuccessfullyWrittenToThisDocumentResource($keyword,$id){
            
            if(!empty($keyword)){
            $cmd =Yii::app()->db->createCommand();
            $result = $cmd->insert('document_resource_keyword',
                                  array(
                                    'document_resource_id'=>$id,
                                    'keyword'=>$keyword,
                                    'create_time'=>new CDbExpression('NOW()'),
                                   'create_user_id'=>Yii::app()->user->id,
                                  
                            )
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
            }else{
                return false;
            }
            
            
        }
        
      
        
        
        /**
         * get the title of a document resource
         */
        public function getTheTitleOfThisDocumentResource($document_resource_id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:documentid'; 
                $criteria->params = array(':documentid'=>$document_resource_id);
                $doc= DocumentResource::model()->find($criteria);
                
                return $doc['title'];
            
        }
        
        /**
         * This is the function that edits the keyword in document resource
         */
        public function actioneditComplementaryKeywordOfThisDocument(){
            
            $_id = $_POST['id'];
            $model= DocumentResourceKeyword::model()->findByPk($_id);
            
            $model->document_resource_id = $_POST['document_resource_id'];
            $model->keyword = $_POST['keyword'];
            $model->update_time = new CDbExpression('NOW()');
            $model->update_user_id = Yii::app()->user->id;
            
            //get the title of this document resoure
            $title = $this->getTheTitleOfThisDocumentResource($model->document_resource_id);
            
            if($model->save()) {
                        
                    $msg = "'$model->keyword' keyword in the '$title' document resource was updated successfully";
                    header('Content-Type: application/json');
                    echo CJSON::encode(array(
                    "success" => mysql_errno() == 0,
                    "msg" => $msg)
                   );
                         
             }
            
            
            
            
        }
        
        
        /**
         * This is the function that deletes a keyword from a document resource
         */
        public function actiondeleteonekeyword(){
            
             //delete a resourcegroup from subgroup
            $id = $_REQUEST['id'];
            $keyword = $_REQUEST['keyword'];
         
                
            //$model=GroupHasResourcegroup::model()->findByPk($_id);
           $cmd =Yii::app()->db->createCommand();  
           $result = $cmd->delete('document_resource_keyword', 'id=:id', array(':id'=>$id));
            
           if($result>0){
               header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"The '$keyword' keyword had successfully been removed from the document resource",
                       ));
           }else{
               header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"Could not remove the '$keyword' keyword from the document resource",
                       ));
           }
            
            
        }
}
